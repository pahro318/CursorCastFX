# ✨ CursorCastFX

> Modern cursor spell effects for **World of Warcraft 3.3.5a**

CursorCastFX adds customizable spell casting visual effects around your mouse cursor while keeping performance lightweight.

## ✨ Features

- 🎯 Beautiful cursor spell effects
- ⚡ Lightweight and optimized
- 🎨 Highly customizable
- 🛠️ Easy configuration
- 💾 No external libraries required
- 🧊 Designed for WoW 3.3.5a

## 📦 Installation

Extract the `CursorCastFX` folder into:

```
World of Warcraft/Interface/AddOns/
```

Restart the game.

## ❤️ Support

If you enjoy this addon and would like to support development:

**USDT (TRC20)**

```
TBUEo5TBGR9Uxpc4P65KBUAjeNXSg62aat
```

## 👨‍💻 Author

**pahro318**

https://github.com/pahro318

If you like the addon, consider leaving a ⭐ on this repository.
