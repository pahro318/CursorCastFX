local addon=_G.CursorCastFX; if not addon or not addon.visualFX then return end
local V=addon.visualFX
local panel=CreateFrame("Frame","CursorCastFXVisualFXConfig",UIParent)
panel:SetSize(500,560); panel:SetPoint("CENTER"); panel:SetFrameStrata("DIALOG"); panel:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=32,insets={left=11,right=12,top=12,bottom=11}}); panel:Hide(); panel:EnableMouse(true); panel:SetMovable(true); panel:RegisterForDrag("LeftButton"); panel:SetScript("OnDragStart",panel.StartMoving); panel:SetScript("OnDragStop",panel.StopMovingOrSizing)
local title=panel:CreateFontString(nil,"OVERLAY","GameFontNormalLarge"); title:SetPoint("TOP",0,-18); title:SetText("CursorCastFX — Visual Effects Studio 0.7")
local sub=panel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); sub:SetPoint("TOP",title,"BOTTOM",0,-5); sub:SetText(addon.L("Только декоративные эффекты — без HUD, кастбаров и неймплейтов", "Decorative effects only — no HUD, cast bars or nameplates"))
local close=CreateFrame("Button",nil,panel,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT",-5,-5)
local y=-66
local function check(label,key)
 local b=CreateFrame("CheckButton",nil,panel,"UICheckButtonTemplate"); b:SetPoint("TOPLEFT",24,y); b:SetSize(24,24)
 local t=b:CreateFontString(nil,"OVERLAY","GameFontNormal"); t:SetPoint("LEFT",b,"RIGHT",4,0); t:SetText(label)
 b:SetScript("OnShow",function() b:SetChecked(V:GetDB()[key] and true or false) end); b:SetScript("OnClick",function() V:GetDB()[key]=b:GetChecked() and true or false end); y=y-29; return b
end
check(addon.L("Включить Visual Effects Studio", "Enable Visual Effects Studio"),"enabled")
check(addon.L("Импульс возле курсора при начале и завершении заклинания", "Pulse near the cursor when a spell starts and finishes"),"cursorCast")
check(addon.L("Критический урон", "Critical damage"),"criticalDamage")
check(addon.L("Критическое исцеление", "Critical healing"),"criticalHeal")
check(addon.L("Успешное прерывание", "Successful interrupt"),"interrupt")
check(addon.L("Рассеивание магии, яда или проклятия", "Dispel magic, poison or curse"),"dispel")
check(addon.L("Эффект убийства цели", "Target-kill effect"),"kill")
check(addon.L("Вход и выход из боя", "Entering and leaving combat"),"combatState")
check(addon.L("Красная вспышка при сильном полученном уроне", "Red flash after heavy incoming damage"),"damageTaken")
check(addon.L("Крупные эффекты классовых проков", "Large class-proc effects"),"procAuras")
check(addon.L("Текст событий", "Event text"),"text")
check(addon.L("Свечение краёв экрана", "Screen-edge glow"),"screenEdges")
check(addon.L("Частицы и искры", "Particles and sparks"),"particles")
local function slider(label,key,minv,maxv,step)
 local s=CreateFrame("Slider",nil,panel,"OptionsSliderTemplate"); s:SetPoint("TOPLEFT",36,y-8); s:SetWidth(205); s:SetMinMaxValues(minv,maxv); s:SetValueStep(step)
 local l=panel:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); l:SetPoint("BOTTOMLEFT",s,"TOPLEFT",0,2); l:SetText(label)
 local val=panel:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); val:SetPoint("LEFT",s,"RIGHT",12,0)
 s:SetScript("OnShow",function() s:SetValue(V:GetDB()[key] or minv) end); s:SetScript("OnValueChanged",function(_,v) V:GetDB()[key]=v; val:SetText(string.format(step<1 and "%.2f" or "%.0f",v)) end); y=y-48; return s
end
slider(addon.L("Общая прозрачность", "Global opacity"),"masterAlpha",0.2,1,0.05)
slider(addon.L("Размер эффектов", "Effect size"),"scale",0.5,1.8,0.05)
slider(addon.L("Порог сильного урона, % здоровья", "Heavy-damage threshold, % health"),"damageThreshold",5,50,1)
local test=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate"); test:SetSize(126,25); test:SetPoint("BOTTOMLEFT",24,20); test:SetText(addon.L("Общий тест", "General test")); test:SetScript("OnClick",function() V:Test("all") end)
local heal=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate"); heal:SetSize(104,25); heal:SetPoint("LEFT",test,"RIGHT",7,0); heal:SetText(addon.L("Тест лечения", "Healing test")); heal:SetScript("OnClick",function() V:Test("heal") end)
local cursor=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate"); cursor:SetSize(104,25); cursor:SetPoint("LEFT",heal,"RIGHT",7,0); cursor:SetText(addon.L("Тест курсора", "Cursor test")); cursor:SetScript("OnClick",function() V:Test("cursor") end)
local reset=CreateFrame("Button",nil,panel,"UIPanelButtonTemplate"); reset:SetSize(104,25); reset:SetPoint("LEFT",cursor,"RIGHT",7,0); reset:SetText(addon.L("Сбросить", "Reset")); reset:SetScript("OnClick",function() CursorCastFXDB.visualFX=nil; V:GetDB(); panel:Hide(); panel:Show() end)
function V:ToggleConfig() if panel:IsShown() then panel:Hide() else panel:Show() end end
SLASH_CURSORCASTFXVISUAL1="/cfxvisual"; SLASH_CURSORCASTFXVISUAL2="/cfx fx"
SlashCmdList.CURSORCASTFXVISUAL=function(msg) msg=string.lower(msg or ""); if msg=="test" then V:Test("all") else V:ToggleConfig() end end
