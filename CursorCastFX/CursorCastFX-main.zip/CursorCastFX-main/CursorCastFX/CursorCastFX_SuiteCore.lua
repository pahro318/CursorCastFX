local addon = _G.CursorCastFX
if not addon then return end

addon.suiteVersion = "0.6.0"
addon.suite = addon.suite or {}
local Suite = addon.suite
Suite.modules = Suite.modules or {}

local defaults = {
    enabled = true,
    locked = false,
    hud = { enabled=true, scale=1, x=0, y=-165, width=290, height=18, showTarget=true, classColor=true, alpha=0.92 },
    procs = { enabled=true, scale=1, x=0, y=55, duration=0.45, sound=false, showName=true },
    actionFX = { enabled=false, pulseReady=true, dimUnusable=true, outOfRange=true, scale=1, alpha=0.9 },
    castbars = { enabled=true, target=true, focus=true, width=260, height=18, x=0, y=135, scale=1 },
    alerts = { enabled=true, lowHealth=true, healthThreshold=30, lowPower=false, powerThreshold=20, targetDanger=true, screenPulse=true },
}

local function Copy(t)
    if type(t) ~= "table" then return t end
    local n = {}
    for k,v in pairs(t) do n[k] = Copy(v) end
    return n
end
local function Merge(dst, src)
    if type(dst) ~= "table" then dst = {} end
    for k,v in pairs(src) do
        if dst[k] == nil then dst[k] = Copy(v)
        elseif type(dst[k]) == "table" and type(v) == "table" then Merge(dst[k], v) end
    end
    return dst
end

function Suite:GetDB()
    if type(CursorCastFXDB) ~= "table" then CursorCastFXDB = {} end
    CursorCastFXDB.suite = Merge(CursorCastFXDB.suite, defaults)
    return CursorCastFXDB.suite
end

function Suite:RegisterModule(name, module)
    self.modules[name] = module
end

function Suite:ApplyAll()
    local db = self:GetDB()
    for name, module in pairs(self.modules) do
        if module.Apply then
            local ok, err = xpcall(function() module:Apply(db[name] or db) end, addon.ErrorHandler)
            if not ok then addon:RecordError("Suite/"..tostring(name), err) end
        end
    end
end

function Suite:SetLocked(value)
    self:GetDB().locked = value and true or false
    for _, module in pairs(self.modules) do
        if module.SetLocked then module:SetLocked(self:GetDB().locked) end
    end
end

function Suite:Reset()
    CursorCastFXDB.suite = Copy(defaults)
    self:ApplyAll()
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent", function()
    Suite:GetDB()
    Suite:ApplyAll()
end)
