local addon=_G.CursorCastFX;if not addon then return end
local Suite=addon.suite;if not Suite then return end
local A={};Suite:RegisterModule("alerts",A)
local f=CreateFrame("Frame","CursorCastFXScreenAlerts",UIParent);f:SetAllPoints(UIParent);f:SetFrameStrata("FULLSCREEN_DIALOG");f:EnableMouse(false);f:Hide()
local edges={};for i=1,4 do local t=f:CreateTexture(nil,"OVERLAY");t:SetTexture("Interface\\Buttons\\WHITE8X8");t:SetBlendMode("ADD");edges[i]=t end
edges[1]:SetPoint("TOPLEFT");edges[1]:SetPoint("TOPRIGHT");edges[1]:SetHeight(32);edges[2]:SetPoint("BOTTOMLEFT");edges[2]:SetPoint("BOTTOMRIGHT");edges[2]:SetHeight(32);edges[3]:SetPoint("TOPLEFT");edges[3]:SetPoint("BOTTOMLEFT");edges[3]:SetWidth(32);edges[4]:SetPoint("TOPRIGHT");edges[4]:SetPoint("BOTTOMRIGHT");edges[4]:SetWidth(32)
local text=f:CreateFontString(nil,"OVERLAY","GameFontNormalHuge");text:SetPoint("CENTER",0,210)
A.phase=0
function A:Apply(db) if not db.enabled then f:Hide() end end
function A:Update()
 local db=Suite:GetDB().alerts;if not db.enabled then f:Hide();return end
 local hp,hm=UnitHealth("player") or 0,UnitHealthMax("player") or 1;local pct=hm>0 and hp/hm*100 or 100
 if db.lowHealth and pct<=(db.healthThreshold or 30) then for _,e in ipairs(edges) do e:SetTexture(1,.03,.03,.75) end;text:SetText(addon.L("НИЗКОЕ ЗДОРОВЬЕ", "LOW HEALTH"));f:Show();return end
 f:Hide()
end
local e=CreateFrame("Frame");e:RegisterEvent("UNIT_HEALTH");e:RegisterEvent("PLAYER_ENTERING_WORLD");e:SetScript("OnEvent",function(_,_,unit)if not unit or unit=="player" then A:Update() end end)
f:SetScript("OnUpdate",function(_,dt)A.phase=A.phase+dt;f:SetAlpha(.45+.35*math.abs(math.sin(A.phase*5))) end)
