local addon = _G.CursorCastFX
if not addon then return end

local registry = addon.ModuleRegistry or {}
addon.ModuleRegistry = registry
registry.modules = registry.modules or {}
registry.order = registry.order or {}

function registry:Register(name, module)
    if type(name) ~= "string" or name == "" then return nil, "invalid module name" end
    if type(module) ~= "table" then return nil, "module must be a table" end

    if not self.modules[name] then
        table.insert(self.order, name)
    end
    self.modules[name] = module
    module.name = module.name or name
    return module
end

function registry:Get(name)
    return self.modules[name]
end

function registry:ForEach(callback)
    if type(callback) ~= "function" then return end
    for _, name in ipairs(self.order) do
        local module = self.modules[name]
        if module then callback(name, module) end
    end
end

function addon:RegisterModule(name, module)
    return registry:Register(name, module)
end

function addon:GetModule(name)
    return registry:Get(name)
end

addon:RegisterModule("Core", addon)
