local addon = _G.CursorCastFX
if not addon then return end

local Pool = {}
Pool.__index = Pool

function Pool:Acquire()
    local object = table.remove(self.free)
    if not object then
        object = self.factory()
        self.created = self.created + 1
    end
    self.active[object] = true
    self.inUse = self.inUse + 1
    return object
end

function Pool:Release(object)
    if not object or not self.active[object] then return false end
    self.active[object] = nil
    self.inUse = self.inUse - 1
    if self.reset then self.reset(object) end
    table.insert(self.free, object)
    return true
end

function Pool:ReleaseAll()
    local pending = {}
    for object in pairs(self.active) do table.insert(pending, object) end
    for _, object in ipairs(pending) do self:Release(object) end
end

function Pool:GetStats()
    return self.created, self.inUse, #self.free
end

local ObjectPool = addon.ObjectPool or {}
addon.ObjectPool = ObjectPool
ObjectPool.pools = ObjectPool.pools or {}

function ObjectPool:Create(name, factory, reset, preallocate)
    if type(name) ~= "string" or name == "" then return nil, "invalid pool name" end
    if type(factory) ~= "function" then return nil, "factory must be a function" end
    if self.pools[name] then return self.pools[name] end

    local pool = setmetatable({
        name = name,
        factory = factory,
        reset = reset,
        free = {},
        active = {},
        created = 0,
        inUse = 0,
    }, Pool)

    self.pools[name] = pool
    preallocate = tonumber(preallocate) or 0
    for _ = 1, preallocate do
        local object = factory()
        pool.created = pool.created + 1
        if reset then reset(object) end
        table.insert(pool.free, object)
    end
    return pool
end

function ObjectPool:Get(name)
    return self.pools[name]
end

addon:RegisterModule("ObjectPool", ObjectPool)
