local addon = _G.CursorCastFX
if not addon then return end

local diagnostics = addon.Diagnostics or {}
addon.Diagnostics = diagnostics

local function BoolText(value)
    return value and "OK" or "FAIL"
end

function diagnostics:Run()
    local checks = {
        { "Core", type(addon.OnEvent) == "function" },
        { "ModuleRegistry", type(addon.ModuleRegistry) == "table" },
        { "ObjectPool", type(addon.ObjectPool) == "table" },
        { "RuntimeEngine", type(addon.RuntimeEngine) == "table" },
        { "Controller", addon.controller ~= nil },
        { "Database API", type(addon.GetProfile) == "function" },
    }

    local passed = 0
    for _, check in ipairs(checks) do
        if check[2] then passed = passed + 1 end
        addon.Chat(string.format("Architecture: %-16s %s", check[1], BoolText(check[2])))
    end
    addon.Chat(string.format(addon.L("Architecture: %d/%d проверок пройдено.", "Architecture: %d/%d checks passed."), passed, #checks))
    return passed == #checks
end

addon:RegisterModule("Diagnostics", diagnostics)

SLASH_CCFXARCH1 = "/ccfxarch"
SlashCmdList.CCFXARCH = function()
    diagnostics:Run()
end
