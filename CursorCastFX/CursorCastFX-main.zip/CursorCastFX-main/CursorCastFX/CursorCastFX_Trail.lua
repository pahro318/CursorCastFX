local addon = _G.CursorCastFX
if not addon then return end

local Trail = {}
addon.modules.Trail = Trail

local floor = math.floor
local sqrt = math.sqrt
local sin = math.sin
local cos = math.cos
local max = math.max
local min = math.min
local pi = math.pi
local random = math.random
local Mod = addon.Mod
local Clamp = addon.Clamp
local Media = addon.Media

local textureStyles = {
    spark = Media("spark.tga"),
    leaf = Media("leaf.tga"),
    soft = Media("glow.tga"),
    rune = Media("ring_inner.tga"),
    star = Media("burst.tga"),
}
Trail.textureStyles = textureStyles

local modelPresets = {
    nature = { layers = {
        { path="spells\\rejuvenation_impact_base", scale=0.35, facing=0, x=5, y=-6 },
    }},
    leaves = { layers = {
        { path="spells\\nature_form_precast", scale=2.50, facing=1.00, x=13, y=-11 },
    }},
    arcane = { layers = {
        { path="spells\\arcane_form_precast", scale=1.10, facing=0.70, x=9, y=-11 },
    }},
    electricBlue = { lightning=true, layers = {
        { path="spells\\lightning_precast_low_hand", scale=1.00, facing=0, x=4, y=-6 },
    }},
    electricBlueLong = { lightning=true, layers = {
        { path="spells\\lightningboltivus_missile", scale=0.10, facing=0, x=4, y=-6 },
    }},
    electricGreen = { lightning=true, layers = {
        { path="spells\\lightning_fel_precast_low_hand", scale=1.00, facing=0, x=4, y=-6 },
    }},
    electricYellow = { lightning=true, layers = {
        { path="spells\\wrath_precast_hand", scale=1.50, facing=0, x=4, y=-6 },
    }},
    energyBeam = { beam=true, layers = {
        { role="core", path="spells\\lightning_precast_low_hand", scale=1.00, facing=0, x=4, y=-6 },
        { role="aura", path="spells\\fire_blue_precast_uber_hand", scale=1.00, facing=0, x=6, y=-8, strata="FULLSCREEN_DIALOG" },
    }},
    energyBeamLong = { beam=true, layers = {
        { role="core", path="spells\\lightningboltivus_missile", scale=0.10, facing=0, x=4, y=-6 },
        { role="aura", path="spells\\detectmagic_recursive", scale=4.00, facing=0, x=0, y=0, strata="FULLSCREEN_DIALOG" },
    }},
    stormBeam = { beam=true, layers = {
        { role="core", path="spells\\lightning_precast_low_hand", scale=1.00, facing=0, x=4, y=-6 },
        { role="aura", path="spells\\arcane_form_precast", scale=1.10, facing=0.70, x=9, y=-11, strata="FULLSCREEN_DIALOG" },
    }},
    frostStorm = { layers = {
        { path="spells\\lightningboltivus_missile", scale=0.10, facing=0, x=4, y=-6 },
        { path="spells\\frost_form_precast", scale=1.10, facing=0.70, x=9, y=-11, strata="FULLSCREEN_DIALOG" },
    }},
    felBeam = { beam=true, forcedPalette="green", layers = {
        { role="core", path="spells\\lightning_fel_precast_low_hand", scale=1.00, facing=0, x=4, y=-6 },
        { role="aura", path="spells\\fel_fire_precast_hand", scale=1.00, facing=0, x=6, y=-8, strata="FULLSCREEN_DIALOG" },
    }},
    holyBeam = { beam=true, forcedPalette="yellow", layers = {
        { role="core", path="spells\\wrath_precast_hand", scale=1.50, facing=0, x=4, y=-6 },
        { role="aura", path="spells\\holy_missile_uber", scale=0.90, facing=0, x=11, y=-9, strata="FULLSCREEN_DIALOG" },
    }},
    shadowBeam = { beam=true, forcedPalette="violet", layers = {
        { role="core", path="spells\\shadow_precast_uber_hand", scale=1.00, facing=0, x=4, y=-6 },
        { role="aura", path="spells\\cripple_state_chest", scale=0.50, facing=0, x=8, y=-8, strata="FULLSCREEN_DIALOG" },
    }},
    frost = { layers = {
        { path="spells\\ice_precast_low_hand", scale=2.50, facing=0, x=8, y=-7 },
    }},
    fire = { layers = {
        { path="spells\\fire_precast_uber_hand", scale=1.50, facing=0, x=4, y=-6 },
    }},
    fel = { layers = {
        { path="spells\\fel_fire_precast_hand", scale=1.00, facing=0, x=6, y=-8 },
    }},
    holy = { layers = {
        { path="spells\\holy_precast_uber_hand", scale=1.00, facing=0, x=5, y=-6 },
    }},
    shadow = { layers = {
        { path="spells\\shadow_precast_uber_hand", scale=1.00, facing=0, x=4, y=-6 },
    }},
    poison = { layers = {
        { path="spells\\banish_chest", scale=0.50, facing=0, x=11, y=-9 },
    }},
    ghost = { layers = {
        { path="spells\\zig_missile", scale=0.70, facing=1.00, x=8, y=-5 },
    }},
    white = { layers = {
        { path="spells\\ribbontrail", scale=1.00, facing=0, x=0, y=0 },
    }},
    intervene = { layers = {
        { path="spells\\intervenetrail", scale=1.00, facing=2.40, x=7, y=-7 },
    }},
    chargeRed = { layers = {
        { path="spells\\chargetrail", scale=1.00, facing=2.40, x=0, y=0 },
    }},
    souls = { layers = {
        { path="spells\\wellofsouls_base", scale=0.50, facing=0, x=9, y=-8 },
    }},
}
Trail.modelPresets = modelPresets

local paletteLayers = {
    blue = {
        core={path="spells\\lightning_precast_low_hand", scale=1.00, facing=0, x=4, y=-6},
        aura={path="spells\\fire_blue_precast_uber_hand", scale=1.00, facing=0, x=6, y=-8},
    },
    blueLong = {
        core={path="spells\\lightningboltivus_missile", scale=0.10, facing=0, x=4, y=-6},
        aura={path="spells\\detectmagic_recursive", scale=4.00, facing=0, x=0, y=0},
    },
    green = {
        core={path="spells\\lightning_fel_precast_low_hand", scale=1.00, facing=0, x=4, y=-6},
        aura={path="spells\\fel_fire_precast_hand", scale=1.00, facing=0, x=6, y=-8},
    },
    yellow = {
        core={path="spells\\wrath_precast_hand", scale=1.50, facing=0, x=4, y=-6},
        aura={path="spells\\holy_missile_uber", scale=0.90, facing=0, x=11, y=-9},
    },
    violet = {
        core={path="spells\\shadow_precast_uber_hand", scale=1.00, facing=0, x=4, y=-6},
        aura={path="spells\\arcane_form_precast", scale=1.10, facing=0.70, x=9, y=-11},
    },
    frost = {
        core={path="spells\\lightningboltivus_missile", scale=0.10, facing=0, x=4, y=-6},
        aura={path="spells\\frost_form_precast", scale=1.10, facing=0.70, x=9, y=-11},
    },
    white = {
        core={path="spells\\ribbontrail", scale=1.00, facing=0, x=0, y=0},
        aura={path="spells\\dispel_low_recursive", scale=4.00, facing=0, x=0, y=0},
    },
    red = {
        core={path="spells\\chargetrail", scale=1.00, facing=2.40, x=0, y=0},
        aura={path="spells\\immolationtrap_recursive", scale=4.00, facing=0, x=0, y=0},
    },
}
Trail.paletteLayers = paletteLayers

local frame = CreateFrame("Frame", "CursorCastFXTrailController", UIParent)
Trail.frame = frame
frame:SetAllPoints(UIParent)
frame:SetFrameStrata("TOOLTIP")
frame:EnableMouse(false)

local pixelSpace = CreateFrame("Frame", "CursorCastFXPhysicalPixelSpace", UIParent)
Trail.pixelSpace = pixelSpace
pixelSpace:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 0, 0)
pixelSpace:SetFrameStrata("TOOLTIP")
pixelSpace:EnableMouse(false)

local function RefreshPixelSpace()
    local scale = 1
    if UIParent and UIParent.GetEffectiveScale then scale = UIParent:GetEffectiveScale()
    elseif UIParent and UIParent.GetScale then scale = UIParent:GetScale() end
    scale = tonumber(scale) or 1
    if scale <= 0 then scale = 1 end

    local uiWidth = UIParent and UIParent.GetWidth and UIParent:GetWidth() or 0
    local uiHeight = UIParent and UIParent.GetHeight and UIParent:GetHeight() or 0
    uiWidth, uiHeight = tonumber(uiWidth) or 0, tonumber(uiHeight) or 0
    local pixelWidth, pixelHeight = uiWidth * scale, uiHeight * scale
    if pixelWidth <= 1 and GetScreenWidth then pixelWidth = (tonumber(GetScreenWidth()) or 0) * scale end
    if pixelHeight <= 1 and GetScreenHeight then pixelHeight = (tonumber(GetScreenHeight()) or 0) * scale end

    local changed = Trail.pixelScale ~= scale or Trail.pixelWidth ~= pixelWidth or Trail.pixelHeight ~= pixelHeight
    if changed then
        pixelSpace:ClearAllPoints()
        pixelSpace:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 0, 0)
        pixelSpace:SetScale(1 / scale)
        pixelSpace:SetWidth(max(1, pixelWidth))
        pixelSpace:SetHeight(max(1, pixelHeight))
        Trail.pixelScale = scale
        Trail.pixelWidth = pixelWidth
        Trail.pixelHeight = pixelHeight
    end
    return scale, pixelWidth, pixelHeight, changed
end
Trail.RefreshPixelSpace = RefreshPixelSpace
RefreshPixelSpace()

Trail.pool = {}
Trail.nextIndex = 1
Trail.lastSpawnX = nil
Trail.lastSpawnY = nil
Trail.lastRawX = nil
Trail.lastRawY = nil
Trail.elapsedSinceSpawn = 0
Trail.rainbowTime = 0
Trail.idleTime = 0

for i = 1, 64 do
    local anchor = CreateFrame("Frame", nil, pixelSpace)
    anchor:SetWidth(1); anchor:SetHeight(1)
    anchor:SetFrameStrata("TOOLTIP")
    anchor:EnableMouse(false)
    anchor:Hide()

    local texture = anchor:CreateTexture(nil, "OVERLAY")
    texture:SetPoint("CENTER", anchor, "CENTER", 0, 0)
    texture:SetTexture(textureStyles.spark)
    texture:SetBlendMode("ADD")
    texture:Hide()
    Trail.pool[i] = {
        anchor=anchor, texture=texture, age=99, life=0.45, baseSize=20, baseAlpha=0.75,
        seed=i * 0.43, x=0, y=0, vx=0, vy=0, spin=0, angle=0,
    }
end

local legacyRoot = CreateFrame("Frame", "CursorCastFXLegacyCursorRoot")
Trail.legacyRoot = legacyRoot
Trail.models = {}

local function RefreshLegacyHypotenuse()
    local width = GetScreenWidth and GetScreenWidth() or 1024
    local height = GetScreenHeight and GetScreenHeight() or 768
    local scale = 1
    if UIParent and UIParent.GetEffectiveScale then scale = UIParent:GetEffectiveScale() or 1 end
    width, height, scale = tonumber(width) or 1024, tonumber(height) or 768, tonumber(scale) or 1
    if scale <= 0 then scale = 1 end
    Trail.legacyHypotenuse = sqrt(width * width + height * height) * scale
    if Trail.legacyHypotenuse <= 0 then Trail.legacyHypotenuse = 1 end
end
Trail.RefreshLegacyHypotenuse = RefreshLegacyHypotenuse
RefreshLegacyHypotenuse()

for i = 1, 3 do
    local model = CreateFrame("Model", "CursorCastFXLegacyModelTrail" .. tostring(i), legacyRoot)
    model:SetAllPoints(nil)
    model:SetFrameStrata(i == 1 and "TOOLTIP" or "FULLSCREEN_DIALOG")
    model:EnableMouse(false)
    model:Hide()
    if model.SetLight then
        pcall(model.SetLight, model, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)
    end
    model.X = 0
    model.Y = 0
    Trail.models[i] = model
end

legacyRoot:SetScript("OnShow", function()
    for _, model in ipairs(Trail.models) do
        local path = model.GetModel and model:GetModel()
        if type(path) == "string" and model.SetModel then
            pcall(model.SetModel, model, path)
        end
    end
end)

legacyRoot:SetScript("OnUpdate", function()
    if not Trail.modelShouldShow then return end
    local x, y = GetCursorPosition()
    x, y = tonumber(x) or 0, tonumber(y) or 0
    local hypotenuse = Trail.legacyHypotenuse or 1
    for _, model in ipairs(Trail.models) do
        if model:IsShown() and model.SetPosition then

            
            pcall(model.SetPosition, model, (x + (model.X or 0)) / hypotenuse, (y + (model.Y or 0)) / hypotenuse, 0)
        end
    end
end)

local legacyEvents = CreateFrame("Frame")
pcall(legacyEvents.RegisterEvent, legacyEvents, "DISPLAY_SIZE_CHANGED")
pcall(legacyEvents.RegisterEvent, legacyEvents, "PLAYER_ENTERING_WORLD")
legacyEvents:SetScript("OnEvent", function()
    RefreshLegacyHypotenuse()
end)

local halo = CreateFrame("Frame", "CursorCastFXCursorHalo", pixelSpace)
halo:SetWidth(2); halo:SetHeight(2); halo:SetFrameStrata("TOOLTIP"); halo:EnableMouse(false); halo:Hide()
Trail.halo = halo
local haloTexture = halo:CreateTexture(nil, "OVERLAY")
haloTexture:SetPoint("CENTER", halo, "CENTER", 0, 0); haloTexture:SetBlendMode("ADD")
Trail.haloTexture = haloTexture
local haloInner = halo:CreateTexture(nil, "OVERLAY")
haloInner:SetPoint("CENTER", halo, "CENTER", 0, 0); haloInner:SetBlendMode("ADD")
Trail.haloInner = haloInner

local function RotateTexture(texture, angle)
    if not texture or not texture.SetTexCoord then return end
    local c, s = cos(angle), sin(angle)
    local function P(x, y)
        x, y = x - 0.5, y - 0.5
        return 0.5 + x * c - y * s, 0.5 + x * s + y * c
    end
    local ulx, uly = P(0, 0)
    local llx, lly = P(0, 1)
    local urx, ury = P(1, 0)
    local lrx, lry = P(1, 1)
    texture:SetTexCoord(ulx, uly, llx, lly, urx, ury, lrx, lry)
end

local function GetTrailCursorPosition()
    local rawX, rawY = GetCursorPosition()
    rawX, rawY = tonumber(rawX) or 0, tonumber(rawY) or 0
    local scale, pixelWidth, pixelHeight, changed = RefreshPixelSpace()

    return rawX, rawY, rawX, rawY, pixelWidth, pixelHeight, scale, pixelWidth, pixelHeight, "pixel", changed
end
Trail.GetCursorPosition = GetTrailCursorPosition

local function HideTextureTrail()
    for _, node in ipairs(Trail.pool) do
        node.texture:Hide()
        if node.anchor then node.anchor:Hide() end
        node.age = 99
    end
    Trail.lastSpawnX, Trail.lastSpawnY = nil, nil
end

local function SetTrailColor(texture, mode, ageRatio, seed, profile)
    if mode == "rainbow" then
        local h = Mod(Trail.rainbowTime * 0.22 + seed * 0.07 - ageRatio * 0.15, 1)
        local sector = floor(h * 6)
        local f = h * 6 - sector
        local q = 1 - f
        if sector == 0 then texture:SetVertexColor(1, f, 0)
        elseif sector == 1 then texture:SetVertexColor(q, 1, 0)
        elseif sector == 2 then texture:SetVertexColor(0, 1, f)
        elseif sector == 3 then texture:SetVertexColor(0, q, 1)
        elseif sector == 4 then texture:SetVertexColor(f, 0, 1)
        else texture:SetVertexColor(1, 0, q) end
    elseif mode == "secondary" then
        local _, _, _, r, g, b = addon:GetColors(false)
        texture:SetVertexColor(r, g, b)
    elseif mode == "white" then
        texture:SetVertexColor(1, 1, 1)
    elseif mode == "custom" then
        local color = profile.trail.customColor or {0.2, 0.8, 1.0}
        texture:SetVertexColor(color[1] or 1, color[2] or 1, color[3] or 1)
    else
        local r, g, b = addon:GetColors(false)
        texture:SetVertexColor(r, g, b)
    end
end

local function AcquireNode(profile)
    local settings = profile.trail
    local length = floor(Clamp(settings.textureLength, 1, #Trail.pool) + 0.5)
    if Trail.nextIndex > length then Trail.nextIndex = 1 end
    local node = Trail.pool[Trail.nextIndex]
    Trail.nextIndex = Trail.nextIndex + 1
    if Trail.nextIndex > length then Trail.nextIndex = 1 end
    return node
end

local function SpawnTextureNode(x, y, profile, directionX, directionY)
    local settings = profile.trail
    local node = AcquireNode(profile)
    local style = settings.textureStyle or "spark"
    node.texture:SetTexture(textureStyles[style] or textureStyles.spark)
    node.texture:SetBlendMode(settings.textureBlend == "BLEND" and "BLEND" or "ADD")
    node.age = 0
    node.life = Clamp(settings.textureLifetime, 0.08, 3.0)
    local variation = Clamp(settings.textureSizeVariation or 0, 0, 0.75)
    local randomScale = 1 + ((random() * 2 - 1) * variation)
    local pixelFactor = Trail.pixelScale or 1
    node.baseSize = Clamp(settings.textureSize, 3, 160) * randomScale * pixelFactor
    node.baseAlpha = Clamp(settings.textureAlpha, 0.05, 1)
    local jitter = Clamp(settings.textureJitter or 0, 0, 80) * pixelFactor
    node.x = x + (random() * 2 - 1) * jitter
    node.y = y + (random() * 2 - 1) * jitter
    node.vx = ((directionX or 0) * 16 + (random() * 2 - 1) * 8) * pixelFactor
    node.vy = ((directionY or 0) * 16 + (random() * 2 - 1) * 8) * pixelFactor
    node.spin = (random() * 2 - 1) * 3.2
    node.angle = random() * pi * 2
    if node.anchor then
        node.anchor:ClearAllPoints()
        node.anchor:SetPoint("CENTER", pixelSpace, "BOTTOMLEFT", node.x, node.y)
        node.anchor:Show()
    end
    node.texture:SetWidth(node.baseSize); node.texture:SetHeight(node.baseSize)
    SetTrailColor(node.texture, settings.textureColor or "theme", 0, node.seed, profile)
    node.texture:SetAlpha(node.baseAlpha)
    node.texture:Show()
end

local function UpdateTextureNodes(elapsed, profile)
    local settings = profile.trail
    local style = settings.textureStyle or "spark"
    local motion = settings.textureMotion or "shrink"
    for _, node in ipairs(Trail.pool) do
        if node.texture:IsShown() then
            node.age = node.age + elapsed
            local ratio = node.age / max(0.001, node.life)
            if ratio >= 1 then
                node.texture:Hide()
                if node.anchor then node.anchor:Hide() end
            else
                local fade = 1 - ratio
                local size = node.baseSize
                if motion == "grow" then
                    size = node.baseSize * (0.55 + ratio * 0.95)
                elseif motion == "float" then
                    size = node.baseSize * (1 - ratio * 0.25)
                    node.y = node.y + elapsed * (16 + node.seed * 0.4)
                    node.x = node.x + sin(node.age * 5 + node.seed) * elapsed * 8
                elseif motion == "drift" then
                    size = node.baseSize * (1 - ratio * 0.35)
                    node.x = node.x + node.vx * elapsed
                    node.y = node.y + node.vy * elapsed
                elseif motion == "pulse" then
                    size = node.baseSize * (0.82 + (sin(node.age * 12 + node.seed) + 1) * 0.16)
                elseif style == "soft" then
                    size = node.baseSize * (0.65 + ratio * 0.75)
                elseif style == "rune" then
                    size = node.baseSize * (1 + ratio * 0.35)
                else
                    size = node.baseSize * (1 - ratio * 0.45)
                end
                if node.anchor then
                    node.anchor:ClearAllPoints()
                    node.anchor:SetPoint("CENTER", pixelSpace, "BOTTOMLEFT", node.x, node.y)
                end
                node.texture:SetWidth(max(1, size)); node.texture:SetHeight(max(1, size))
                node.texture:SetAlpha(node.baseAlpha * fade * fade)
                RotateTexture(node.texture, node.angle + node.age * node.spin)
                SetTrailColor(node.texture, settings.textureColor or "theme", ratio, node.seed, profile)
            end
        end
    end
end

local function CopyLayer(layer)
    local result = {}
    for k, v in pairs(layer) do result[k] = v end
    return result
end

local function ResolveLayers(profile)
    local settings = profile.trail
    local layers = {}
    if settings.modelPreset == "custom" then
        local path1 = tostring(settings.customModelPath1 or ""):gsub("%.mdx$", "")
        local path2 = tostring(settings.customModelPath2 or ""):gsub("%.mdx$", "")
        if path1 ~= "" then
            table.insert(layers, {
                path=path1,
                scale=tonumber(settings.customModelScale1) or 1,
                facing=tonumber(settings.customModelFacing1) or 0,
                x=tonumber(settings.customModelOffsetX1) or 0,
                y=tonumber(settings.customModelOffsetY1) or 0,
            })
        end
        if settings.modelSecondLayer ~= false and path2 ~= "" then
            table.insert(layers, {
                path=path2,
                scale=tonumber(settings.customModelScale2) or 1,
                facing=tonumber(settings.customModelFacing2) or 0,
                x=tonumber(settings.customModelOffsetX2) or 0,
                y=tonumber(settings.customModelOffsetY2) or 0,
                strata="FULLSCREEN_DIALOG",
            })
        end
        return layers
    end
    local preset = modelPresets[settings.modelPreset] or modelPresets.nature
    local paletteName = preset.forcedPalette or settings.modelPalette or "auto"
    if paletteName == "auto" then
        if settings.modelPreset == "energyBeamLong" then paletteName = "blueLong" else paletteName = "blue" end
    end
    local palette = paletteLayers[paletteName]

    for i, source in ipairs(preset.layers or {}) do
        local layer = CopyLayer(source)
        if preset.beam and palette and source.role and palette[source.role] then
            local replacement = palette[source.role]
            layer.path = replacement.path
            layer.scale = replacement.scale
            layer.facing = replacement.facing
            layer.x = replacement.x
            layer.y = replacement.y
        end
        if i == 1 or settings.modelSecondLayer ~= false then
            table.insert(layers, layer)
        end
    end
    return layers
end

local function HideModels()
    for _, model in ipairs(Trail.models) do model:Hide() end
end

local function ShowConfiguredModels()
    for i, model in ipairs(Trail.models) do
        if i <= (Trail.activeModelCount or 0) and model._cfxValid ~= false then model:Show() else model:Hide() end
    end
end

local function ConfigureModels(profile, shouldShow)
    local settings = profile.trail
    Trail.modelShouldShow = settings.modelEnabled and shouldShow ~= false
    if not Trail.modelShouldShow then
        HideModels()
        return
    end

    local layers = ResolveLayers(profile)
    Trail.activeModelCount = #layers
    for i, model in ipairs(Trail.models) do
        local layer = layers[i]
        if layer then
            local path = tostring(layer.path or "")
            if path ~= "" and not path:find("%.mdx$") then path = path .. ".mdx" end
            if model._cfxPath ~= path then
                local ok = path ~= "" and pcall(model.SetModel, model, path)
                if not ok then
                    model._cfxValid = false
                    model:Hide()
                    addon:RecordError("legacy model trail", addon.L("Не удалось загрузить модель ", "Failed to load model ") .. tostring(path))
                else
                    model._cfxValid = true
                    model._cfxPath = path
                end
            end

            local intensity = Clamp(settings.modelIntensity or 1, 0.25, 2.5)
            if model.SetModelScale then
                pcall(model.SetModelScale, model,
                    0.01 * (tonumber(layer.scale) or 1) * Clamp(settings.modelScale, 0.10, 5.00) * intensity)
            end
            if model.SetFacing then
                pcall(model.SetFacing, model, (tonumber(layer.facing) or 0) + (settings.modelFacing or 0))
            end
            if model.SetFrameStrata then
                model:SetFrameStrata(layer.strata or settings.modelStrata or (i == 1 and "TOOLTIP" or "FULLSCREEN_DIALOG"))
            end
            if model.SetAlpha then model:SetAlpha(Clamp(0.45 + intensity * 0.40, 0.25, 1)) end

            model.X = (tonumber(settings.modelOffsetX) or 0) + (tonumber(layer.x) or 0)
            model.Y = (tonumber(settings.modelOffsetY) or 0) + (tonumber(layer.y) or 0)
            model._cfxLayer = layer
            if model._cfxValid ~= false then model:Show() end
        else
            model._cfxLayer = nil
            model:Hide()
        end
    end
    legacyRoot:Show()
end

local function SetModelsVisible(profile, shouldShow)
    local settings = profile.trail
    Trail.modelShouldShow = settings.modelEnabled and shouldShow ~= false
    if not Trail.modelShouldShow then
        HideModels()
        return
    end
    if not Trail.activeModelCount then
        ConfigureModels(profile, true)
    else
        ShowConfiguredModels()
    end
end

local function ConfigureHalo(profile)
    local settings = profile.trail
    if not settings.haloEnabled then halo:Hide(); return end
    local style = settings.haloStyle or "ring"
    if style == "glow" then
        haloTexture:SetTexture(Media("glow.tga")); haloInner:SetTexture(Media("spark.tga"))
    elseif style == "star" then
        haloTexture:SetTexture(Media("burst.tga")); haloInner:SetTexture(Media("glow.tga"))
    elseif style == "rune" then
        haloTexture:SetTexture(Media("ring_inner.tga")); haloInner:SetTexture(Media("ring_outer.tga"))
    else
        haloTexture:SetTexture(Media("ring_outer.tga")); haloInner:SetTexture(Media("glow.tga"))
    end
    local r, g, b, r2, g2, b2 = addon:GetColors(false)
    haloTexture:SetVertexColor(r, g, b); haloInner:SetVertexColor(r2, g2, b2)
    halo:SetFrameStrata(profile.frameStrata or "TOOLTIP")
    halo:Show()
end

local function UpdateHalo(x, y, profile)
    local settings = profile.trail
    if not settings.haloEnabled then if halo:IsShown() then halo:Hide() end; return end
    if profile.hideInMouselook and IsMouselooking and IsMouselooking() then halo:Hide(); return end
    if not halo:IsShown() then ConfigureHalo(profile) end
    halo:ClearAllPoints(); halo:SetPoint("CENTER", pixelSpace, "BOTTOMLEFT", x, y)
    local pulse = 1 + sin(Trail.rainbowTime * 5) * Clamp(settings.haloPulse or 0, 0, 0.5)
    local size = Clamp(settings.haloSize or 44, 8, 220) * pulse * (Trail.pixelScale or 1)
    haloTexture:SetWidth(size); haloTexture:SetHeight(size)
    haloInner:SetWidth(size * 0.62); haloInner:SetHeight(size * 0.62)
    local alpha = Clamp(settings.haloAlpha or 0.55, 0.05, 1)
    haloTexture:SetAlpha(alpha); haloInner:SetAlpha(alpha * 0.45)
    RotateTexture(haloTexture, Trail.rainbowTime * 0.45)
    RotateTexture(haloInner, -Trail.rainbowTime * 0.70)
end

function Trail:StartCalibration()
    local settings = addon:GetProfile().trail
    settings.coordinateMode = "pixel"
    settings.coordinateCalibrated = false
    settings.coordinateScaleX = 1
    settings.coordinateScaleY = 1
    settings.coordinateOffsetX = 0
    settings.coordinateOffsetY = 0
    HideTextureTrail()
    RefreshPixelSpace()
    addon.Chat(addon.L("калибровка больше не требуется: включён физический пиксельный слой", "calibration is no longer required: the physical-pixel layer is enabled"))
end

function Trail:ResetCalibration()
    self:StartCalibration()
end

function Trail:ShowCoordinateStatus()
    local x, y, rawX, rawY, pixelWidth, pixelHeight, scale = GetTrailCursorPosition()
    addon.Chat(string.format(addon.L("след: raw %.1f/%.1f -> pixel %.1f/%.1f", "trail: raw %.1f/%.1f -> pixel %.1f/%.1f"), rawX, rawY, x, y))
    addon.Chat(string.format("pixelSpace %.1fx%.1f; UI effective scale %.6f; effective layer scale 1.000000", pixelWidth, pixelHeight, scale))
    addon.Chat(string.format(addon.L("модельный движок: оригинальный _Cursor; hypotenuse %.6f", "model engine: original _Cursor; hypotenuse %.6f"), Trail.legacyHypotenuse or 0))
end

function Trail:Refresh()
    RefreshPixelSpace()
    RefreshLegacyHypotenuse()
    local profile = addon:GetProfile()
    self.frame:SetFrameStrata(profile.frameStrata or "TOOLTIP")
    for _, node in ipairs(self.pool) do
        if node.anchor and node.anchor.SetFrameStrata then node.anchor:SetFrameStrata(profile.frameStrata or "TOOLTIP") end
    end
    if not profile.trail.textureEnabled then HideTextureTrail() end
    ConfigureModels(profile, true)
    ConfigureHalo(profile)
end

frame:SetScript("OnUpdate", function(_, elapsed)
    local ok, err = xpcall(function()
        local profile = addon:GetProfile()
        local settings = profile.trail
        Trail.rainbowTime = Trail.rainbowTime + elapsed

        local x, y, rawX, rawY, uiWidth, uiHeight, _, _, _, _, pixelSpaceChanged = GetTrailCursorPosition()
        local blocked = profile.hideInMouselook and IsMouselooking and IsMouselooking()

        
        if pixelSpaceChanged or (Trail.lastUIWidth and (math.abs(uiWidth - Trail.lastUIWidth) > 0.5 or math.abs(uiHeight - Trail.lastUIHeight) > 0.5)) then
            HideTextureTrail()
            Trail.lastRawX, Trail.lastRawY = nil, nil
        end
        Trail.lastUIWidth, Trail.lastUIHeight = uiWidth, uiHeight
        local moving = true
        local directionX, directionY = 0, 0
        if Trail.lastRawX then
            local dx, dy = rawX - Trail.lastRawX, rawY - Trail.lastRawY
            local distanceSq = dx * dx + dy * dy
            moving = distanceSq > 1
            if moving and distanceSq > 0 then
                local length = sqrt(distanceSq)
                directionX, directionY = dx / length, dy / length
            end
        end
        Trail.lastRawX, Trail.lastRawY = rawX, rawY
        if moving then Trail.idleTime = 0 else Trail.idleTime = Trail.idleTime + elapsed end

        if settings.textureEnabled and not blocked then
            UpdateTextureNodes(elapsed, profile)
            Trail.elapsedSinceSpawn = Trail.elapsedSinceSpawn + elapsed
            local shouldSpawn = not settings.onlyWhileMoving or moving
            if shouldSpawn then
                local spacing = Clamp(settings.textureSpacing, 1, 80) * (Trail.pixelScale or 1)
                local distanceOK = true
                if Trail.lastSpawnX then
                    local dx, dy = x - Trail.lastSpawnX, y - Trail.lastSpawnY
                    distanceOK = (dx * dx + dy * dy) >= spacing * spacing
                end
                if distanceOK or Trail.elapsedSinceSpawn >= 0.06 then
                    if settings.textureDouble then
                        local offset = Clamp(settings.textureSize, 3, 160) * 0.24 * (Trail.pixelScale or 1)
                        local px, py = -directionY * offset, directionX * offset
                        SpawnTextureNode(x + px, y + py, profile, directionX, directionY)
                        SpawnTextureNode(x - px, y - py, profile, directionX, directionY)
                    else
                        SpawnTextureNode(x, y, profile, directionX, directionY)
                    end
                    Trail.lastSpawnX, Trail.lastSpawnY = x, y
                    Trail.elapsedSinceSpawn = 0
                end
            end
        elseif settings.textureEnabled and blocked then
            HideTextureTrail()
        end

        local showModels = not blocked
        if settings.modelOnlyWhileMoving then
            showModels = showModels and (moving or Trail.idleTime < Clamp(settings.modelIdleDelay or 0.18, 0.02, 2.0))
        end
        SetModelsVisible(profile, showModels)
        UpdateHalo(x, y, profile)
    end, addon.ErrorHandler)
    if not ok then
        addon:RecordError("trail OnUpdate", err)
        frame:SetScript("OnUpdate", nil)
    end
end)

Trail:Refresh()
