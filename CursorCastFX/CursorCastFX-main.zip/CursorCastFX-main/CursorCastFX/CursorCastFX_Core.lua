local ADDON_NAME = "CursorCastFX"
local addon = _G.CursorCastFX or {}
_G.CursorCastFX = addon

local detectedLocale = GetLocale and GetLocale() or "enUS"
local savedLanguage = CursorCastFXLanguage or (type(CursorCastFXDB) == "table" and CursorCastFXDB.language) or "auto"
if savedLanguage ~= "ru" and savedLanguage ~= "en" then savedLanguage = "auto" end
addon.language = savedLanguage
addon.locale = detectedLocale
addon.isRussian = savedLanguage == "ru" or (savedLanguage == "auto" and detectedLocale == "ruRU")
function addon.L(ru, en)
    if addon.isRussian then return ru end
    return en or ru
end

function addon:GetLanguage()
    local db = self:EnsureDB()
    return db.language or "auto"
end

function addon:SetLanguage(language)
    language = string.lower(tostring(language or "auto"))
    if language == "russian" or language == "ruru" then language = "ru" end
    if language == "english" or language == "enus" then language = "en" end
    if language ~= "auto" and language ~= "ru" and language ~= "en" then return false end
    local db = self:EnsureDB()
    db.language = language
    CursorCastFXLanguage = language
    self.language = language
    self.isRussian = language == "ru" or (language == "auto" and self.locale == "ruRU")
    return true
end

addon.name = ADDON_NAME
addon.version = "1.0.2"
addon.author = "pahro318"
addon.website = "https://github.com/pahro318"
addon.walletNetwork = "USDT (TRC20)"
addon.walletAddress = "TBUEo5TBGR9Uxpc4P65KBUAjeNXSg62aat"
addon.ready = false
addon.errors = addon.errors or {}
addon.pendingMessages = addon.pendingMessages or {}
addon.modules = addon.modules or {}

local unpack = unpack
local pairs = pairs
local ipairs = ipairs
local tostring = tostring
local tonumber = tonumber
local type = type
local floor = math.floor
local sin = math.sin
local cos = math.cos
local max = math.max
local min = math.min
local pi = math.pi

local function Chat(message, r, g, b)
    message = tostring(message or "")
    if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
        DEFAULT_CHAT_FRAME:AddMessage("|cff55ff88CursorCastFX:|r " .. message, r or 1, g or 1, b or 1)
    else
        table.insert(addon.pendingMessages, message)
    end
end
addon.Chat = Chat

local function FlushMessages()
    if not DEFAULT_CHAT_FRAME or not DEFAULT_CHAT_FRAME.AddMessage then return end
    for _, message in ipairs(addon.pendingMessages) do
        DEFAULT_CHAT_FRAME:AddMessage("|cff55ff88CursorCastFX:|r " .. tostring(message))
    end
    addon.pendingMessages = {}
end

local function ErrorHandler(err)
    local text = tostring(err)
    if debugstack then
        text = text .. "\n" .. tostring(debugstack(2, 10, 10))
    end
    return text
end
addon.ErrorHandler = ErrorHandler

function addon:RecordError(where, err)
    local item = tostring(where or "unknown") .. ": " .. tostring(err or "unknown error")
    table.insert(self.errors, item)
    Chat(addon.L("|cffff5555ошибка|r ", "|cffff5555error|r ") .. item)
end

local function Clamp(value, low, high)
    value = tonumber(value) or low
    if value < low then return low end
    if value > high then return high end
    return value
end
addon.Clamp = Clamp

local function Mod(value, divisor)
    value = tonumber(value) or 0
    divisor = tonumber(divisor) or 1
    if divisor == 0 then return 0 end
    return value - floor(value / divisor) * divisor
end
addon.Mod = Mod

local function DeepCopy(source)
    if type(source) ~= "table" then return source end
    local destination = {}
    for key, value in pairs(source) do
        destination[DeepCopy(key)] = DeepCopy(value)
    end
    return destination
end
addon.DeepCopy = DeepCopy

local function MergeDefaults(destination, source)
    if type(destination) ~= "table" then destination = {} end
    for key, value in pairs(source) do
        if destination[key] == nil then
            destination[key] = DeepCopy(value)
        elseif type(value) == "table" and type(destination[key]) == "table" then
            MergeDefaults(destination[key], value)
        end
    end
    return destination
end
addon.MergeDefaults = MergeDefaults

local function Media(name)
    return "Interface\\AddOns\\CursorCastFX\\Media\\" .. name
end
addon.Media = Media

local themes = {
    nature = { primary = {0.18, 1.00, 0.38}, secondary = {0.92, 0.82, 0.18} },
    arcane = { primary = {0.62, 0.30, 1.00}, secondary = {0.18, 0.82, 1.00} },
    frost  = { primary = {0.20, 0.78, 1.00}, secondary = {0.78, 0.96, 1.00} },
    fire   = { primary = {1.00, 0.22, 0.04}, secondary = {1.00, 0.78, 0.08} },
    holy   = { primary = {1.00, 0.86, 0.22}, secondary = {1.00, 1.00, 0.80} },
    shadow = { primary = {0.62, 0.18, 0.92}, secondary = {0.96, 0.14, 0.62} },
    blood  = { primary = {0.95, 0.05, 0.08}, secondary = {0.50, 0.01, 0.02} },
    storm  = { primary = {0.08, 0.62, 1.00}, secondary = {0.72, 0.92, 1.00} },
    poison = { primary = {0.48, 1.00, 0.08}, secondary = {0.72, 0.18, 1.00} },
    steel  = { primary = {0.76, 0.80, 0.86}, secondary = {1.00, 0.42, 0.08} },
}
addon.themes = themes

local classThemes = {
    DRUID = "nature", MAGE = "arcane", DEATHKNIGHT = "frost",
    WARLOCK = "shadow", PRIEST = "holy", PALADIN = "holy",
    SHAMAN = "storm", ROGUE = "poison", WARRIOR = "steel",
    HUNTER = "nature",
}
addon.classThemes = classThemes

local defaultProfile = {
			["elements"] = {
				["glow"] = true,
				["progress"] = true,
				["failureMark"] = true,
				["outerRing"] = true,
				["time"] = false,
				["name"] = false,
				["iconBorder"] = false,
				["particles"] = true,
				["progressSpark"] = true,
				["icon"] = false,
				["innerRing"] = true,
			},
			["primaryColor"] = {
				0.9764705882352941, 
				1, 
				0.8705882352941177, 
			},
			["hideInMouselook"] = true,
			["sizes"] = {
				["nameFont"] = 12,
				["barHeight"] = 12,
				["particle"] = 15,
				["outerRing"] = 126,
				["particleRadius"] = 60,
				["glow"] = 144,
				["timeFont"] = 10,
				["innerRing"] = 92,
				["iconBorder"] = 64,
				["progressSpark"] = 18,
				["icon"] = 50,
				["barWidth"] = 110,
			},
			["theme"] = "auto",
			["smooth"] = false,
			["enabled"] = true,
			["masterScale"] = 0.3,
			["animation"] = {
				["failureStyle"] = "shakeCross",
				["instantStyle"] = "pulse",
				["effectDuration"] = 0.58,
				["castMotion"] = "rotatePulse",
				["particleCount"] = 8,
				["ringSpeed"] = 1,
				["progressStyle"] = "smooth",
				["pulseStrength"] = 0.12,
				["particleStyle"] = "mixed",
				["successStyle"] = "burst",
				["progressPulse"] = 0.12,
				["showInstantSpells"] = false,
				["glowPulse"] = 0.25,
				["particleSpeed"] = 1,
			},
			["alpha"] = 1,
			["positions"] = {
				["barY"] = -72,
				["iconX"] = 0,
				["barX"] = 0,
				["ringX"] = 0,
				["nameY"] = -93,
				["ringY"] = 0,
				["iconY"] = 0,
				["nameX"] = 0,
				["timeX"] = 0,
				["timeY"] = -43,
			},
			["trail"] = {
				["modelEnabled"] = true,
				["modelOnlyWhileMoving"] = false,
				["textureDouble"] = false,
				["textureLifetime"] = 0.45,
				["textureAlpha"] = 0.75,
				["textureStyle"] = "spark",
				["modelIntensity"] = 1.35,
				["haloPulse"] = 0.16,
				["coordinateOffsetX"] = 0,
				["modelOffsetX"] = 0,
				["coordinateOffsetY"] = 0,
				["haloStyle"] = "ring",
				["modelPalette"] = "white",
				["textureColor"] = "theme",
				["modelSecondLayer"] = true,
				["customModelOffsetY1"] = -6,
				["coordinateCalibrated"] = false,
				["textureSpacing"] = 8,
				["haloSize"] = 20,
				["coordinateMode"] = "pixel",
				["customModelOffsetY2"] = -8,
				["textureSizeVariation"] = 0.15,
				["textureEnabled"] = false,
				["customColor"] = {
					0.2, 
					0.8, 
					1, 
				},
				["haloEnabled"] = false,
				["textureSize"] = 20,
				["textureMotion"] = "shrink",
				["modelStrata"] = "TOOLTIP",
				["coordinateScaleX"] = 1,
				["modelOffsetY"] = 0,
				["customModelFacing2"] = 0,
				["textureLength"] = 18,
				["textureJitter"] = 0,
				["customModelOffsetX1"] = 4,
				["customModelOffsetX2"] = 6,
				["onlyWhileMoving"] = true,
				["textureBlend"] = "ADD",
				["coordinateScaleY"] = 1,
				["customModelScale2"] = 1,
				["customModelScale1"] = 1,
				["customModelPath2"] = "spells\\fire_blue_precast_uber_hand",
				["modelIdleDelay"] = 0.18,
				["customModelPath1"] = "spells\\lightning_precast_low_hand",
				["customModelFacing1"] = 0,
				["modelScale"] = 0.75,
				["haloAlpha"] = 0.55,
				["modelPreset"] = "nature",
				["modelFacing"] = 0,
			},
			["offsetX"] = 6,
			["followSpeed"] = 22,
			["useCustomColors"] = false,
			["offsetY"] = -10,
			["secondaryColor"] = {
				0.92, 
				0.82, 
				0.18, 
			},
			["frameStrata"] = "TOOLTIP",
		}

addon.defaultProfile = defaultProfile

local presetPatches = {
    full = {
        elements = { glow=true, outerRing=true, innerRing=true, icon=true, iconBorder=true, progress=true, name=true, time=true, particles=true },
        animation = { castMotion="rotatePulse", particleCount=8, particleStyle="mixed", successStyle="burst", failureStyle="shakeCross" },
    },
    minimal = {
        masterScale = 0.78,
        elements = { glow=false, outerRing=true, innerRing=false, icon=false, iconBorder=false, progress=false, name=false, time=true, particles=false },
        sizes = { outerRing=54, timeFont=10 },
        positions = { timeX=0, timeY=-34 },
        animation = { castMotion="pulse", pulseStrength=0.08, successStyle="expand", failureStyle="redPulse", instantStyle="minimal" },
    },
    clean = {
        masterScale = 0.90,
        elements = { glow=false, outerRing=false, innerRing=false, icon=true, iconBorder=true, progress=true, name=true, time=true, particles=false },
        positions = { barY=-42, nameY=-61, timeY=-28 },
        animation = { castMotion="static", successStyle="flash", failureStyle="cross", instantStyle="flash" },
    },
    rings = {
        masterScale = 0.90,
        elements = { glow=true, outerRing=true, innerRing=true, icon=false, iconBorder=false, progress=false, name=false, time=true, particles=false },
        sizes = { glow=108, outerRing=92, innerRing=66 },
        positions = { timeY=-48 },
        animation = { castMotion="rotate", successStyle="expand", failureStyle="redPulse", instantStyle="pulse" },
    },
    healer = {
        theme = "nature",
        elements = { glow=true, outerRing=true, innerRing=true, icon=true, iconBorder=true, progress=true, name=true, time=true, particles=true },
        animation = { castMotion="rotatePulse", particleStyle="leaves", particleCount=10, successStyle="spark", failureStyle="shakeCross" },
    },
    melee = {
        masterScale = 0.72,
        offsetX = 10, offsetY = -12,
        elements = { glow=true, outerRing=true, innerRing=false, icon=true, iconBorder=false, progress=false, name=false, time=false, particles=false },
        sizes = { glow=76, outerRing=58, icon=30 },
        animation = { castMotion="pulse", pulseStrength=0.08, instantStyle="flash", successStyle="flash", failureStyle="redPulse" },
    },
    cursorOnly = {
        enabled = true,
        elements = { glow=false, outerRing=false, innerRing=false, icon=false, iconBorder=false, progress=false, name=false, time=false, particles=false },
        trail = { textureEnabled=true, textureStyle="spark", textureLength=22, textureLifetime=0.50, textureSize=18, modelEnabled=false },
    },
}
addon.presetPatches = presetPatches

local function ApplyPatch(destination, patch)
    for key, value in pairs(patch) do
        if type(value) == "table" then
            if type(destination[key]) ~= "table" then destination[key] = {} end
            ApplyPatch(destination[key], value)
        else
            destination[key] = value
        end
    end
end
addon.ApplyPatch = ApplyPatch

local function MigrateLegacy(old)
    local profile = DeepCopy(defaultProfile)
    if type(old) ~= "table" then return profile end
    if old.enabled ~= nil then profile.enabled = old.enabled end
    if old.scale then profile.masterScale = old.scale end
    if old.alpha then profile.alpha = old.alpha end
    if old.offsetX then profile.offsetX = old.offsetX end
    if old.offsetY then profile.offsetY = old.offsetY end
    if old.smooth ~= nil then profile.smooth = old.smooth end
    if old.followSpeed then profile.followSpeed = old.followSpeed end
    if old.theme then profile.theme = old.theme end

    if old.showIcon ~= nil then profile.elements.icon = old.showIcon; profile.elements.iconBorder = old.showIcon end
    if old.showProgress ~= nil then profile.elements.progress = old.showProgress end
    if old.showName ~= nil then profile.elements.name = old.showName end
    if old.showTime ~= nil then profile.elements.time = old.showTime end
    if old.particles ~= nil then profile.elements.particles = old.particles end
    if old.particleCount then profile.animation.particleCount = old.particleCount end
    if old.particleSpeed then profile.animation.particleSpeed = old.particleSpeed end

    local ringScale = tonumber(old.ringScale) or 1
    local iconScale = tonumber(old.iconScale) or 1
    local barScale = tonumber(old.barScale) or 1
    local textScale = tonumber(old.textScale) or 1
    local particleScale = tonumber(old.particleScale) or 1
    profile.sizes.glow = profile.sizes.glow * ringScale
    profile.sizes.outerRing = profile.sizes.outerRing * ringScale
    profile.sizes.innerRing = profile.sizes.innerRing * ringScale
    profile.sizes.icon = profile.sizes.icon * iconScale
    profile.sizes.iconBorder = profile.sizes.iconBorder * iconScale
    profile.sizes.barWidth = profile.sizes.barWidth * barScale
    profile.sizes.barHeight = profile.sizes.barHeight * barScale
    profile.sizes.nameFont = profile.sizes.nameFont * textScale
    profile.sizes.timeFont = profile.sizes.timeFont * textScale
    profile.sizes.particle = profile.sizes.particle * particleScale
    return profile
end

function addon:EnsureDB()
    if type(CursorCastFXDB) ~= "table" then CursorCastFXDB = {} end
    if type(CursorCastFXDB.profiles) ~= "table" then
        local legacy = CursorCastFXDB
        CursorCastFXDB = {
            version = 504,
            activeProfile = "Default",
            profiles = { Default = MigrateLegacy(legacy) },
            minimap = { hide = false, angle = 220 },
            language = "auto",
        }
    end
    CursorCastFXDB.version = 504
    CursorCastFXDB.activeProfile = CursorCastFXDB.activeProfile or "Default"
    if CursorCastFXDB.language ~= "ru" and CursorCastFXDB.language ~= "en" then CursorCastFXDB.language = "auto" end

    
    if CursorCastFXDB.profiles["сава"] then
        CursorCastFXDB.profiles.Default = DeepCopy(CursorCastFXDB.profiles["сава"])
        CursorCastFXDB.profiles["сава"] = nil
        CursorCastFXDB.activeProfile = "Default"
    end
    CursorCastFXDB.minimap = MergeDefaults(CursorCastFXDB.minimap, { hide=false, angle=220 })
    if not CursorCastFXDB.profiles[CursorCastFXDB.activeProfile] then
        CursorCastFXDB.activeProfile = "Default"
    end
    if not CursorCastFXDB.profiles.Default then
        CursorCastFXDB.profiles.Default = DeepCopy(defaultProfile)
    end
    for _, profile in pairs(CursorCastFXDB.profiles) do
        MergeDefaults(profile, defaultProfile)

        
        profile.trail.coordinateMode = "pixel"
        profile.trail.coordinateCalibrated = false
        profile.trail.coordinateScaleX = 1
        profile.trail.coordinateScaleY = 1
        profile.trail.coordinateOffsetX = 0
        profile.trail.coordinateOffsetY = 0
    end
    return CursorCastFXDB
end

function addon:GetProfile()
    local db = self:EnsureDB()
    local profile = db.profiles[db.activeProfile]
    MergeDefaults(profile, defaultProfile)
    return profile
end

function addon:GetProfileName()
    return self:EnsureDB().activeProfile
end

function addon:GetProfileNames()
    local names = {}
    for name in pairs(self:EnsureDB().profiles) do table.insert(names, name) end
    table.sort(names)
    return names
end

function addon:SetActiveProfile(name)
    local db = self:EnsureDB()
    if not db.profiles[name] then return false end
    db.activeProfile = name
    self:RefreshAll()
    Chat("профиль: |cffffff88" .. name .. "|r")
    return true
end

function addon:CreateProfile(name)
    name = tostring(name or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if name == "" then return false, "Введите имя профиля" end
    local db = self:EnsureDB()
    if db.profiles[name] then return false, "Профиль уже существует" end
    db.profiles[name] = DeepCopy(self:GetProfile())
    db.activeProfile = name
    self:RefreshAll()
    return true
end

function addon:DeleteProfile(name)
    local db = self:EnsureDB()
    if not db.profiles[name] then return false end
    local count = 0
    for _ in pairs(db.profiles) do count = count + 1 end
    if count <= 1 then return false, "Нельзя удалить последний профиль" end
    db.profiles[name] = nil
    if db.activeProfile == name then
        db.activeProfile = next(db.profiles)
    end
    self:RefreshAll()
    return true
end

function addon:ResetProfile()
    local db = self:EnsureDB()
    db.profiles[db.activeProfile] = DeepCopy(defaultProfile)
    self:RefreshAll()
end

function addon:ApplyPreset(name)
    local patch = presetPatches[name]
    if not patch then return false end
    local profile = self:GetProfile()
    ApplyPatch(profile, patch)
    self:RefreshAll()
    Chat("пресет применён: |cffffff88" .. tostring(name) .. "|r")
    return true
end

local function GetPath(root, path)
    local value = root
    for part in string.gmatch(path, "[^%.]+") do
        if type(value) ~= "table" then return nil end
        value = value[part]
    end
    return value
end

local function SetPath(root, path, newValue)
    local parts = {}
    for part in string.gmatch(path, "[^%.]+") do table.insert(parts, part) end
    local value = root
    for i = 1, #parts - 1 do
        local part = parts[i]
        if type(value[part]) ~= "table" then value[part] = {} end
        value = value[part]
    end
    value[parts[#parts]] = newValue
end

function addon:GetOption(path)
    return GetPath(self:GetProfile(), path)
end

function addon:SetOption(path, value, skipRefresh)
    SetPath(self:GetProfile(), path, value)
    if not skipRefresh then self:RefreshAll() end
end

function addon:GetColors(forceFailure)
    if forceFailure then return 1, 0.05, 0.05, 0.55, 0.01, 0.01 end
    local profile = self:GetProfile()
    if profile.useCustomColors then
        local a = profile.primaryColor or defaultProfile.primaryColor
        local b = profile.secondaryColor or defaultProfile.secondaryColor
        return a[1], a[2], a[3], b[1], b[2], b[3]
    end
    local themeName = profile.theme
    if themeName == "auto" or not themes[themeName] then
        local _, class = UnitClass("player")
        themeName = classThemes[class] or "nature"
    end
    local theme = themes[themeName] or themes.nature
    return theme.primary[1], theme.primary[2], theme.primary[3], theme.secondary[1], theme.secondary[2], theme.secondary[3]
end

local function SetFontStringSize(fontString, fontPath, size, flags)
    if not fontString then return end
    size = Clamp(size, 6, 64)
    if fontString.SetFont and fontPath then
        local ok = pcall(fontString.SetFont, fontString, fontPath, size, flags)
        if ok then return end
    end
    if fontString.SetTextHeight then pcall(fontString.SetTextHeight, fontString, size) end
end

local function RotateTexture(texture, angle)
    if not texture or not texture.SetTexCoord then return end
    local c, s = cos(angle), sin(angle)
    local function P(x, y)
        x, y = x - 0.5, y - 0.5
        return 0.5 + x * c - y * s, 0.5 + x * s + y * c
    end
    local ulx, uly = P(0, 0)
    local llx, lly = P(0, 1)
    local urx, ury = P(1, 0)
    local lrx, lry = P(1, 1)
    texture:SetTexCoord(ulx, uly, llx, lly, urx, ury, lrx, lry)
end

local function SafeRegister(frame, event)
    local ok, err = pcall(frame.RegisterEvent, frame, event)
    if not ok then addon:RecordError("register " .. event, err) end
end

function addon:BuildVisual()
    if self.controller then return end
    local controller = CreateFrame("Frame", "CursorCastFXController", UIParent)
    self.controller = controller

    local root = CreateFrame("Frame", "CursorCastFXVisualRoot", UIParent)
    root:SetWidth(2); root:SetHeight(2)
    root:SetFrameStrata("TOOLTIP")
    root:EnableMouse(false)
    root:Hide()
    controller.root = root

    local glow = root:CreateTexture(nil, "BACKGROUND")
    glow:SetTexture(Media("glow.tga")); glow:SetBlendMode("ADD")
    controller.glow = glow

    local burst = root:CreateTexture(nil, "BACKGROUND")
    burst:SetTexture(Media("burst.tga")); burst:SetBlendMode("ADD"); burst:Hide()
    controller.burst = burst

    local outerRing = root:CreateTexture(nil, "ARTWORK")
    outerRing:SetTexture(Media("ring_outer.tga")); outerRing:SetBlendMode("ADD")
    controller.outerRing = outerRing

    local innerRing = root:CreateTexture(nil, "ARTWORK")
    innerRing:SetTexture(Media("ring_inner.tga")); innerRing:SetBlendMode("ADD")
    controller.innerRing = innerRing

    local iconFrame = CreateFrame("Frame", nil, root)
    iconFrame:SetFrameLevel(root:GetFrameLevel() + 2)
    controller.iconFrame = iconFrame

    local icon = iconFrame:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints(iconFrame); icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    controller.icon = icon

    local iconShade = iconFrame:CreateTexture(nil, "OVERLAY")
    iconShade:SetAllPoints(iconFrame); iconShade:SetTexture(0, 0, 0, 0.10)

    local iconBorder = root:CreateTexture(nil, "OVERLAY")
    iconBorder:SetTexture(Media("icon_border.tga")); iconBorder:SetBlendMode("ADD")
    controller.iconBorder = iconBorder

    local progressBack = CreateFrame("Frame", nil, root)
    controller.progressBack = progressBack
    local progressBackTex = progressBack:CreateTexture(nil, "BACKGROUND")
    progressBackTex:SetAllPoints(progressBack); progressBackTex:SetTexture(Media("bar_back.tga"))

    local progress = CreateFrame("StatusBar", nil, progressBack)
    progress:SetPoint("TOPLEFT", progressBack, "TOPLEFT", 3, -3)
    progress:SetPoint("BOTTOMRIGHT", progressBack, "BOTTOMRIGHT", -3, 3)
    progress:SetStatusBarTexture(Media("bar_fill.tga")); progress:SetMinMaxValues(0, 1); progress:SetValue(0)
    controller.progress = progress

    local progressSpark = progressBack:CreateTexture(nil, "OVERLAY")
    progressSpark:SetTexture(Media("glow.tga")); progressSpark:SetBlendMode("ADD")
    progressSpark:Hide()
    controller.progressSpark = progressSpark
    controller.progressValue = 0

    local castName = root:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    castName:SetJustifyH("CENTER"); castName:SetText(""); castName:SetShadowOffset(1, -1)
    controller.castName = castName
    if castName.GetFont then
        local font, _, flags = castName:GetFont()
        controller.castNameFont = font or STANDARD_TEXT_FONT
        controller.castNameFontFlags = flags
    else
        controller.castNameFont = STANDARD_TEXT_FONT
    end

    local timeText = root:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    timeText:SetJustifyH("CENTER"); timeText:SetText(""); timeText:SetShadowOffset(1, -1)
    controller.timeText = timeText
    if timeText.GetFont then
        local font, _, flags = timeText:GetFont()
        controller.timeTextFont = font or STANDARD_TEXT_FONT
        controller.timeTextFontFlags = flags
    else
        controller.timeTextFont = STANDARD_TEXT_FONT
    end

    local failText = root:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    failText:SetText("X"); failText:SetTextColor(1, 0.08, 0.08)
    if STANDARD_TEXT_FONT then pcall(failText.SetFont, failText, STANDARD_TEXT_FONT, 40, "OUTLINE") end
    failText:Hide(); controller.failText = failText

    controller.particles = {}
    for i = 1, 16 do
        local texture = root:CreateTexture(nil, "OVERLAY")
        texture:SetBlendMode("ADD"); texture:Hide()
        controller.particles[i] = {
            texture = texture,
            angle = (i / 16) * pi * 2,
            speed = 0.55 + Mod(i, 5) * 0.10,
            phase = i * 0.67,
        }
    end

    controller.mode = nil
    controller.animTime = 0
    controller.effectTime = 0
    controller.cursorX = nil
    controller.cursorY = nil
    controller.startTime = nil
    controller.endTime = nil
    controller.channel = false
    controller.stopGrace = nil
    controller.shakeX = 0
    controller.shakeY = 0
    controller.testIndex = 0

    local events = {
        "ADDON_LOADED", "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD",
        "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_SENT", "UNIT_SPELLCAST_SUCCEEDED",
        "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_DELAYED",
        "UNIT_SPELLCAST_CHANNEL_START", "UNIT_SPELLCAST_CHANNEL_STOP", "UNIT_SPELLCAST_CHANNEL_UPDATE",
    }
    for _, event in ipairs(events) do SafeRegister(controller, event) end

    controller:SetScript("OnEvent", function(frame, event, ...)
        local args = { ... }
        local ok, err = xpcall(function() addon:OnEvent(frame, event, unpack(args)) end, ErrorHandler)
        if not ok then addon:RecordError("event " .. tostring(event), err) end
    end)

    controller:SetScript("OnUpdate", function(frame, elapsed)
        local ok, err = xpcall(function() addon:OnUpdate(frame, elapsed) end, ErrorHandler)
        if not ok then
            addon:RecordError("OnUpdate", err)
            frame:SetScript("OnUpdate", nil)
        end
    end)

    self.ready = true
end

local function SetSize(region, width, height)
    if not region then return end
    if region.SetWidth then region:SetWidth(max(1, width)) end
    if region.SetHeight then region:SetHeight(max(1, height or width)) end
end

local function SetCentered(region, root, x, y)
    if not region then return end
    region:ClearAllPoints()
    region:SetPoint("CENTER", root, "CENTER", x, y)
end

function addon:ApplyTheme(forceFailure)
    local c = self.controller
    if not c then return end
    local r, g, b, r2, g2, b2 = self:GetColors(forceFailure)
    c.outerRing:SetVertexColor(r, g, b)
    c.innerRing:SetVertexColor(r2, g2, b2)
    c.iconBorder:SetVertexColor(r, g, b)
    c.glow:SetVertexColor(r, g, b)
    c.burst:SetVertexColor(r2, g2, b2)
    c.progress:SetStatusBarColor(r, g, b)
    if c.progressSpark then c.progressSpark:SetVertexColor(r2, g2, b2) end
    c.castName:SetTextColor(Clamp(r + 0.25, 0, 1), Clamp(g + 0.25, 0, 1), Clamp(b + 0.25, 0, 1))
    for i, particle in ipairs(c.particles) do
        if Mod(i, 2) == 0 then particle.texture:SetVertexColor(r, g, b)
        else particle.texture:SetVertexColor(r2, g2, b2) end
    end
end

function addon:ApplySettings()
    local c = self.controller
    if not c then return end
    local p = self:GetProfile()
    local s = Clamp(p.masterScale, 0.20, 4.00)
    local sizes = p.sizes
    local pos = p.positions
    local elements = p.elements

    c.root:SetFrameStrata(p.frameStrata or "TOOLTIP")
    c.root:SetAlpha(Clamp(p.alpha, 0.05, 1))

    local ringX, ringY = (pos.ringX or 0) * s, (pos.ringY or 0) * s
    SetSize(c.glow, sizes.glow * s); SetCentered(c.glow, c.root, ringX, ringY)
    SetSize(c.burst, sizes.glow * 1.05 * s); SetCentered(c.burst, c.root, ringX, ringY)
    SetSize(c.outerRing, sizes.outerRing * s); SetCentered(c.outerRing, c.root, ringX, ringY)
    SetSize(c.innerRing, sizes.innerRing * s); SetCentered(c.innerRing, c.root, ringX, ringY)

    SetSize(c.iconFrame, sizes.icon * s); SetCentered(c.iconFrame, c.root, (pos.iconX or 0) * s, (pos.iconY or 0) * s)
    SetSize(c.iconBorder, sizes.iconBorder * s); SetCentered(c.iconBorder, c.root, (pos.iconX or 0) * s, (pos.iconY or 0) * s)

    local barWidth = max(12, sizes.barWidth * s)
    local barHeight = max(6, sizes.barHeight * s)
    SetSize(c.progressBack, barWidth, barHeight)
    SetCentered(c.progressBack, c.root, (pos.barX or 0) * s, (pos.barY or 0) * s)
    local barInset = min(3, max(1, floor(barHeight * 0.18 + 0.5)))
    c.progress:ClearAllPoints()
    c.progress:SetPoint("TOPLEFT", c.progressBack, "TOPLEFT", barInset, -barInset)
    c.progress:SetPoint("BOTTOMRIGHT", c.progressBack, "BOTTOMRIGHT", -barInset, barInset)
    c.progressBarWidth = max(1, barWidth - barInset * 2)
    c.progressBarHeight = max(1, barHeight - barInset * 2)
    if c.progressSpark then
        SetSize(c.progressSpark, max(4, sizes.progressSpark * s), max(4, sizes.progressSpark * s))
    end

    SetFontStringSize(c.castName, c.castNameFont, sizes.nameFont * s, c.castNameFontFlags)
    c.castName:SetWidth(max(80, 230 * s)); SetCentered(c.castName, c.root, (pos.nameX or 0) * s, (pos.nameY or 0) * s)
    SetFontStringSize(c.timeText, c.timeTextFont, sizes.timeFont * s, c.timeTextFontFlags)
    c.timeText:SetWidth(max(40, 100 * s)); SetCentered(c.timeText, c.root, (pos.timeX or 0) * s, (pos.timeY or 0) * s)
    SetCentered(c.failText, c.root, ringX, ringY)

    if elements.glow then c.glow:Show() else c.glow:Hide() end
    if elements.outerRing then c.outerRing:Show() else c.outerRing:Hide() end
    if elements.innerRing then c.innerRing:Show() else c.innerRing:Hide() end
    if elements.icon then c.iconFrame:Show() else c.iconFrame:Hide() end
    if elements.iconBorder then c.iconBorder:Show() else c.iconBorder:Hide() end
    if elements.progress then c.progressBack:Show() else c.progressBack:Hide() end
    if c.progressSpark then
        if elements.progress and elements.progressSpark and (c.mode == "cast" or c.mode == "channel") then c.progressSpark:Show() else c.progressSpark:Hide() end
    end
    if elements.name then c.castName:Show() else c.castName:Hide() end
    if elements.time then c.timeText:Show() else c.timeText:Hide() end

    local particleStyle = p.animation.particleStyle or "mixed"
    for i, particle in ipairs(c.particles) do
        if particleStyle == "leaves" then
            particle.texture:SetTexture(Media("leaf.tga"))
        elseif particleStyle == "sparks" then
            particle.texture:SetTexture(Media("spark.tga"))
        elseif particleStyle == "soft" then
            particle.texture:SetTexture(Media("glow.tga"))
        else
            particle.texture:SetTexture(Mod(i, 2) == 0 and Media("leaf.tga") or Media("spark.tga"))
        end
        local base = sizes.particle * s
        if particleStyle == "soft" then base = base * 1.55 end
        SetSize(particle.texture, base)
    end

    self:ApplyTheme(false)
    self:ShowParticles(c.root:IsShown())
end

function addon:ShowParticles(show)
    local c = self.controller
    if not c then return end
    local p = self:GetProfile()
    local count = floor(Clamp(p.animation.particleCount, 0, 16) + 0.5)
    for i, particle in ipairs(c.particles) do
        if show and p.elements.particles and i <= count then particle.texture:Show() else particle.texture:Hide() end
    end
end

function addon:ResetVisualState()
    local c = self.controller
    if not c then return end
    local p = self:GetProfile()
    self:ApplySettings()
    c.root:SetAlpha(Clamp(p.alpha, 0.05, 1))
    c.glow:SetAlpha(0.65)
    c.outerRing:SetAlpha(1)
    c.innerRing:SetAlpha(0.92)
    c.icon:SetAlpha(1); c.iconBorder:SetAlpha(1); c.progress:SetAlpha(1)
    if c.progressSpark then c.progressSpark:SetAlpha(1); c.progressSpark:Hide() end
    c.castName:SetAlpha(1); c.timeText:SetAlpha(1)
    c.failText:SetAlpha(1); c.failText:Hide()
    c.burst:SetAlpha(0); c.burst:Hide()
    c.shakeX, c.shakeY = 0, 0
    c.effectTime, c.animTime = 0, 0
    RotateTexture(c.outerRing, 0); RotateTexture(c.innerRing, 0)
end

function addon:SetSpellVisual(name, texture)
    local c = self.controller
    if not c then return end
    c.castName:SetText(name or "Заклинание")
    c.icon:SetTexture(texture or "Interface\\Icons\\INV_Misc_QuestionMark")
end

function addon:GetCastInfo(channel)
    local name, rank, displayName, texture, startMS, endMS
    if channel then
        name, rank, displayName, texture, startMS, endMS = UnitChannelInfo("player")
    else
        name, rank, displayName, texture, startMS, endMS = UnitCastingInfo("player")
    end
    if not name or not startMS or not endMS then return nil end
    return name, texture, startMS / 1000, endMS / 1000
end

local function ResolveEventSpell(...)
    local args = { ... }

    

    for i = 2, #args do
        if type(args[i]) == "string" and args[i] ~= "" then
            local n, _, texture = GetSpellInfo(args[i])
            if n then return n, texture end
        end
    end
    for i = 2, #args do
        if type(args[i]) == "number" then
            local n, _, texture = GetSpellInfo(args[i])
            if n then return n, texture end
        end
    end
    return nil, nil
end

local lastSentSpell, lastSentTexture, lastSentAt

function addon:StartCast(channel, fallbackName)
    local p = self:GetProfile()
    if not p.enabled or not self.controller then return end
    local name, texture, startTime, endTime = self:GetCastInfo(channel)

    
    if not name then return end
    local c = self.controller
    self:ResetVisualState(); self:SetSpellVisual(name, texture)
    c.mode = channel and "channel" or "cast"
    c.channel = channel and true or false
    c.startTime, c.endTime = startTime, endTime
    c.stopGrace = nil
    c.progressValue = channel and 1 or 0
    c.progress:SetMinMaxValues(0, 1); c.progress:SetValue(c.progressValue)
    c.root:Show(); self:ShowParticles(true)
    if c.progressSpark and p.elements.progress and p.elements.progressSpark then c.progressSpark:Show() end
end

function addon:UpdateCastInfo(channel)
    local c = self.controller
    if not c then return end
    local name, texture, startTime, endTime = self:GetCastInfo(channel)
    if name then
        c.startTime, c.endTime = startTime, endTime
        self:SetSpellVisual(name, texture)
    end
end

function addon:InstantSpell(name, texture)
    local p = self:GetProfile()

    
    if not p.enabled or not p.animation.showInstantSpells or p.animation.instantStyle == "none" then return end
    local c = self.controller
    self:ResetVisualState(); self:SetSpellVisual(name, texture)
    c.mode = "instant"; c.effectTime = 0; c.root:Show(); self:ShowParticles(true)
    if c.progressSpark then c.progressSpark:Hide() end
    if p.animation.instantStyle == "flash" then c.burst:Show(); c.burst:SetAlpha(0.70) end
end

function addon:Success()
    local p = self:GetProfile()
    local c = self.controller
    if not c then return end
    if p.animation.successStyle == "none" then self:HideEffect(); return end
    c.mode = "success"; c.effectTime = 0; c.stopGrace = nil; c.root:Show(); self:ShowParticles(true)
    if c.progressSpark then c.progressSpark:Hide() end
    if p.animation.successStyle == "burst" or p.animation.successStyle == "spark" or p.animation.successStyle == "flash" then
        c.burst:Show(); c.burst:SetAlpha(0.85)
    end
end

function addon:Failure()
    local p = self:GetProfile()
    local c = self.controller
    if not c then return end
    if p.animation.failureStyle == "none" then self:HideEffect(); return end
    c.mode = "failure"; c.effectTime = 0; c.stopGrace = nil; c.root:Show()
    if c.progressSpark then c.progressSpark:Hide() end
    self:ApplyTheme(true)
    if p.elements.failureMark and (p.animation.failureStyle == "cross" or p.animation.failureStyle == "shakeCross") then c.failText:Show() end
    self:ShowParticles(false)
end

function addon:HideEffect()
    local c = self.controller
    if not c then return end
    c.mode = nil; c.startTime = nil; c.endTime = nil; c.stopGrace = nil
    c.effectTime = 0; c.shakeX = 0; c.shakeY = 0
    c.root:Hide(); c.failText:Hide(); c.burst:Hide(); if c.progressSpark then c.progressSpark:Hide() end; self:ShowParticles(false)
end

function addon:GetCursorUIPosition()
    local x, y = GetCursorPosition()
    local scale = 1
    if UIParent and UIParent.GetEffectiveScale then scale = UIParent:GetEffectiveScale()
    elseif UIParent and UIParent.GetScale then scale = UIParent:GetScale() end
    if not scale or scale == 0 then scale = 1 end
    return x / scale, y / scale, x, y, scale
end

function addon:UpdateCursor(c, elapsed)
    local p = self:GetProfile()
    local x, y = self:GetCursorUIPosition()
    x = x + (p.offsetX or 0)
    y = y + (p.offsetY or 0)
    if not c.cursorX or not p.smooth then
        c.cursorX, c.cursorY = x, y
    else
        local factor = Clamp(elapsed * Clamp(p.followSpeed, 1, 60), 0, 1)
        c.cursorX = c.cursorX + (x - c.cursorX) * factor
        c.cursorY = c.cursorY + (y - c.cursorY) * factor
    end
    c.root:ClearAllPoints()
    c.root:SetPoint("CENTER", UIParent, "BOTTOMLEFT", c.cursorX + (c.shakeX or 0), c.cursorY + (c.shakeY or 0))
end

function addon:UpdateParticles(c)
    local p = self:GetProfile()
    if not p.elements.particles then return end
    local s = Clamp(p.masterScale, 0.2, 4)
    local speed = Clamp(p.animation.particleSpeed, 0.1, 5)
    if c.mode == "success" or c.mode == "instant" then speed = speed * 2.1 end
    local centerX = (p.positions.ringX or 0) * s
    local centerY = (p.positions.ringY or 0) * s
    local radiusBase = Clamp(p.sizes.particleRadius, 5, 250) * s
    for i, particle in ipairs(c.particles) do
        if particle.texture:IsShown() then
            local direction = Mod(i, 2) == 0 and 1 or -1
            local angle = particle.angle + c.animTime * particle.speed * direction * speed
            local pulse = sin(c.animTime * 3.2 + particle.phase)
            local radius = radiusBase + pulse * 4 * s
            particle.texture:ClearAllPoints()
            particle.texture:SetPoint("CENTER", c.root, "CENTER", centerX + cos(angle) * radius, centerY + sin(angle) * radius)
            particle.texture:SetAlpha(Clamp(0.40 + (pulse + 1) * 0.20, 0, 1))
        end
    end
end

function addon:UpdateCast(c, now, elapsed)
    if not c.startTime or not c.endTime then return end
    local p = self:GetProfile()
    local duration = max(0.001, c.endTime - c.startTime)
    local remaining = max(0, c.endTime - now)
    local target
    if c.mode == "channel" then target = remaining / duration else target = 1 - remaining / duration end
    target = Clamp(target, 0, 1)

    local style = p.animation.progressStyle or "smooth"
    if style == "smooth" then
        local current = tonumber(c.progressValue) or target
        local factor = Clamp((elapsed or 0.016) * 18, 0, 1)
        current = current + (target - current) * factor
        if math.abs(target - current) < 0.002 then current = target end
        c.progressValue = current
    else
        c.progressValue = target
    end
    c.progress:SetValue(c.progressValue)

    if style == "pulse" then
        local pulse = 0.82 + (sin(c.animTime * 9) + 1) * 0.09
        c.progress:SetAlpha(pulse)
    else
        c.progress:SetAlpha(1)
    end

    if c.progressSpark then
        local showSpark = p.elements.progress and p.elements.progressSpark and c.progressBack:IsShown()
        if showSpark then
            local usable = c.progressBarWidth or 1
            local x = -usable * 0.5 + usable * c.progressValue
            c.progressSpark:ClearAllPoints()
            c.progressSpark:SetPoint("CENTER", c.progress, "CENTER", x, 0)
            local sparkPulse = 0.65 + (sin(c.animTime * 14) + 1) * Clamp(p.animation.progressPulse or 0.12, 0, 0.5)
            c.progressSpark:SetAlpha(Clamp(sparkPulse, 0, 1))
            c.progressSpark:Show()
        else
            c.progressSpark:Hide()
        end
    end
    c.timeText:SetText(string.format("%.1f", remaining))
end

function addon:UpdateCastMotion(c)
    local p = self:GetProfile()
    local motion = p.animation.castMotion or "static"
    local speed = Clamp(p.animation.ringSpeed, -5, 5)
    if motion == "rotate" or motion == "rotatePulse" then
        RotateTexture(c.outerRing, c.animTime * speed)
        RotateTexture(c.innerRing, -c.animTime * speed * 0.72)
    end
    if motion == "pulse" or motion == "rotatePulse" then
        local pulse = (sin(c.animTime * 4.0) + 1) * 0.5
        local strength = Clamp(p.animation.pulseStrength, 0, 0.8)
        c.outerRing:SetAlpha(Clamp(0.68 + pulse * strength, 0, 1))
        c.innerRing:SetAlpha(Clamp(0.55 + (1 - pulse) * strength, 0, 1))
        c.glow:SetAlpha(Clamp(0.35 + pulse * Clamp(p.animation.glowPulse, 0, 1), 0, 1))
    else
        c.outerRing:SetAlpha(1); c.innerRing:SetAlpha(0.92); c.glow:SetAlpha(0.62)
    end
end

function addon:UpdateOutcome(c, elapsed)
    local p = self:GetProfile()
    local duration = Clamp(p.animation.effectDuration, 0.15, 2.0)
    c.effectTime = c.effectTime + elapsed
    local t = Clamp(c.effectTime / duration, 0, 1)
    local fade = 1 - t
    local s = Clamp(p.masterScale, 0.2, 4)
    local ringX, ringY = (p.positions.ringX or 0) * s, (p.positions.ringY or 0) * s

    if c.mode == "success" then
        local style = p.animation.successStyle
        if style == "burst" or style == "spark" then
            c.burst:SetAlpha(fade * 0.85)
            SetSize(c.burst, p.sizes.glow * s * (1.0 + t * 0.65)); SetCentered(c.burst, c.root, ringX, ringY)
        elseif style == "flash" then
            c.burst:SetAlpha(fade); c.root:SetAlpha(Clamp(p.alpha, 0.05, 1) * fade)
        elseif style == "expand" then
            SetSize(c.outerRing, p.sizes.outerRing * s * (1 + t * 0.75)); SetCentered(c.outerRing, c.root, ringX, ringY)
            SetSize(c.innerRing, p.sizes.innerRing * s * (1 + t * 0.45)); SetCentered(c.innerRing, c.root, ringX, ringY)
            c.outerRing:SetAlpha(fade); c.innerRing:SetAlpha(fade)
        end
        c.glow:SetAlpha(fade * 0.70)
    elseif c.mode == "instant" then
        local style = p.animation.instantStyle
        if style == "flash" then
            c.burst:SetAlpha(fade * 0.75)
        elseif style == "minimal" then
            c.outerRing:SetAlpha(fade)
        else
            local pulse = 1 + sin(t * pi) * 0.30
            SetSize(c.outerRing, p.sizes.outerRing * s * pulse); SetCentered(c.outerRing, c.root, ringX, ringY)
            c.outerRing:SetAlpha(fade)
            c.glow:SetAlpha(fade * 0.65)
        end
    elseif c.mode == "failure" then
        local style = p.animation.failureStyle
        if style == "shake" or style == "shakeCross" then
            c.shakeX = sin(c.effectTime * 55) * 7 * fade
        else
            c.shakeX = 0
        end
        if style == "redPulse" then
            local pulse = 1 + sin(t * pi) * 0.25
            SetSize(c.outerRing, p.sizes.outerRing * s * pulse); SetCentered(c.outerRing, c.root, ringX, ringY)
        end
        c.root:SetAlpha(Clamp(p.alpha, 0.05, 1) * fade)
        c.failText:SetAlpha(fade)
    end
    if t >= 1 then self:HideEffect() end
end

function addon:OnUpdate(c, elapsed)
    local p = self:GetProfile()
    if p.hideInMouselook and IsMouselooking and IsMouselooking() then
        if c.root:IsShown() then c.root:Hide() end
        return
    elseif c.mode and not c.root:IsShown() then
        c.root:Show()
    end

    if c.root:IsShown() then
        c.animTime = c.animTime + elapsed
        self:UpdateCursor(c, elapsed)
        self:UpdateParticles(c)
        if c.mode == "cast" or c.mode == "channel" then
            self:UpdateCast(c, GetTime(), elapsed)
            self:UpdateCastMotion(c)
            if c.stopGrace then
                c.stopGrace = c.stopGrace - elapsed
                if c.stopGrace <= 0 then self:HideEffect() end
            end
        elseif c.mode == "success" or c.mode == "instant" or c.mode == "failure" then
            self:UpdateOutcome(c, elapsed)
        end
    end
end

function addon:OnEvent(frame, event, ...)
    if event == "ADDON_LOADED" then
        local loaded = ...
        if loaded == ADDON_NAME then
            self:EnsureDB(); self:ApplySettings(); FlushMessages()
        end
        return
    elseif event == "PLAYER_LOGIN" then
        self:EnsureDB(); self:ApplySettings(); FlushMessages()
        if not self.authorMessageShown then
            self.authorMessageShown = true
            Chat("|cffb8ffd0Автор:|r pahro318  |cff7fbfffGitHub:|r https://github.com/pahro318")
        end
        return
    elseif event == "PLAYER_ENTERING_WORLD" then
        self:EnsureDB(); self:ApplySettings(); FlushMessages()
        return
    end

    local unit = ...
    if unit ~= "player" then return end
    local spellName, texture = ResolveEventSpell(...)

    if event == "UNIT_SPELLCAST_SENT" then
        if spellName then
            lastSentSpell, lastSentTexture, lastSentAt = spellName, texture, GetTime()
        end
    elseif event == "UNIT_SPELLCAST_START" then
        self:StartCast(false, spellName)
    elseif event == "UNIT_SPELLCAST_CHANNEL_START" then
        self:StartCast(true, spellName)
    elseif event == "UNIT_SPELLCAST_DELAYED" then
        self:UpdateCastInfo(false)
    elseif event == "UNIT_SPELLCAST_CHANNEL_UPDATE" then
        self:UpdateCastInfo(true)
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        local c = self.controller
        if c and (c.mode == "cast" or c.mode == "channel" or c.stopGrace) then
            self:Success()
        else

            if (not spellName) and lastSentSpell and lastSentAt and GetTime() - lastSentAt < 0.75 then
                spellName, texture = lastSentSpell, lastSentTexture
            end
            self:InstantSpell(spellName, texture)
            lastSentSpell, lastSentTexture, lastSentAt = nil, nil, nil
        end
    elseif event == "UNIT_SPELLCAST_STOP" or event == "UNIT_SPELLCAST_CHANNEL_STOP" then
        local c = self.controller
        if c and (c.mode == "cast" or c.mode == "channel") then c.stopGrace = 0.10 end
    elseif event == "UNIT_SPELLCAST_FAILED" or event == "UNIT_SPELLCAST_INTERRUPTED" then
        self:Failure()
    end
end

function addon:RunTest(mode)
    local c = self.controller
    if not c then return end
    if not mode then
        c.testIndex = Mod((c.testIndex or 0) + 1, 4)
        if c.testIndex == 1 then mode = "cast"
        elseif c.testIndex == 2 then mode = "channel"
        elseif c.testIndex == 3 then mode = "instant"
        else mode = "failure" end
    end
    if mode == "cast" then
        self:ResetVisualState(); self:SetSpellVisual("Тест обычного каста", "Interface\\Icons\\Spell_Nature_StarFall")
        c.mode = "cast"; c.startTime = GetTime(); c.endTime = c.startTime + 2.5; c.progressValue = 0; c.progress:SetValue(0); c.root:Show(); self:ShowParticles(true); if c.progressSpark and self:GetProfile().elements.progressSpark then c.progressSpark:Show() end
    elseif mode == "channel" then
        self:ResetVisualState(); self:SetSpellVisual("Тест поддерживаемого заклинания", "Interface\\Icons\\Spell_Nature_Tranquility")
        c.mode = "channel"; c.startTime = GetTime(); c.endTime = c.startTime + 3.5; c.progressValue = 1; c.progress:SetValue(1); c.root:Show(); self:ShowParticles(true); if c.progressSpark and self:GetProfile().elements.progressSpark then c.progressSpark:Show() end
    elseif mode == "instant" then
        self:InstantSpell("Тест мгновенного заклинания", "Interface\\Icons\\Spell_Nature_Rejuvenation")
    elseif mode == "success" then
        self:ResetVisualState(); self:SetSpellVisual("Успех", "Interface\\Icons\\Spell_Holy_FlashHeal"); c.root:Show(); self:Success()
    elseif mode == "failure" then
        self:ResetVisualState(); self:SetSpellVisual("Прервано", "Interface\\Icons\\Spell_Shadow_Curse"); c.root:Show(); self:Failure()
    end
end

function addon:RefreshAll()
    if self.controller then self:ApplySettings() end
    if self.modules.Trail and self.modules.Trail.Refresh then self.modules.Trail:Refresh() end
    if self.modules.Minimap and self.modules.Minimap.Refresh then self.modules.Minimap:Refresh() end
    if self.Config and self.Config.Refresh then self.Config:Refresh() end
end

function addon:ShowStatus()
    local db = self:EnsureDB()
    Chat("версия |cffffff88" .. self.version .. "|r; профиль |cffffff88" .. tostring(db.activeProfile) .. "|r")
    Chat("ядро: " .. (self.ready and "|cff55ff55готово|r" or "|cffff5555не готово|r") .. "; ошибок: " .. tostring(#self.errors))
    if #self.errors > 0 then Chat("последняя: |cffff7777" .. tostring(self.errors[#self.errors]) .. "|r") end
end

function addon:HandleSlash(message)
    message = tostring(message or "")
    local command, rest = message:match("^(%S*)%s*(.-)$")
    command = string.lower(command or "")
    if command == "" or command == "config" or command == "options" then
        if self.OpenConfig then self:OpenConfig() else Chat("окно настроек ещё не загружено") end
    elseif command == "test" then self:RunTest(rest ~= "" and rest or nil)
    elseif command == "status" then self:ShowStatus()
    elseif command == "lang" or command == "language" then
        if self:SetLanguage(rest) then
            Chat(self.L("Язык сохранён. Перезагрузка интерфейса...", "Language saved. Reloading interface..."))
            ReloadUI()
        else
            Chat(self.L("Использование: /cfx lang auto|ru|en", "Usage: /cfx lang auto|ru|en"))
        end
    elseif command == "reset" then self:ResetProfile(); Chat("текущий профиль сброшен")
    elseif command == "preset" then
        if not self:ApplyPreset(rest) then Chat("пресеты: full, minimal, clean, rings, healer, melee, cursorOnly") end
    elseif command == "trail" then
        local p = self:GetProfile(); p.trail.textureEnabled = not p.trail.textureEnabled; self:RefreshAll()
        Chat("текстурный след: " .. (p.trail.textureEnabled and "включён" or "выключен"))
    elseif command == "modeltrail" then
        local p = self:GetProfile(); p.trail.modelEnabled = not p.trail.modelEnabled; self:RefreshAll()
        Chat("модельный след: " .. (p.trail.modelEnabled and "включён" or "выключен"))
    elseif command == "trailcalibrate" or command == "calibratetrail" then
        local trail = self.modules and self.modules.Trail
        if trail and trail.StartCalibration then trail:StartCalibration()
        else Chat("модуль следа ещё не загружен") end
    elseif command == "trailcoords" or command == "traildebug" then
        local trail = self.modules and self.modules.Trail
        if trail and trail.ShowCoordinateStatus then trail:ShowCoordinateStatus()
        else Chat("модуль следа ещё не загружен") end
    elseif command == "minimap" then
        local db = self:EnsureDB(); db.minimap.hide = not db.minimap.hide; self:RefreshAll()
    elseif command == "hide" then self:HideEffect()
    else
        Chat(addon.L("/cfx config, lang auto|ru|en, test, preset, trail, modeltrail, minimap, status, reset", "/cfx config, lang auto|ru|en, test, preset, trail, modeltrail, minimap, status, reset"))
    end
end

SLASH_CURSORCASTFX1 = "/cfx"
SLASH_CURSORCASTFX2 = "/cursorcastfx"
SlashCmdList["CURSORCASTFX"] = function(message) addon:HandleSlash(message) end

SLASH_CURSORCASTFXLANG1 = "/ccfxlang"
SlashCmdList["CURSORCASTFXLANG"] = function(message)
    if addon:SetLanguage(message) then
        addon.Chat(addon.L("Язык сохранён. Перезагрузка интерфейса...", "Language saved. Reloading interface..."))
        ReloadUI()
    else
        addon.Chat(addon.L("Использование: /ccfxlang auto|ru|en", "Usage: /ccfxlang auto|ru|en"))
    end
end

local ok, err = xpcall(function() addon:BuildVisual() end, ErrorHandler)
if not ok then addon:RecordError("initialization", err) end
