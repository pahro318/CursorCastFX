local addon = _G.CursorCastFX; if not addon then return end
local Suite = addon.suite; if not Suite then return end
local HUD = {}
Suite:RegisterModule("hud", HUD)

local classColors = RAID_CLASS_COLORS or {}
local f = CreateFrame("Frame", "CursorCastFXModernHUD", UIParent)
f:SetWidth(320); f:SetHeight(76); f:SetPoint("CENTER", UIParent, "CENTER", 0, -165); f:SetFrameStrata("MEDIUM")
f:EnableMouse(true); f:SetMovable(true); f:RegisterForDrag("LeftButton")
f:SetScript("OnDragStart", function(self) if not Suite:GetDB().locked then self:StartMoving() end end)
f:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing(); local _,_,_,x,y=self:GetPoint(); local db=Suite:GetDB().hud; db.x=x or 0; db.y=y or -165
end)

local function Bar(name, y)
    local b=CreateFrame("StatusBar", name, f); b:SetPoint("TOP", f, "TOP", 0, y); b:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); b:SetMinMaxValues(0,1); b:SetValue(1)
    b.bg=b:CreateTexture(nil,"BACKGROUND"); b.bg:SetAllPoints(b); b.bg:SetTexture(0.03,0.03,0.03,0.82)
    b.spark=b:CreateTexture(nil,"OVERLAY"); b.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark"); b.spark:SetBlendMode("ADD"); b.spark:SetWidth(18); b.spark:SetPoint("CENTER",b:GetStatusBarTexture(),"RIGHT",0,0)
    b.text=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); b.text:SetPoint("CENTER",b,"CENTER",0,0)
    return b
end
HUD.health=Bar("CursorCastFXHUDHealth",0)
HUD.power=Bar("CursorCastFXHUDPower",-23)
HUD.target=Bar("CursorCastFXHUDTarget",-50)
HUD.target:SetStatusBarColor(0.85,0.15,0.15)

local events=CreateFrame("Frame")
for _,e in ipairs({"PLAYER_ENTERING_WORLD","UNIT_HEALTH","UNIT_MAXHEALTH","UNIT_MANA","UNIT_MAXMANA","UNIT_RAGE","UNIT_ENERGY","UNIT_RUNIC_POWER","UNIT_DISPLAYPOWER","PLAYER_TARGET_CHANGED"}) do events:RegisterEvent(e) end

local function UnitValues(unit)
    local cur,maxv=UnitHealth(unit) or 0,UnitHealthMax(unit) or 1; if maxv<=0 then maxv=1 end
    return cur,maxv
end
function HUD:Update()
    local db=Suite:GetDB().hud; if not db.enabled then f:Hide(); return end
    f:Show()
    local hp,hm=UnitValues("player"); self.health:SetMinMaxValues(0,hm); self.health:SetValue(hp); self.health.text:SetText(string.format("%d%%   %s", math.floor(hp/hm*100+0.5), UnitName("player") or ""))
    local _,class=UnitClass("player"); local c=classColors[class]
    if db.classColor and c then self.health:SetStatusBarColor(c.r,c.g,c.b) else self.health:SetStatusBarColor(0.15,0.85,0.25) end
    local ptype=UnitPowerType("player") or 0; local pc=UnitMana("player") or 0; local pm=UnitManaMax("player") or 1
    if ptype==1 then pc=UnitRage("player") or 0; pm=UnitRageMax and UnitRageMax("player") or 1000
    elseif ptype==3 then pc=UnitEnergy("player") or 0; pm=UnitEnergyMax and UnitEnergyMax("player") or 100
    elseif ptype==6 then pc=UnitRunicPower("player") or 0; pm=UnitRunicPowerMax and UnitRunicPowerMax("player") or 1000 end
    if pm<=0 then pm=1 end
    self.power:SetMinMaxValues(0,pm); self.power:SetValue(pc); self.power.text:SetText(string.format("%d%%",math.floor(pc/pm*100+0.5)))
    if ptype==0 then self.power:SetStatusBarColor(0.15,0.45,1) elseif ptype==1 then self.power:SetStatusBarColor(0.9,0.12,0.08) elseif ptype==3 then self.power:SetStatusBarColor(1,0.82,0.08) else self.power:SetStatusBarColor(0.12,0.75,0.9) end
    if db.showTarget and UnitExists("target") then local th,tm=UnitValues("target"); self.target:Show(); self.target:SetMinMaxValues(0,tm); self.target:SetValue(th); self.target.text:SetText((UnitName("target") or addon.L("Цель", "Target")).."  "..math.floor(th/tm*100+0.5).."%") else self.target:Hide() end
end
function HUD:Apply(db)
    f:SetScale(db.scale or 1); f:SetAlpha(db.alpha or 1); f:ClearAllPoints(); f:SetPoint("CENTER",UIParent,"CENTER",db.x or 0,db.y or -165)
    local w,h=db.width or 290,db.height or 18
    self.health:SetWidth(w);self.health:SetHeight(h);self.power:SetWidth(w);self.power:SetHeight(math.max(8,h-4));self.target:SetWidth(w);self.target:SetHeight(math.max(8,h-4)); self:Update()
end
function HUD:SetLocked(v) f:EnableMouse(not v) end
events:SetScript("OnEvent",function(_,event,unit) if not unit or unit=="player" or unit=="target" then HUD:Update() end end)
