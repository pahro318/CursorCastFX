local addon=_G.CursorCastFX;if not addon then return end
local Suite=addon.suite;if not Suite then return end
local win=CreateFrame("Frame","CursorCastFXSuiteWindow",UIParent);win:SetWidth(460);win:SetHeight(430);win:SetPoint("CENTER");win:SetFrameStrata("DIALOG");win:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",tile=true,tileSize=32,edgeSize=32,insets={left=10,right=10,top=10,bottom=10}});win:Hide();win:SetMovable(true);win:EnableMouse(true);win:RegisterForDrag("LeftButton");win:SetScript("OnDragStart",win.StartMoving);win:SetScript("OnDragStop",win.StopMovingOrSizing)
local title=win:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");title:SetPoint("TOP",0,-18);title:SetText("CursorCastFX Visual Suite 0.6.0")
local close=CreateFrame("Button",nil,win,"UIPanelCloseButton");close:SetPoint("TOPRIGHT",-5,-5)
local desc=win:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");desc:SetPoint("TOPLEFT",28,-52);desc:SetWidth(400);desc:SetJustifyH("LEFT");desc:SetText(addon.L("Модули в стиле актуального WoW. Каждый блок можно включать независимо.", "Modules styled after modern WoW. Each block can be enabled independently."))
local checks={}
local defs={{"hud",addon.L("Современный центральный HUD", "Modern central HUD")},{"procs",addon.L("Экранные эффекты проков", "On-screen proc effects")},{"castbars",addon.L("Касты цели и фокуса", "Target and focus casts")},{"actionFX",addon.L("Свечение готовых кнопок", "Ready-action glow")},{"alerts",addon.L("Экранные предупреждения", "Screen alerts")}}
local y=-95
for _,d in ipairs(defs) do local c=CreateFrame("CheckButton",nil,win,"UICheckButtonTemplate");c:SetPoint("TOPLEFT",26,y);c.text=_G[c:GetName() and c:GetName().."Text" or ""];local fs=win:CreateFontString(nil,"OVERLAY","GameFontNormal");fs:SetPoint("LEFT",c,"RIGHT",2,0);fs:SetText(d[2]);c.label=fs;c.key=d[1];c:SetScript("OnClick",function(self)Suite:GetDB()[self.key].enabled=self:GetChecked() and true or false;Suite:ApplyAll() end);checks[#checks+1]=c;y=y-42 end
local lock=CreateFrame("CheckButton",nil,win,"UICheckButtonTemplate");lock:SetPoint("TOPLEFT",26,y-4);local lfs=win:CreateFontString(nil,"OVERLAY","GameFontNormal");lfs:SetPoint("LEFT",lock,"RIGHT",2,0);lfs:SetText(addon.L("Заблокировать перемещение HUD", "Lock HUD movement"));lock:SetScript("OnClick",function(self)Suite:SetLocked(self:GetChecked()) end)
local test=CreateFrame("Button",nil,win,"UIPanelButtonTemplate");test:SetWidth(170);test:SetHeight(24);test:SetPoint("BOTTOMLEFT",26,28);test:SetText(addon.L("Тест эффектов", "Test effects"));test:SetScript("OnClick",function()if Suite.modules.procs then Suite.modules.procs:Show(addon.L("Тестовый прок", "Test proc"),"Interface\\Icons\\Spell_Nature_Lightning") end end)
local reset=CreateFrame("Button",nil,win,"UIPanelButtonTemplate");reset:SetWidth(170);reset:SetHeight(24);reset:SetPoint("BOTTOMRIGHT",-26,28);reset:SetText(addon.L("Сбросить Suite", "Reset Suite"));reset:SetScript("OnClick",function()Suite:Reset();Suite:OpenConfig() end)
function Suite:OpenConfig() local db=self:GetDB();for _,c in ipairs(checks) do c:SetChecked(db[c.key].enabled) end;lock:SetChecked(db.locked);win:Show() end

local oldHandle=addon.HandleSlash
function addon:HandleSlash(message)
 local cmd=(message or ""):lower():match("^%s*(.-)%s*$")
 if cmd=="suite" or cmd=="visual" or cmd=="retail" then Suite:OpenConfig();return end
 if cmd=="suite reset" then Suite:Reset();addon.Chat(addon.L("Visual Suite сброшен", "Visual Suite reset"));return end
 if oldHandle then return oldHandle(self,message) end
end
