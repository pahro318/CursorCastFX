local addon=_G.CursorCastFX;if not addon then return end
local Suite=addon.suite;if not Suite then return end
local P={};Suite:RegisterModule("procs",P)
local tracked={16870,16886,48108,44401,44544,57761,59578,54149,53817,16246,56453,51124,59052,52437,50227,17941,34936,33151,46916,60503}
local names={};for _,id in ipairs(tracked) do local n=GetSpellInfo(id);if n then names[n]=true end end
local f=CreateFrame("Frame","CursorCastFXProcOverlay",UIParent);f:SetWidth(300);f:SetHeight(180);f:SetPoint("CENTER",0,55);f:SetFrameStrata("HIGH");f:Hide()
local left=f:CreateTexture(nil,"ARTWORK");left:SetTexture("Interface\\Cooldown\\star4");left:SetBlendMode("ADD");left:SetWidth(128);left:SetHeight(128);left:SetPoint("RIGHT",f,"CENTER",-18,0)
local right=f:CreateTexture(nil,"ARTWORK");right:SetTexture("Interface\\Cooldown\\star4");right:SetBlendMode("ADD");right:SetWidth(128);right:SetHeight(128);right:SetPoint("LEFT",f,"CENTER",18,0)
local icon=f:CreateTexture(nil,"OVERLAY");icon:SetWidth(46);icon:SetHeight(46);icon:SetPoint("CENTER")
local text=f:CreateFontString(nil,"OVERLAY","GameFontNormalLarge");text:SetPoint("TOP",icon,"BOTTOM",0,-8)
P.active={};P.t=0;P.showUntil=0
local function FindProc()
    for i=1,40 do local n,_,tex,_,_,dur,exp=UnitBuff("player",i);if not n then break end;if names[n] and not P.active[n] then return n,tex,dur,exp end end
end
function P:Scan()
    local current={};for i=1,40 do local n=UnitBuff("player",i);if not n then break end;current[n]=true end
    local n,tex=FindProc();if n then self:Show(n,tex) end;self.active=current
end
function P:Show(n,tex)
    local db=Suite:GetDB().procs;if not db.enabled then return end
    icon:SetTexture(tex);text:SetText(db.showName and n or "");f:Show();self.t=0;self.showUntil=GetTime()+(db.duration or .45)+1.1
end
function P:Apply(db) f:SetScale(db.scale or 1);f:ClearAllPoints();f:SetPoint("CENTER",UIParent,"CENTER",db.x or 0,db.y or 55);if not db.enabled then f:Hide() end end
local e=CreateFrame("Frame");e:RegisterEvent("UNIT_AURA");e:RegisterEvent("PLAYER_ENTERING_WORLD");e:SetScript("OnEvent",function(_,_,unit) if not unit or unit=="player" then P:Scan() end end)
f:SetScript("OnUpdate",function(_,dt) if not f:IsShown() then return end;P.t=P.t+dt;local pulse=1+0.10*math.sin(P.t*10);left:SetWidth(128*pulse);left:SetHeight(128*pulse);right:SetWidth(128*pulse);right:SetHeight(128*pulse);local a=1;if GetTime()>P.showUntil-.35 then a=math.max(0,(P.showUntil-GetTime())/.35) end;f:SetAlpha(a);if GetTime()>=P.showUntil then f:Hide();f:SetAlpha(1) end end)
