local addon = _G.CursorCastFX
if not addon then return end

local MinimapModule = {}
addon.modules.Minimap = MinimapModule

local sin = math.sin
local cos = math.cos
local pi = math.pi

local function Atan2(y, x)
    if math.atan2 then return math.atan2(y, x) end
    if atan2 then return atan2(y, x) end
    if x > 0 then return math.atan(y / x) end
    if x < 0 and y >= 0 then return math.atan(y / x) + pi end
    if x < 0 and y < 0 then return math.atan(y / x) - pi end
    if x == 0 and y > 0 then return pi / 2 end
    if x == 0 and y < 0 then return -pi / 2 end
    return 0
end

local button = CreateFrame("Button", "CursorCastFXMinimapButton", Minimap)
MinimapModule.button = button
button:SetWidth(32); button:SetHeight(32)
button:SetFrameStrata("MEDIUM")
button:SetFrameLevel((Minimap:GetFrameLevel() or 0) + 8)
button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
button:RegisterForDrag("LeftButton")
button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

local background = button:CreateTexture(nil, "BACKGROUND")
background:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
background:SetWidth(20); background:SetHeight(20); background:SetPoint("CENTER", button, "CENTER", 0, 1)

local icon = button:CreateTexture(nil, "ARTWORK")
icon:SetTexture("Interface\\Icons\\Spell_Nature_StarFall")
icon:SetWidth(18); icon:SetHeight(18); icon:SetPoint("CENTER", button, "CENTER", 0, 1)
icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

local border = button:CreateTexture(nil, "OVERLAY")
border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
border:SetWidth(54); border:SetHeight(54); border:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)

local function PositionButton()
    local db = addon:EnsureDB()
    local angle = tonumber(db.minimap.angle) or 220
    local radians = angle * pi / 180
    local radius = 80
    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", cos(radians) * radius, sin(radians) * radius)
end

button:SetScript("OnEnter", function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("CursorCastFX Studio", 0.35, 1, 0.55)
    GameTooltip:AddLine(addon.L("ЛКМ — открыть настройки", "Left-click — open settings"), 1, 1, 1)
    GameTooltip:AddLine(addon.L("ПКМ — общий тест визуала", "Right-click — test all visuals"), 1, 1, 1)
    GameTooltip:AddLine(addon.L("Перетащи — изменить положение", "Drag — change position"), 0.75, 0.75, 0.75)
    GameTooltip:Show()
end)
button:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)

button:SetScript("OnClick", function(_, mouseButton)
    if mouseButton == "RightButton" then addon:RunTest(); if addon.visualFX then addon.visualFX:Test("all") end
    else addon:OpenConfig() end
end)

button:SetScript("OnDragStart", function(self)
    self.dragging = true
    self:SetScript("OnUpdate", function()
        local cursorX, cursorY = GetCursorPosition()
        local scale = UIParent:GetEffectiveScale()
        cursorX, cursorY = cursorX / scale, cursorY / scale
        local centerX, centerY = Minimap:GetCenter()
        if not centerX or not centerY then return end
        local angle = Atan2(cursorY - centerY, cursorX - centerX) * 180 / pi
        addon:EnsureDB().minimap.angle = angle
        PositionButton()
    end)
end)
button:SetScript("OnDragStop", function(self)
    self.dragging = nil
    self:SetScript("OnUpdate", nil)
end)

function MinimapModule:Refresh()
    local db = addon:EnsureDB()
    PositionButton()
    if db.minimap.hide then button:Hide() else button:Show() end
end

MinimapModule:Refresh()
