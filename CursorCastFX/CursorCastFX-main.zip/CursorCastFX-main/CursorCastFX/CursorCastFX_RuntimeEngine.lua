local addon = _G.CursorCastFX
if not addon then return end

local engine = addon.RuntimeEngine or {}
addon.RuntimeEngine = engine

engine.active = false
engine.stats = engine.stats or {
    wakeups = 0,
    sleeps = 0,
    frames = 0,
    elapsed = 0,
}

local controller = addon.controller
if not controller then return end

local function ErrorHandler(err)
    if addon.ErrorHandler then return addon.ErrorHandler(err) end
    return tostring(err)
end

local function NeedsUpdate()
    local c = addon.controller
    return c and c.mode ~= nil
end

local function Driver(frame, elapsed)
    local stats = engine.stats
    stats.frames = (stats.frames or 0) + 1
    stats.elapsed = (stats.elapsed or 0) + (elapsed or 0)

    local ok, err = xpcall(function()
        addon:OnUpdate(frame, elapsed)
    end, ErrorHandler)

    if not ok then
        if addon.RecordError then addon:RecordError("RuntimeEngine", err) end
        engine:Sleep()
        return
    end

    if not NeedsUpdate() then
        engine:Sleep()
    end
end

function engine:Wake()
    if self.active then return end
    local c = addon.controller
    if not c then return end
    self.active = true
    self.stats.wakeups = (self.stats.wakeups or 0) + 1
    c:SetScript("OnUpdate", Driver)
end

function engine:Sleep()
    if not self.active then return end
    local c = addon.controller
    self.active = false
    self.stats.sleeps = (self.stats.sleeps or 0) + 1
    if c then c:SetScript("OnUpdate", nil) end
end

function engine:IsActive()
    return self.active and true or false
end

function engine:ResetStats()
    self.stats = { wakeups = 0, sleeps = 0, frames = 0, elapsed = 0 }
end

controller:SetScript("OnUpdate", nil)
engine.active = false

local function WrapWake(methodName)
    local original = addon[methodName]
    if type(original) ~= "function" then return end
    addon[methodName] = function(self, ...)
        local results = { original(self, ...) }
        if NeedsUpdate() then engine:Wake() end
        return unpack(results)
    end
end

WrapWake("StartCast")
WrapWake("InstantSpell")
WrapWake("Success")
WrapWake("Failure")

local originalHideEffect = addon.HideEffect
if type(originalHideEffect) == "function" then
    addon.HideEffect = function(self, ...)
        local results = { originalHideEffect(self, ...) }
        if not NeedsUpdate() then engine:Sleep() end
        return unpack(results)
    end
end

SLASH_CCFXENGINE1 = "/ccfxengine"
SlashCmdList.CCFXENGINE = function(msg)
    msg = string.lower(tostring(msg or ""))
    if msg == "reset" then
        engine:ResetStats()
        addon.Chat(addon.L("Runtime Engine: статистика сброшена.", "Runtime Engine: statistics reset."))
        return
    end

    local s = engine.stats
    addon.Chat(string.format(
        "Runtime Engine: %s, wake=%d, sleep=%d, frames=%d, activeTime=%.2fs",
        engine:IsActive() and "ON" or "OFF",
        s.wakeups or 0,
        s.sleeps or 0,
        s.frames or 0,
        s.elapsed or 0
    ))
end
