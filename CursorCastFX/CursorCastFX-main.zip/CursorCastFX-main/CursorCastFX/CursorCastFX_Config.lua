local addon = _G.CursorCastFX
if not addon then return end

local Config = {}
addon.Config = Config

local controls = {}
local pages = {}
local navButtons = {}
local controlID = 0
local selectedPage = 1

local function NextName(prefix)
    controlID = controlID + 1
    return "CursorCastFXStudio" .. prefix .. controlID
end

local function Round(value, step)
    if step >= 1 then return math.floor(value + 0.5) end
    return math.floor(value / step + 0.5) * step
end

local function FormatNumber(value, decimals)
    return string.format("%." .. tostring(decimals or 2) .. "f", value)
end

local frame = CreateFrame("Frame", "CursorCastFXStudioConfig", UIParent)
Config.frame = frame
frame:SetWidth(790); frame:SetHeight(660)
frame:SetPoint("CENTER", UIParent, "CENTER", 0, 10)
frame:SetFrameStrata("DIALOG")
if frame.SetToplevel then frame:SetToplevel(true) end
frame:EnableMouse(true)
frame:SetMovable(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", function(self) self:StartMoving() end)
frame:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
if frame.SetClampedToScreen then frame:SetClampedToScreen(true) end
frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 32, edgeSize = 16,
    insets = { left=4, right=4, top=4, bottom=4 },
})
frame:SetBackdropColor(0.025, 0.035, 0.045, 0.98)
frame:SetBackdropBorderColor(0.18, 0.95, 0.48, 0.85)
frame:Hide()

local topGlow = frame:CreateTexture(nil, "BACKGROUND")
topGlow:SetTexture("Interface\\Buttons\\WHITE8X8")
topGlow:SetPoint("TOPLEFT", frame, "TOPLEFT", 6, -6)
topGlow:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -6, -6)
topGlow:SetHeight(54)
if topGlow.SetGradientAlpha then
    topGlow:SetGradientAlpha("VERTICAL", 0.08, 0.75, 0.28, 0.70, 0.02, 0.08, 0.04, 0.05)
else
    topGlow:SetVertexColor(0.08, 0.75, 0.28, 0.45)
end

local titleIcon = frame:CreateTexture(nil, "ARTWORK")
titleIcon:SetTexture("Interface\\Icons\\Spell_Nature_StarFall")
titleIcon:SetWidth(38); titleIcon:SetHeight(38)
titleIcon:SetPoint("TOPLEFT", frame, "TOPLEFT", 18, -14)
titleIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
title:SetPoint("TOPLEFT", titleIcon, "TOPRIGHT", 10, -2)
title:SetText("CursorCastFX Studio")
title:SetTextColor(0.35, 1.00, 0.58)

local subtitle = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
subtitle:SetText(addon.L("Единый редактор курсора, каста и декоративных боевых эффектов", "Unified editor for cursor, cast and decorative combat effects"))
subtitle:SetTextColor(0.72, 0.80, 0.76)

local authorLine = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
authorLine:SetPoint("TOPLEFT", subtitle, "BOTTOMLEFT", 0, -3)
authorLine:SetText(addon.L("Автор: |cff55ff88pahro318|r   GitHub: |cff7fbfffhttps://github.com/pahro318|r", "Author: |cff55ff88pahro318|r   GitHub: |cff7fbfffhttps://github.com/pahro318|r"))
authorLine:SetTextColor(0.82, 0.86, 0.84)

local supportLine = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
supportLine:SetPoint("TOPLEFT", authorLine, "BOTTOMLEFT", 0, -3)
supportLine:SetText(addon.L("Поддержать проект — |cffffd966USDT (TRC20):|r |cffffffffTBUEo5TBGR9Uxpc4P65KBUAjeNXSg62aat|r", "Support the project — |cffffd966USDT (TRC20):|r |cffffffffTBUEo5TBGR9Uxpc4P65KBUAjeNXSg62aat|r"))
supportLine:SetTextColor(0.82, 0.86, 0.84)

local profileLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
profileLabel:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -48, -22)
profileLabel:SetTextColor(0.65, 1.00, 0.78)

local close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -3, -3)

local leftPanel = CreateFrame("Frame", nil, frame)
leftPanel:SetPoint("TOPLEFT", frame, "TOPLEFT", 12, -88)
leftPanel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 12, 54)
leftPanel:SetWidth(164)
leftPanel:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=10, insets={left=2,right=2,top=2,bottom=2} })
leftPanel:SetBackdropColor(0.02, 0.028, 0.035, 0.92)
leftPanel:SetBackdropBorderColor(0.12, 0.32, 0.22, 0.85)

local contentHost = CreateFrame("Frame", nil, frame)
contentHost:SetPoint("TOPLEFT", leftPanel, "TOPRIGHT", 10, 0)
contentHost:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -14, 54)
contentHost:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=10, insets={left=2,right=2,top=2,bottom=2} })
contentHost:SetBackdropColor(0.018, 0.024, 0.030, 0.88)
contentHost:SetBackdropBorderColor(0.11, 0.26, 0.18, 0.75)

local pageTitle = contentHost:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
pageTitle:SetPoint("TOPLEFT", contentHost, "TOPLEFT", 18, -14)
pageTitle:SetTextColor(0.38, 1.00, 0.60)

local footerLine = frame:CreateTexture(nil, "ARTWORK")
footerLine:SetTexture("Interface\\Buttons\\WHITE8X8")
footerLine:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 12, 49)
footerLine:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 49)
footerLine:SetHeight(1)
footerLine:SetVertexColor(0.18, 0.80, 0.42, 0.45)

local function AddControl(control)
    table.insert(controls, control)
    return control
end

local function MakePage(index, titleText, contentHeight)
    local scrollName = "CursorCastFXStudioConfigPageScroll" .. tostring(index)
    local scroll = CreateFrame("ScrollFrame", scrollName, contentHost, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", contentHost, "TOPLEFT", 10, -46)
    scroll:SetPoint("BOTTOMRIGHT", contentHost, "BOTTOMRIGHT", -30, 10)
    scroll:Hide()

    local content = CreateFrame("Frame", nil, scroll)
    content:SetWidth(548)
    content:SetHeight(contentHeight or 1200)
    scroll:SetScrollChild(content)

    local function ScrollByWheel(self, delta)
        local current = scroll:GetVerticalScroll() or 0
        local range = scroll.GetVerticalScrollRange and scroll:GetVerticalScrollRange() or 0
        local target = current - delta * 58
        if target < 0 then target = 0 end
        if target > range then target = range end
        scroll:SetVerticalScroll(target)
    end
    scroll:EnableMouse(true)
    scroll:EnableMouseWheel(true)
    scroll:SetScript("OnMouseWheel", ScrollByWheel)
    content:EnableMouse(true)
    content:EnableMouseWheel(true)
    content:SetScript("OnMouseWheel", ScrollByWheel)
    scroll:SetScript("OnShow", function(self)
        if self.UpdateScrollChildRect then pcall(self.UpdateScrollChildRect, self) end
    end)

    pages[index] = { scroll=scroll, content=content, title=titleText }
    return content
end

frame:EnableMouseWheel(true)
frame:SetScript("OnMouseWheel", function(_, delta)
    local page = pages[selectedPage]
    if not page or not page.scroll:IsShown() then return end
    local current = page.scroll:GetVerticalScroll() or 0
    local range = page.scroll.GetVerticalScrollRange and page.scroll:GetVerticalScrollRange() or 0
    local target = current - delta * 58
    if target < 0 then target = 0 end
    if target > range then target = range end
    page.scroll:SetVerticalScroll(target)
end)

local function Section(parent, text, y)
    local label = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetPoint("TOPLEFT", parent, "TOPLEFT", 12, y)
    label:SetText(text)
    label:SetTextColor(0.35, 1.00, 0.58)
    local line = parent:CreateTexture(nil, "ARTWORK")
    line:SetTexture("Interface\\Buttons\\WHITE8X8")
    line:SetPoint("TOPLEFT", parent, "TOPLEFT", 12, y - 19)
    line:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -12, y - 19)
    line:SetHeight(1)
    line:SetVertexColor(0.20, 0.75, 0.40, 0.32)
end

local function Check(parent, label, path, x, y, customGet, customSet)
    local name = NextName("Check")
    local check = CreateFrame("CheckButton", name, parent, "UICheckButtonTemplate")
    check:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    local text = _G[name .. "Text"]
    if text then text:SetText(label); text:SetTextColor(0.90, 0.95, 0.92) end
    check:SetScript("OnClick", function(self)
        local value = self:GetChecked() and true or false
        if customSet then customSet(value) else addon:SetOption(path, value) end
    end)
    check.Refresh = function(self)
        local value
        if customGet then value = customGet() else value = addon:GetOption(path) end
        self:SetChecked(value and true or false)
    end
    return AddControl(check)
end

local function Slider(parent, label, path, minValue, maxValue, step, x, y, formatter)
    local labelText = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    labelText:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    labelText:SetText(label)
    labelText:SetTextColor(0.88, 0.92, 0.90)

    local valueText = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    valueText:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -24, y)
    valueText:SetTextColor(0.42, 1.00, 0.63)

    local name = NextName("Slider")
    local slider = CreateFrame("Slider", name, parent, "OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT", labelText, "BOTTOMLEFT", 0, -6)
    slider:SetWidth(490); slider:SetHeight(16)
    slider:SetMinMaxValues(minValue, maxValue)
    slider:SetValueStep(step)
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    local low, high, center = _G[name .. "Low"], _G[name .. "High"], _G[name .. "Text"]
    if low then low:SetText(tostring(minValue)) end
    if high then high:SetText(tostring(maxValue)) end
    if center then center:SetText("") end

    local updating = false
    local function ShowValue(value)
        valueText:SetText(formatter and formatter(value) or FormatNumber(value, step < 1 and 2 or 0))
    end
    slider:SetScript("OnValueChanged", function(self, value)
        value = Round(value, step)
        ShowValue(value)
        if not updating then addon:SetOption(path, value) end
    end)
    slider.Refresh = function(self)
        updating = true
        local value = tonumber(addon:GetOption(path)) or minValue
        self:SetValue(value)
        updating = false
        ShowValue(value)
    end
    return AddControl(slider)
end

local function Dropdown(parent, label, path, options, x, y, width, customGet, customSet)
    local text = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    text:SetText(label)
    text:SetTextColor(0.88, 0.92, 0.90)

    local name = NextName("Dropdown")
    local dropdown = CreateFrame("Frame", name, parent, "UIDropDownMenuTemplate")
    dropdown:SetPoint("TOPLEFT", text, "BOTTOMLEFT", -16, -4)
    UIDropDownMenu_SetWidth(dropdown, width or 220)

    UIDropDownMenu_Initialize(dropdown, function(self, level)
        for _, option in ipairs(options) do
            local value, optionLabel = option[1], option[2]
            local info = UIDropDownMenu_CreateInfo()
            info.text = optionLabel
            info.value = value
            info.checked = false
            info.func = function()
                if customSet then customSet(value) else addon:SetOption(path, value) end
                UIDropDownMenu_SetSelectedValue(dropdown, value)
                UIDropDownMenu_SetText(dropdown, optionLabel)
            end
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    dropdown.Refresh = function(self)
        local value
        if customGet then value = customGet() else value = addon:GetOption(path) end
        UIDropDownMenu_SetSelectedValue(self, value)
        local found = false
        for _, option in ipairs(options) do
            if option[1] == value then UIDropDownMenu_SetText(self, option[2]); found = true; break end
        end
        if not found then UIDropDownMenu_SetText(self, tostring(value or "")) end
    end
    return AddControl(dropdown)
end

local function ColorButton(parent, label, path, x, y)
    local text = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    text:SetText(label)

    local button = CreateFrame("Button", nil, parent)
    button:SetWidth(90); button:SetHeight(25)
    button:SetPoint("TOPLEFT", text, "BOTTOMLEFT", 0, -7)
    button:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=10, insets={left=3,right=3,top=3,bottom=3} })

    local swatch = button:CreateTexture(nil, "ARTWORK")
    swatch:SetPoint("TOPLEFT", button, "TOPLEFT", 5, -5)
    swatch:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -5, 5)
    swatch:SetTexture("Interface\\Buttons\\WHITE8X8")

    button:SetScript("OnClick", function()
        local color = addon:GetOption(path) or {1,1,1}
        local previous = {color[1], color[2], color[3]}
        ColorPickerFrame.func = function()
            local r, g, b = ColorPickerFrame:GetColorRGB()
            addon:SetOption(path, {r, g, b})
            swatch:SetVertexColor(r, g, b)
        end
        ColorPickerFrame.cancelFunc = function()
            addon:SetOption(path, previous)
            swatch:SetVertexColor(previous[1], previous[2], previous[3])
        end
        ColorPickerFrame.hasOpacity = false
        ColorPickerFrame:SetColorRGB(color[1], color[2], color[3])
        ColorPickerFrame:Show()
    end)
    button.Refresh = function()
        local color = addon:GetOption(path) or {1,1,1}
        swatch:SetVertexColor(color[1], color[2], color[3])
    end
    return AddControl(button)
end

local function Button(parent, label, x, y, width, callback)
    local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    button:SetWidth(width or 145); button:SetHeight(26)
    button:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    button:SetText(label)
    button:SetScript("OnClick", callback)
    return button
end

local function EditBox(parent, label, x, y, width)
    local text = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    text:SetText(label)
    local edit = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    edit:SetAutoFocus(false)
    edit:SetWidth(width or 240); edit:SetHeight(24)
    edit:SetPoint("TOPLEFT", text, "BOTTOMLEFT", 4, -7)
    edit:SetTextInsets(4, 4, 0, 0)
    return edit
end

local function VisualDB() return addon.visualFX and addon.visualFX:GetDB() or {} end
local function VisualSlider(parent, label, key, minValue, maxValue, step, x, y, formatter)
    local labelText = parent:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    labelText:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y); labelText:SetText(label); labelText:SetTextColor(0.88,0.92,0.90)
    local valueText = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    valueText:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -24, y); valueText:SetTextColor(0.42,1.00,0.63)
    local name=NextName("VisualSlider"); local slider=CreateFrame("Slider",name,parent,"OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT",labelText,"BOTTOMLEFT",0,-6); slider:SetWidth(490); slider:SetHeight(16)
    slider:SetMinMaxValues(minValue,maxValue); slider:SetValueStep(step); if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    local low,high,centerText=_G[name.."Low"],_G[name.."High"],_G[name.."Text"]
    if low then low:SetText(tostring(minValue)) end; if high then high:SetText(tostring(maxValue)) end; if centerText then centerText:SetText("") end
    local updating=false
    slider:SetScript("OnValueChanged",function(self,value)
        value=Round(value,step); if not updating then VisualDB()[key]=value end
        valueText:SetText(formatter and formatter(value) or FormatNumber(value,step<1 and 2 or 0))
    end)
    slider.Refresh=function(self) updating=true; self:SetValue(VisualDB()[key] or minValue); updating=false end
    return AddControl(slider)
end
local function VisualCheck(parent,label,key,x,y)
    return Check(parent,label,nil,x,y,function() return VisualDB()[key] end,function(v) VisualDB()[key]=v end)
end

local function EffectDB(effectName)
    local db=VisualDB(); db.effects=db.effects or {}; db.effects[effectName]=db.effects[effectName] or {}
    return db.effects[effectName]
end
local function EffectCheck(parent,label,effectName,key,x,y)
    return Check(parent,label,nil,x,y,function() return EffectDB(effectName)[key] end,function(v) EffectDB(effectName)[key]=v end)
end
local function EffectSlider(parent,label,effectName,key,minValue,maxValue,step,x,y,formatter)
    local labelText=parent:CreateFontString(nil,"OVERLAY","GameFontNormal")
    labelText:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y); labelText:SetText(label); labelText:SetTextColor(0.88,0.92,0.90)
    local valueText=parent:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    valueText:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-24,y); valueText:SetTextColor(0.42,1.00,0.63)
    local name=NextName("EffectSlider"); local slider=CreateFrame("Slider",name,parent,"OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT",labelText,"BOTTOMLEFT",0,-6); slider:SetWidth(490); slider:SetHeight(16); slider:SetMinMaxValues(minValue,maxValue); slider:SetValueStep(step)
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    local low,high,center=_G[name.."Low"],_G[name.."High"],_G[name.."Text"]; if low then low:SetText(tostring(minValue)) end; if high then high:SetText(tostring(maxValue)) end; if center then center:SetText("") end
    local updating=false
    slider:SetScript("OnValueChanged",function(self,value) value=Round(value,step); valueText:SetText(formatter and formatter(value) or tostring(value)); if not updating then EffectDB(effectName)[key]=value end end)
    slider.Refresh=function(self) updating=true; local value=tonumber(EffectDB(effectName)[key]) or minValue; self:SetValue(value); updating=false; valueText:SetText(formatter and formatter(value) or tostring(value)) end
    return AddControl(slider)
end
local function EffectPage(index,titleText,effectName,testMode,extraBuilder)
    local page=MakePage(index,titleText,1320)
    Section(page,addon.L("Включение и состав эффекта", "Effect enable and components"),-10)
    EffectCheck(page,addon.L("Включить этот эффект", "Enable this effect"),effectName,"enabled",18,-42)
    EffectCheck(page,addon.L("Центральная вспышка", "Center flash"),effectName,"center",280,-42)
    EffectCheck(page,addon.L("Частицы и искры", "Particles and sparks"),effectName,"particles",18,-78)
    EffectCheck(page,addon.L("Показывать текст", "Show text"),effectName,"text",280,-78)
    EffectCheck(page,addon.L("Свечение краёв экрана", "Screen-edge glow"),effectName,"edge",18,-114)
    Section(page,addon.L("Размер, яркость и длительность", "Size, brightness and duration"),-175)
    EffectSlider(page,addon.L("Размер эффекта", "Effect size"),effectName,"size",40,520,5,18,-208,function(v) return string.format("%d px",v) end)
    EffectSlider(page,addon.L("Общая яркость этого события", "Overall brightness for this event"),effectName,"alpha",0.10,1.00,0.05,18,-281,function(v) return string.format("%d%%",math.floor(v*100+0.5)) end)
    EffectSlider(page,addon.L("Сила центральной вспышки", "Center-flash strength"),effectName,"centerIntensity",0.00,1.50,0.05,18,-354,function(v) return string.format("%d%%",math.floor(v*100+0.5)) end)
    EffectSlider(page,addon.L("Сила затемнения / свечения углов", "Corner darkness / glow strength"),effectName,"edgeIntensity",0.00,1.50,0.05,18,-427,function(v) return string.format("%d%%",math.floor(v*100+0.5)) end)
    EffectSlider(page,addon.L("Длительность анимации", "Animation duration"),effectName,"duration",0.15,2.00,0.05,18,-500,function(v) return string.format(addon.L("%.2f сек", "%.2f sec"),v) end)
    Section(page,addon.L("Частицы", "Particles"),-575)
    EffectSlider(page,addon.L("Количество частиц", "Particle count"),effectName,"particleCount",0,30,1,18,-608,function(v) return string.format("%d",v) end)
    EffectSlider(page,addon.L("Разлёт частиц", "Particle spread"),effectName,"particleSpread",20,350,5,18,-681,function(v) return string.format("%d",v) end)

    
    Section(page,addon.L("Проверка", "Test"),-960)
    Button(page,addon.L("Показать этот эффект", "Show this effect"),18,-995,210,function() if addon.visualFX then addon.visualFX:TestEffect(effectName) end end)
    if extraBuilder then extraBuilder(page) end
    return page
end

local function ClickEffectPage(index,titleText,effectName,description)
    local page=MakePage(index,titleText,820)
    Section(page,addon.L("Мягкая вспышка возле курсора", "Soft flash near cursor"),-10)
    EffectCheck(page,addon.L("Включить эффект клика", "Enable click effect"),effectName,"enabled",18,-42)
    EffectCheck(page,addon.L("Добавить маленькие искры", "Add small sparks"),effectName,"particles",280,-42)
    EffectSlider(page,addon.L("Размер вспышки", "Flash size"),effectName,"size",35,180,5,18,-105,function(v) return string.format("%d px",v) end)
    EffectSlider(page,addon.L("Яркость", "Brightness"),effectName,"alpha",0.10,1.00,0.05,18,-178,function(v) return string.format("%d%%",math.floor(v*100+0.5)) end)
    EffectSlider(page,addon.L("Длительность", "Duration"),effectName,"duration",0.12,0.80,0.02,18,-251,function(v) return string.format(addon.L("%.2f сек", "%.2f sec"),v) end)
    Section(page,addon.L("Дополнительная модель искр", "Additional spark model"),-332)
    EffectSlider(page,addon.L("Показывать искры (0 = выключить)", "Show sparks (0 = off)"),effectName,"particleCount",0,18,1,18,-365,function(v) return string.format("%d",v) end)
    EffectSlider(page,addon.L("Интенсивность искр", "Spark intensity"),effectName,"particleSpread",15,180,5,18,-438,function(v) return string.format("%d",v) end)
    local info=page:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");info:SetPoint("TOPLEFT",page,"TOPLEFT",18,-520);info:SetWidth(500);info:SetJustifyH("LEFT");info:SetText(description)
    Button(page,addon.L("Показать вспышку", "Show flash"),18,-585,210,function() if addon.visualFX then addon.visualFX:TestEffect(effectName) end end)
    return page
end

local themeOptions = {
    {"auto", addon.L("Автоматически по классу", "Automatically by class")}, {"nature", addon.L("Природа", "Nature")}, {"arcane", addon.L("Тайная магия", "Arcane")},
    {"frost", addon.L("Лёд", "Frost")}, {"fire", addon.L("Огонь", "Fire")}, {"holy", addon.L("Свет", "Holy")}, {"shadow", addon.L("Тьма", "Shadow")},
    {"blood", addon.L("Кровь", "Blood")}, {"storm", addon.L("Буря", "Storm")}, {"poison", addon.L("Яд", "Poison")}, {"steel", addon.L("Сталь", "Steel")},
}
local strataOptions = {
    {"BACKGROUND", addon.L("Фон", "Background")}, {"LOW", addon.L("Низкий", "Low")}, {"MEDIUM", addon.L("Средний", "Medium")}, {"HIGH", addon.L("Высокий", "High")},
    {"DIALOG", addon.L("Диалог", "Dialog")}, {"FULLSCREEN", addon.L("Полный экран", "Fullscreen")}, {"FULLSCREEN_DIALOG", addon.L("Над интерфейсом", "Above UI")}, {"TOOLTIP", addon.L("Самый верхний", "Topmost")},
}

local general = MakePage(1, addon.L("Общее", "General"), 1160)
Section(general, addon.L("Основные параметры", "Main settings"), -10)
Check(general, addon.L("Включить эффекты каста", "Enable cast effects"), "enabled", 18, -42)
Check(general, addon.L("Плавно следовать за курсором", "Smoothly follow cursor"), "smooth", 280, -42)
Check(general, addon.L("Скрывать при управлении камерой", "Hide while controlling camera"), "hideInMouselook", 18, -78)
Slider(general, addon.L("Общий размер визуала", "Overall visual size"), "masterScale", 0.25, 3.00, 0.05, 18, -125, function(v) return string.format("%.2fx", v) end)
Slider(general, addon.L("Прозрачность", "Opacity"), "alpha", 0.10, 1.00, 0.05, 18, -198, function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)
Slider(general, addon.L("Смещение всего эффекта по X", "Whole-effect X offset"), "offsetX", -300, 300, 2, 18, -271, function(v) return string.format("%d px", v) end)
Slider(general, addon.L("Смещение всего эффекта по Y", "Whole-effect Y offset"), "offsetY", -300, 300, 2, 18, -344, function(v) return string.format("%d px", v) end)
Slider(general, addon.L("Скорость следования", "Follow speed"), "followSpeed", 1, 60, 1, 18, -417, function(v) return string.format("%d", v) end)
Dropdown(general, addon.L("Слой отображения", "Display layer"), "frameStrata", strataOptions, 18, -496, 220)

Section(general, addon.L("Цвет и оформление", "Color and appearance"), -585)
Dropdown(general, addon.L("Тема", "Theme"), "theme", themeOptions, 18, -618, 250)
Check(general, addon.L("Использовать собственные цвета", "Use custom colors"), "useCustomColors", 18, -695)
ColorButton(general, addon.L("Основной цвет", "Primary color"), "primaryColor", 18, -742)
ColorButton(general, addon.L("Дополнительный цвет", "Secondary color"), "secondaryColor", 180, -742)

Section(general, addon.L("Кнопка миникарты", "Minimap button"), -842)
Check(general, addon.L("Скрыть кнопку у миникарты", "Hide minimap button"), nil, 18, -875,
    function() return addon:EnsureDB().minimap.hide end,
    function(value) addon:EnsureDB().minimap.hide = value; addon:RefreshAll() end)
local resetMini = Button(general, addon.L("Вернуть кнопку на место", "Reset button position"), 18, -920, 190, function()
    addon:EnsureDB().minimap.angle = 220
    addon:RefreshAll()
end)

Section(general, addon.L("Язык интерфейса", "Interface language"), -980)
Dropdown(general, addon.L("Язык аддона", "Addon language"), nil, {
    {"auto", addon.L("Автоматически (язык клиента)", "Automatic (client language)")},
    {"ru", "Русский"},
    {"en", "English"},
}, 18, -1013, 260,
function() return addon:GetLanguage() end,
function(value)
    if addon:SetLanguage(value) then
        addon.Chat(addon.L("Язык сохранён. Перезагрузка интерфейса...", "Language saved. Reloading interface..."))
        ReloadUI()
    end
end)

local elements = MakePage(2, addon.L("Элементы", "Elements"), 2010)
Section(elements, addon.L("Видимость", "Visibility"), -10)
Check(elements, addon.L("Свечение", "Glow"), "elements.glow", 18, -42)
Check(elements, addon.L("Внешнее кольцо", "Outer ring"), "elements.outerRing", 280, -42)
Check(elements, addon.L("Внутреннее кольцо", "Inner ring"), "elements.innerRing", 18, -78)
Check(elements, addon.L("Иконка заклинания", "Spell icon"), "elements.icon", 280, -78)
Check(elements, addon.L("Рамка иконки", "Icon border"), "elements.iconBorder", 18, -114)
Check(elements, addon.L("Полоса прогресса", "Progress bar"), "elements.progress", 280, -114)
Check(elements, addon.L("Светящаяся точка на полосе", "Glowing point on bar"), "elements.progressSpark", 280, -150)
Check(elements, addon.L("Название заклинания", "Spell name"), "elements.name", 18, -150)
Check(elements, addon.L("Таймер", "Timer"), "elements.time", 18, -186)
Check(elements, addon.L("Орбитальные частицы", "Orbiting particles"), "elements.particles", 280, -186)
Check(elements, addon.L("Крест при ошибке", "Failure cross"), "elements.failureMark", 18, -222)

Section(elements, addon.L("Размеры", "Sizes"), -278)
Slider(elements, addon.L("Размер свечения", "Glow size"), "sizes.glow", 20, 350, 2, 18, -311, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Размер внешнего кольца", "Outer-ring size"), "sizes.outerRing", 20, 300, 2, 18, -384, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Размер внутреннего кольца", "Inner-ring size"), "sizes.innerRing", 20, 260, 2, 18, -457, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Размер иконки", "Icon size"), "sizes.icon", 10, 180, 2, 18, -530, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Размер рамки иконки", "Icon-border size"), "sizes.iconBorder", 10, 220, 2, 18, -603, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Ширина полосы", "Bar width"), "sizes.barWidth", 30, 350, 2, 18, -676, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Высота полосы", "Bar height"), "sizes.barHeight", 4, 50, 1, 18, -749, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Размер светящейся точки", "Glowing-point size"), "sizes.progressSpark", 4, 64, 1, 18, -822, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Размер названия", "Name size"), "sizes.nameFont", 6, 32, 1, 18, -895, function(v) return string.format("%d", v) end)
Slider(elements, addon.L("Размер таймера", "Timer size"), "sizes.timeFont", 6, 32, 1, 18, -968, function(v) return string.format("%d", v) end)

Section(elements, addon.L("Положение отдельных блоков", "Individual element positions"), -1014)
Slider(elements, addon.L("Кольца: X", "Rings: X"), "positions.ringX", -250, 250, 2, 18, -1047, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Кольца: Y", "Rings: Y"), "positions.ringY", -250, 250, 2, 18, -1120, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Иконка: X", "Icon: X"), "positions.iconX", -250, 250, 2, 18, -1193, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Иконка: Y", "Icon: Y"), "positions.iconY", -250, 250, 2, 18, -1266, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Полоса: X", "Bar: X"), "positions.barX", -300, 300, 2, 18, -1339, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Полоса: Y", "Bar: Y"), "positions.barY", -300, 300, 2, 18, -1412, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Название: X", "Name: X"), "positions.nameX", -300, 300, 2, 18, -1485, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Название: Y", "Name: Y"), "positions.nameY", -300, 300, 2, 18, -1558, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Таймер: X", "Timer: X"), "positions.timeX", -300, 300, 2, 18, -1631, function(v) return string.format("%d px", v) end)
Slider(elements, addon.L("Таймер: Y", "Timer: Y"), "positions.timeY", -300, 300, 2, 18, -1704, function(v) return string.format("%d px", v) end)
Button(elements, addon.L("Сбросить расположение", "Reset layout"), 18, -1792, 190, function()
    addon:GetProfile().positions = addon.DeepCopy(addon.defaultProfile.positions)
    addon:RefreshAll()
end)

local animations = MakePage(3, addon.L("Анимации", "Animations"), 1470)
Section(animations, addon.L("Поведение во время каста", "Behavior during casting"), -10)
Dropdown(animations, addon.L("Движение колец", "Ring motion"), "animation.castMotion", {
    {"static",addon.L("Без движения", "No motion")}, {"rotate",addon.L("Вращение", "Rotation")}, {"pulse",addon.L("Пульсация", "Pulse")}, {"rotatePulse",addon.L("Вращение и пульсация", "Rotation and pulse")},
}, 18, -43, 250)
Slider(animations, addon.L("Скорость вращения", "Rotation speed"), "animation.ringSpeed", -4, 4, 0.10, 18, -122, function(v) return string.format("%.1fx", v) end)
Slider(animations, addon.L("Сила пульсации", "Pulse strength"), "animation.pulseStrength", 0, 0.80, 0.02, 18, -195, function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)
Slider(animations, addon.L("Пульсация свечения", "Glow pulse"), "animation.glowPulse", 0, 1.00, 0.02, 18, -268, function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)

Section(animations, addon.L("Анимация полосы каста", "Cast-bar animation"), -350)
Dropdown(animations, addon.L("Движение прогресса", "Progress motion"), "animation.progressStyle", {
    {"smooth",addon.L("Плавное заполнение", "Smooth fill")}, {"direct",addon.L("Точное без сглаживания", "Exact, no smoothing")}, {"pulse",addon.L("Пульсирующее заполнение", "Pulsing fill")},
}, 18, -383, 250)
Slider(animations, addon.L("Яркость светящейся точки", "Glowing-point brightness"), "animation.progressPulse", 0, 0.50, 0.02, 18, -462, function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)

Section(animations, addon.L("Частицы", "Particles"), -555)
Dropdown(animations, addon.L("Тип частиц", "Particle type"), "animation.particleStyle", {
    {"mixed",addon.L("Листья и искры", "Leaves and sparks")}, {"leaves",addon.L("Только листья", "Leaves only")}, {"sparks",addon.L("Только искры", "Sparks only")}, {"soft",addon.L("Мягкое свечение", "Soft glow")},
}, 18, -588, 250)
Slider(animations, addon.L("Количество частиц", "Particle count"), "animation.particleCount", 0, 16, 1, 18, -667, function(v) return string.format("%d", v) end)
Slider(animations, addon.L("Размер частиц", "Particle size"), "sizes.particle", 3, 80, 1, 18, -740, function(v) return string.format("%d px", v) end)
Slider(animations, addon.L("Радиус частиц", "Particle radius"), "sizes.particleRadius", 10, 220, 2, 18, -813, function(v) return string.format("%d px", v) end)
Slider(animations, addon.L("Скорость частиц", "Particle speed"), "animation.particleSpeed", 0.10, 5.00, 0.05, 18, -886, function(v) return string.format("%.2fx", v) end)

Section(animations, addon.L("Результаты заклинаний", "Spell results"), -970)
Check(animations, addon.L("Показывать визуал для мгновенных заклинаний", "Show visuals for instant spells"), "animation.showInstantSpells", 18, -1000)
Dropdown(animations, addon.L("Стиль мгновенного заклинания", "Instant-spell style"), "animation.instantStyle", {
    {"pulse",addon.L("Мягкая пульсация", "Soft pulse")}, {"flash",addon.L("Вспышка", "Flash")}, {"minimal",addon.L("Минималистично", "Minimal")}, {"none",addon.L("Отключено", "Disabled")},
}, 18, -1040, 250)
Dropdown(animations, addon.L("Успешное применение", "Successful cast"), "animation.successStyle", {
    {"burst",addon.L("Яркий импульс", "Bright pulse")}, {"expand",addon.L("Расширение колец", "Expanding rings")}, {"spark",addon.L("Всплеск частиц", "Particle burst")}, {"flash",addon.L("Короткая вспышка", "Short flash")}, {"none",addon.L("Отключено", "Disabled")},
}, 18, -1082, 250)
Dropdown(animations, addon.L("Ошибка или прерывание", "Failure or interruption"), "animation.failureStyle", {
    {"shakeCross",addon.L("Тряска и крест", "Shake and cross")}, {"shake",addon.L("Только тряска", "Shake only")}, {"cross",addon.L("Только крест", "Cross only")}, {"redPulse",addon.L("Красная пульсация", "Red pulse")}, {"none",addon.L("Отключено", "Disabled")},
}, 18, -1161, 250)
Slider(animations, addon.L("Длительность финального эффекта", "Final-effect duration"), "animation.effectDuration", 0.15, 2.00, 0.05, 18, -1240, function(v) return string.format(addon.L("%.2f сек", "%.2f sec"), v) end)

local trail = MakePage(4, addon.L("След курсора", "Cursor trail"), 3450)
Section(trail, addon.L("Текстурный след", "Texture trail"), -10)
Check(trail, addon.L("Включить текстурный след", "Enable texture trail"), "trail.textureEnabled", 18, -42)
Check(trail, addon.L("Создавать след только при движении", "Create trail only while moving"), "trail.onlyWhileMoving", 280, -42)
Check(trail, addon.L("Двойная лента следа", "Double trail ribbon"), "trail.textureDouble", 18, -78)
Dropdown(trail, addon.L("Форма следа", "Trail shape"), "trail.textureStyle", {
    {"spark",addon.L("Искры", "Sparks")}, {"leaf",addon.L("Листья", "Leaves")}, {"soft",addon.L("Мягкий свет", "Soft light")}, {"rune",addon.L("Руны", "Runes")}, {"star",addon.L("Звёздные вспышки", "Starbursts")},
}, 18, -126, 250)
Dropdown(trail, addon.L("Цвет следа", "Trail color"), "trail.textureColor", {
    {"theme",addon.L("Основной цвет темы", "Primary theme color")}, {"secondary",addon.L("Дополнительный цвет", "Secondary color")}, {"custom",addon.L("Свой цвет", "Custom color")}, {"white",addon.L("Белый", "White")}, {"rainbow",addon.L("Радужный", "Rainbow")},
}, 18, -205, 250)
ColorButton(trail, addon.L("Собственный цвет", "Custom color"), "trail.customColor", 330, -244)
Dropdown(trail, addon.L("Поведение сегментов", "Segment behavior"), "trail.textureMotion", {
    {"shrink",addon.L("Сжимаются", "Shrink")}, {"grow",addon.L("Расширяются", "Grow")}, {"float",addon.L("Всплывают", "Float")}, {"drift",addon.L("Продолжают движение", "Continue moving")}, {"pulse",addon.L("Пульсируют", "Pulse")},
}, 18, -284, 250)
Dropdown(trail, addon.L("Режим смешивания", "Blend mode"), "trail.textureBlend", {
    {"ADD",addon.L("Светящийся", "Additive glow")}, {"BLEND",addon.L("Обычный прозрачный", "Normal transparent")},
}, 18, -363, 250)
Slider(trail, addon.L("Длина следа", "Trail length"), "trail.textureLength", 1, 64, 1, 18, -442, function(v) return string.format(addon.L("%d сегм.", "%d segments"), v) end)
Slider(trail, addon.L("Время затухания", "Fade time"), "trail.textureLifetime", 0.08, 3.00, 0.02, 18, -515, function(v) return string.format(addon.L("%.2f сек", "%.2f sec"), v) end)
Slider(trail, addon.L("Расстояние между сегментами", "Distance between segments"), "trail.textureSpacing", 1, 80, 1, 18, -588, function(v) return string.format("%d px", v) end)
Slider(trail, addon.L("Размер сегмента", "Segment size"), "trail.textureSize", 3, 160, 1, 18, -661, function(v) return string.format("%d px", v) end)
Slider(trail, addon.L("Разброс размера", "Size variation"), "trail.textureSizeVariation", 0, 0.75, 0.05, 18, -734, function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)
Slider(trail, addon.L("Разброс положения", "Position jitter"), "trail.textureJitter", 0, 80, 1, 18, -807, function(v) return string.format("%d px", v) end)
Slider(trail, addon.L("Прозрачность следа", "Trail opacity"), "trail.textureAlpha", 0.05, 1.00, 0.05, 18, -880, function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)

Section(trail, addon.L("Модельный след — встроенные эффекты клиента", "Model trail — built-in client effects"), -970)
Check(trail, addon.L("Включить модельный след", "Enable model trail"), "trail.modelEnabled", 18, -1002)
Check(trail, addon.L("Использовать дополнительный слой", "Use second layer"), "trail.modelSecondLayer", 280, -1002)
Check(trail, addon.L("Показывать модель только при движении", "Show model only while moving"), "trail.modelOnlyWhileMoving", 18, -1038)
Dropdown(trail, addon.L("Модель или многослойный эффект", "Model or multi-layer effect"), "trail.modelPreset", {
    {"energyBeam",addon.L("Молния из _Cursor — Energy beam", "_Cursor lightning — Energy beam")},
    {"custom",addon.L("Свои модели — оригинальный движок _Cursor", "Custom models — original _Cursor engine")},
    {"energyBeamLong",addon.L("Длинная синяя молния из _Cursor", "Long blue lightning from _Cursor")},
    {"electricBlue",addon.L("Синяя молния", "Blue lightning")}, {"electricBlueLong",addon.L("Синяя молния — длинная", "Blue lightning — long")},
    {"electricGreen",addon.L("Зелёная молния", "Green lightning")}, {"electricYellow",addon.L("Жёлтая молния", "Yellow lightning")},
    {"stormBeam",addon.L("Грозовой луч", "Storm beam")}, {"frostStorm",addon.L("Ледяная гроза", "Frost storm")},
    {"felBeam",addon.L("Луч скверны", "Fel beam")}, {"holyBeam",addon.L("Священный луч", "Holy beam")}, {"shadowBeam",addon.L("Тёмный луч", "Shadow beam")},
    {"nature",addon.L("Природный вихрь", "Nature vortex")}, {"leaves",addon.L("Листья", "Leaves")}, {"arcane",addon.L("Тайная пыль", "Arcane dust")},
    {"frost",addon.L("Лёд", "Frost")}, {"fire",addon.L("Огонь", "Fire")}, {"fel",addon.L("Скверна", "Fel")}, {"holy",addon.L("Свет", "Holy")},
    {"shadow",addon.L("Тьма", "Shadow")}, {"poison",addon.L("Ядовитый вихрь", "Poison vortex")}, {"ghost",addon.L("Призрачный", "Ghost")},
    {"white",addon.L("Белая лента", "White ribbon")}, {"intervene",addon.L("Синий рывок", "Blue charge")}, {"chargeRed",addon.L("Красный рывок", "Red charge")}, {"souls",addon.L("Души", "Souls")},
}, 18, -1086, 320)
Dropdown(trail, addon.L("Цветовая версия молнии/луча", "Lightning/beam color variant"), "trail.modelPalette", {
    {"auto",addon.L("Автоматически для эффекта", "Automatic for effect")}, {"blue",addon.L("Синий", "Blue")}, {"blueLong",addon.L("Синий длинный", "Long blue")},
    {"green",addon.L("Зелёный", "Green")}, {"yellow",addon.L("Золотой", "Gold")}, {"violet",addon.L("Фиолетовый", "Violet")},
    {"frost",addon.L("Ледяной", "Frost")}, {"white",addon.L("Белый", "White")}, {"red",addon.L("Красный", "Red")},
}, 18, -1165, 300)
Slider(trail, addon.L("Насыщенность модельного эффекта", "Model-effect intensity"), "trail.modelIntensity", 0.25, 2.50, 0.05, 18, -1244, function(v) return string.format("%.2fx", v) end)
Slider(trail, addon.L("Масштаб модели", "Model scale"), "trail.modelScale", 0.10, 5.00, 0.05, 18, -1317, function(v) return string.format("%.2fx", v) end)
Slider(trail, addon.L("Поворот модели", "Model rotation"), "trail.modelFacing", -6.28, 6.28, 0.05, 18, -1390, function(v) return string.format("%.2f", v) end)
Slider(trail, addon.L("Смещение модели X", "Model X offset"), "trail.modelOffsetX", -200, 200, 1, 18, -1463, function(v) return string.format("%d px", v) end)
Slider(trail, addon.L("Смещение модели Y", "Model Y offset"), "trail.modelOffsetY", -200, 200, 1, 18, -1536, function(v) return string.format("%d px", v) end)
Slider(trail, addon.L("Задержка скрытия после остановки", "Hide delay after stopping"), "trail.modelIdleDelay", 0.02, 2.00, 0.02, 18, -1609, function(v) return string.format(addon.L("%.2f сек", "%.2f sec"), v) end)
Dropdown(trail, addon.L("Слой модельного следа", "Model-trail layer"), "trail.modelStrata", strataOptions, 18, -1688, 250)

local modelColorHelp = trail:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
modelColorHelp:SetPoint("TOPLEFT", trail, "TOPLEFT", 18, -1778)
modelColorHelp:SetWidth(505); modelColorHelp:SetJustifyH("LEFT")
modelColorHelp:SetText(addon.L("У 3D-моделей цвет встроен в сам игровой файл, поэтому произвольный RGB для них невозможен. Пункт «Цветовая версия» заменяет модель на близкий синий, зелёный, золотой, фиолетовый, ледяной, белый или красный вариант. Для текстурного следа выше доступен любой собственный цвет.", "3D model colors are built into the game files, so arbitrary RGB colors are not available. The “Color variant” option swaps the model for a similar blue, green, gold, violet, frost, white or red version. The texture trail above can use any custom color."))
modelColorHelp:SetTextColor(0.72, 0.80, 0.76)

Section(trail, addon.L("Постоянный ореол вокруг курсора", "Persistent halo around cursor"), -1888)
Check(trail, addon.L("Включить ореол", "Enable halo"), "trail.haloEnabled", 18, -1920)
Dropdown(trail, addon.L("Вид ореола", "Halo style"), "trail.haloStyle", {
    {"ring",addon.L("Тонкое кольцо", "Thin ring")}, {"glow",addon.L("Мягкое свечение", "Soft glow")}, {"star",addon.L("Звёздная вспышка", "Starburst")}, {"rune",addon.L("Двойная руна", "Double rune")},
}, 18, -1968, 250)
Slider(trail, addon.L("Размер ореола", "Halo size"), "trail.haloSize", 8, 220, 2, 18, -2047, function(v) return string.format("%d px", v) end)
Slider(trail, addon.L("Прозрачность ореола", "Halo opacity"), "trail.haloAlpha", 0.05, 1.00, 0.05, 18, -2120, function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)
Slider(trail, addon.L("Сила пульсации ореола", "Halo pulse strength"), "trail.haloPulse", 0, 0.50, 0.02, 18, -2193, function(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end)

Section(trail, addon.L("Быстрые комбинации", "Quick combinations"), -2280)
Button(trail, addon.L("Оригинальная молния _Cursor", "Original _Cursor lightning"), 18, -2315, 225, function()
    local p = addon:GetProfile(); p.trail.modelEnabled=true; p.trail.modelPreset="energyBeam"; p.trail.modelPalette="blue"; p.trail.modelSecondLayer=true; p.trail.modelScale=1; p.trail.modelIntensity=1; addon:RefreshAll()
end)
Button(trail, addon.L("Длинная молния", "Long lightning"), 260, -2315, 160, function()
    local p = addon:GetProfile(); p.trail.modelEnabled=true; p.trail.modelPreset="energyBeamLong"; p.trail.modelPalette="blueLong"; p.trail.modelSecondLayer=true; addon:RefreshAll()
end)
Button(trail, addon.L("Ледяная гроза", "Frost storm"), 18, -2355, 180, function()
    local p = addon:GetProfile(); p.trail.modelEnabled=true; p.trail.modelPreset="frostStorm"; p.trail.modelSecondLayer=true; addon:RefreshAll()
end)
Button(trail, addon.L("Луч скверны", "Fel beam"), 215, -2355, 170, function()
    local p = addon:GetProfile(); p.trail.modelEnabled=true; p.trail.modelPreset="felBeam"; p.trail.modelSecondLayer=true; addon:RefreshAll()
end)
Button(trail, addon.L("Минималистичный хвост", "Minimal trail"), 18, -2395, 210, function()
    local p = addon:GetProfile(); p.trail.textureEnabled=true; p.trail.textureStyle="soft"; p.trail.textureMotion="shrink"; p.trail.textureLength=14; p.trail.textureLifetime=0.28; p.trail.textureSize=12; p.trail.textureAlpha=0.45; p.trail.modelEnabled=false; addon:RefreshAll()
end)
Button(trail, addon.L("Радужная двойная лента", "Rainbow double ribbon"), 245, -2395, 225, function()
    local p = addon:GetProfile(); p.trail.textureEnabled=true; p.trail.textureDouble=true; p.trail.textureStyle="spark"; p.trail.textureColor="rainbow"; p.trail.textureMotion="drift"; p.trail.textureLength=36; p.trail.textureLifetime=0.72; p.trail.textureSize=16; addon:RefreshAll()
end)

local trailHelp = trail:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
trailHelp:SetPoint("TOPLEFT", trail, "TOPLEFT", 18, -2490)
trailHelp:SetWidth(505); trailHelp:SetJustifyH("LEFT")
trailHelp:SetText(addon.L("Текстурный след, модельные слои и ореол можно включить одновременно. Многослойные эффекты красивее, но тяжелее для слабого компьютера. При просадке FPS отключи дополнительный модельный слой или уменьши длину текстурного следа.", "The texture trail, model layers and cursor halo can be enabled at the same time. Multi-layer effects look better but are heavier on slower computers. If FPS drops, disable the second model layer or reduce the texture trail length."))
trailHelp:SetTextColor(0.72, 0.80, 0.76)

Section(trail, addon.L("Точная привязка текстурного следа", "Exact texture-trail alignment"), -2585)
local coordinateModeText = trail:CreateFontString(nil, "OVERLAY", "GameFontNormal")
coordinateModeText:SetPoint("TOPLEFT", trail, "TOPLEFT", 18, -2620)
coordinateModeText:SetWidth(500); coordinateModeText:SetJustifyH("LEFT")
coordinateModeText:SetText(addon.L("Режим: физические пиксели — отдельный слой с эффективным масштабом 1.0", "Mode: physical pixels — separate layer with effective scale 1.0"))
coordinateModeText:SetTextColor(0.45, 1.00, 0.63)
Button(trail, addon.L("Показать диагностику", "Show diagnostics"), 18, -2670, 205, function()
    local module = addon.modules and addon.modules.Trail
    if module and module.ShowCoordinateStatus then module:ShowCoordinateStatus() end
end)
Button(trail, addon.L("Сбросить начало следа", "Reset trail origin"), 242, -2670, 205, function()
    local module = addon.modules and addon.modules.Trail
    if module and module.ResetCalibration then module:ResetCalibration() end
end)
local coordinateHelp = trail:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
coordinateHelp:SetPoint("TOPLEFT", trail, "TOPLEFT", 18, -2720)
coordinateHelp:SetWidth(505); coordinateHelp:SetJustifyH("LEFT")
coordinateHelp:SetText(addon.L("Текстурный след больше не переводит координаты вручную. Он рисуется в отдельном физическом слое: координаты GetCursorPosition используются напрямую, а UI Scale нейтрализуется обратным масштабом. Это повторяет принцип оригинального _Cursor, где эффект живёт в полноэкранном слое и получает необработанные координаты мыши.", "The texture trail no longer converts coordinates manually. It is drawn on a separate physical-pixel layer: GetCursorPosition coordinates are used directly and UI Scale is neutralized with inverse scaling. This follows the original _Cursor approach, where the effect lives on a full-screen layer and receives raw mouse coordinates."))
coordinateHelp:SetTextColor(0.72, 0.80, 0.76)

Section(trail, addon.L("Свои модели в точном движке _Cursor", "Custom models in the exact _Cursor engine"), -2820)
local customModelHelp = trail:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
customModelHelp:SetPoint("TOPLEFT", trail, "TOPLEFT", 18, -2855)
customModelHelp:SetWidth(505); customModelHelp:SetJustifyH("LEFT")
customModelHelp:SetText(addon.L("Можно заменить оба слоя на любой встроенный эффект клиента. Укажи путь модели без .mdx, например spells\\lightning_precast_low_hand. Позиционирование остаётся полностью таким же, как в оригинальном _Cursor.", "Both layers can be replaced with any built-in client effect. Enter the model path without .mdx, for example spells\\lightning_precast_low_hand. Positioning remains identical to the original _Cursor."))
customModelHelp:SetTextColor(0.72, 0.80, 0.76)

local customPath1 = EditBox(trail, addon.L("Путь первого слоя", "First-layer path"), 18, -2925, 500)
customPath1:SetScript("OnEnterPressed", function(self)
    local p = addon:GetProfile(); p.trail.customModelPath1 = self:GetText() or ""; p.trail.modelPreset = "custom"; self:ClearFocus(); addon:RefreshAll()
end)
customPath1:SetScript("OnEscapePressed", function(self) self:ClearFocus(); Config:Refresh() end)
customPath1.Refresh = function(self) self:SetText(tostring(addon:GetProfile().trail.customModelPath1 or "")) end
AddControl(customPath1)

local customPath2 = EditBox(trail, addon.L("Путь второго слоя", "Second-layer path"), 18, -2995, 500)
customPath2:SetScript("OnEnterPressed", function(self)
    local p = addon:GetProfile(); p.trail.customModelPath2 = self:GetText() or ""; p.trail.modelPreset = "custom"; self:ClearFocus(); addon:RefreshAll()
end)
customPath2:SetScript("OnEscapePressed", function(self) self:ClearFocus(); Config:Refresh() end)
customPath2.Refresh = function(self) self:SetText(tostring(addon:GetProfile().trail.customModelPath2 or "")) end
AddControl(customPath2)

Button(trail, addon.L("Применить свои модели", "Apply custom models"), 18, -3072, 220, function()
    local p = addon:GetProfile()
    p.trail.customModelPath1 = customPath1:GetText() or ""
    p.trail.customModelPath2 = customPath2:GetText() or ""
    p.trail.modelPreset = "custom"
    p.trail.modelEnabled = true
    addon:RefreshAll()
end)
Button(trail, addon.L("Вернуть Energy beam", "Restore Energy beam"), 260, -3072, 210, function()
    local p = addon:GetProfile()
    p.trail.modelPreset = "energyBeam"
    p.trail.modelPalette = "blue"
    p.trail.modelEnabled = true
    p.trail.modelSecondLayer = true
    addon:RefreshAll()
end)

local legacyHelp = trail:CreateFontString(nil, "OVERLAY", "GameFontNormal")
legacyHelp:SetPoint("TOPLEFT", trail, "TOPLEFT", 18, -3125)
legacyHelp:SetWidth(505); legacyHelp:SetJustifyH("LEFT")
legacyHelp:SetText(addon.L("Точный режим 0.5.4: Model создаётся дочерним объектом отдельной корневой рамки, получает SetAllPoints(nil), а позиция вычисляется как (GetCursorPosition + смещение) / диагональ экрана — без UI-якорей и пересчёта координат.", "Exact mode 0.5.4: the Model is created as a child of a separate root frame, receives SetAllPoints(nil), and its position is calculated as (GetCursorPosition + offset) / screen diagonal — without UI anchors or coordinate conversion."))
legacyHelp:SetTextColor(0.45, 1.00, 0.63)

local profiles = MakePage(5, addon.L("Профили и пресеты", "Profiles and presets"), 1000)
Section(profiles, addon.L("Готовые стили", "Ready-made styles"), -10)
local selectedPreset = "full"
local presetDrop = Dropdown(profiles, addon.L("Пресет", "Preset"), nil, {
    {"full",addon.L("Полная магия", "Full magic")}, {"minimal",addon.L("Минималистичный круг", "Minimal circle")}, {"clean",addon.L("Чистый: иконка и полоса", "Clean: icon and bar")},
    {"rings",addon.L("Только кольца", "Rings only")}, {"healer",addon.L("Целитель", "Healer")}, {"melee",addon.L("Ближний бой", "Melee")}, {"cursorOnly",addon.L("Только след курсора", "Cursor trail only")},
}, 18, -43, 280, function() return selectedPreset end, function(value) selectedPreset = value end)
Button(profiles, addon.L("Применить пресет", "Apply preset"), 330, -84, 180, function() addon:ApplyPreset(selectedPreset) end)

local presetHelp = profiles:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
presetHelp:SetPoint("TOPLEFT", profiles, "TOPLEFT", 18, -145)
presetHelp:SetWidth(500); presetHelp:SetJustifyH("LEFT")
presetHelp:SetText(addon.L("Пресет изменяет только связанные с ним параметры. После применения всё можно доработать вручную на остальных вкладках.", "A preset changes only its related settings. After applying it, every option can still be adjusted manually on the other tabs."))
presetHelp:SetTextColor(0.72, 0.80, 0.76)

Section(profiles, addon.L("Профили", "Profiles"), -220)
local selectedProfile = addon:GetProfileName()
local profileDrop = Dropdown(profiles, addon.L("Активный профиль", "Active profile"), nil, {}, 18, -253, 280,
    function() return addon:GetProfileName() end,
    function(value) addon:SetActiveProfile(value) end)

local function RebuildProfileDropdown()
    local options = {}
    for _, name in ipairs(addon:GetProfileNames()) do table.insert(options, {name, name}) end

    UIDropDownMenu_Initialize(profileDrop, function(self, level)
        for _, option in ipairs(options) do
            local value = option[1]
            local info = UIDropDownMenu_CreateInfo(); info.text=value; info.value=value
            info.func = function() addon:SetActiveProfile(value); profileDrop:Refresh() end
            UIDropDownMenu_AddButton(info, level)
        end
    end)
end
profileDrop.Refresh = function(self)
    RebuildProfileDropdown()
    local value = addon:GetProfileName()
    UIDropDownMenu_SetSelectedValue(self, value); UIDropDownMenu_SetText(self, value)
end

local profileName = EditBox(profiles, addon.L("Имя нового профиля", "New profile name"), 18, -344, 260)
Button(profiles, addon.L("Создать копию", "Create copy"), 310, -373, 170, function()
    local ok, err = addon:CreateProfile(profileName:GetText())
    if not ok then addon.Chat(err or addon.L("Не удалось создать профиль", "Could not create profile")) else profileName:SetText("") end
end)
Button(profiles, addon.L("Удалить активный", "Delete active profile"), 18, -468, 180, function()
    local ok, err = addon:DeleteProfile(addon:GetProfileName())
    if not ok then addon.Chat(err or addon.L("Не удалось удалить профиль", "Could not delete profile")) end
end)
Button(profiles, addon.L("Сбросить активный", "Reset active profile"), 215, -468, 180, function() addon:ResetProfile() end)

Section(profiles, addon.L("Быстрая проверка", "Quick test"), -520)
Button(profiles, addon.L("Обычный каст", "Normal cast"), 18, -555, 150, function() addon:RunTest("cast") end)
Button(profiles, addon.L("Канал", "Channel"), 185, -555, 150, function() addon:RunTest("channel") end)
Button(profiles, addon.L("Мгновенное", "Instant"), 352, -555, 150, function() addon:RunTest("instant") end)
Button(profiles, addon.L("Успех", "Success"), 18, -595, 150, function() addon:RunTest("success") end)
Button(profiles, addon.L("Ошибка", "Failure"), 185, -595, 150, function() addon:RunTest("failure") end)
Button(profiles, addon.L("Скрыть эффект", "Hide effect"), 352, -595, 150, function() addon:HideEffect() end)

local visualGeneral=MakePage(7,addon.L("Визуал: общее", "Visuals: general"),1000)
Section(visualGeneral,addon.L("Главный переключатель", "Master switch"),-10)
VisualCheck(visualGeneral,addon.L("Включить весь декоративный визуал", "Enable all decorative visuals"),"enabled",18,-42)
VisualCheck(visualGeneral,addon.L("Разрешить частицы глобально", "Allow particles globally"),"particles",280,-42)
VisualCheck(visualGeneral,addon.L("Разрешить текст глобально", "Allow text globally"),"text",18,-78)
VisualCheck(visualGeneral,addon.L("Разрешить свечение краёв", "Allow edge glow"),"screenEdges",280,-78)
Section(visualGeneral,addon.L("Общая интенсивность", "Global intensity"),-145)
VisualSlider(visualGeneral,addon.L("Общая прозрачность", "Global opacity"),"masterAlpha",0.10,1.00,0.05,18,-208,function(v) return string.format("%d%%",math.floor(v*100+0.5)) end)
VisualSlider(visualGeneral,addon.L("Общий масштаб декоративных эффектов", "Global decorative-effect scale"),"scale",0.50,1.80,0.05,18,-281,function(v) return string.format("%.2fx",v) end)
VisualSlider(visualGeneral,addon.L("Яркость свечения краёв", "Edge-glow brightness"),"edgeAlpha",0.05,1.00,0.05,18,-354,function(v) return string.format("%d%%",math.floor(v*100+0.5)) end)
VisualSlider(visualGeneral,addon.L("Защита от слишком частых повторов", "Repeat-rate protection"),"eventCooldown",0.05,1.00,0.05,18,-397,function(v) return string.format(addon.L("%.2f сек", "%.2f sec"),v) end)
Section(visualGeneral,addon.L("Быстрый тест", "Quick test"),-485)
Button(visualGeneral,addon.L("Показать всё", "Show all"),18,-520,180,function() if addon.visualFX then addon.visualFX:Test("all") end end)

local hiddenLeftClick=MakePage(8,addon.L("Скрыто", "Hidden"),100)
local hiddenRightClick=MakePage(9,addon.L("Скрыто", "Hidden"),100)

local hiddenCastStart=MakePage(10,addon.L("Скрыто", "Hidden"),100)
local hiddenCastSuccess=MakePage(11,addon.L("Скрыто", "Hidden"),100)
local critDamagePage=EffectPage(12,addon.L("Критический урон", "Critical damage"),"criticalDamage","all")
local critHealPage=EffectPage(13,addon.L("Критическое лечение", "Critical healing"),"criticalHeal","heal")
local interruptPage=EffectPage(14,addon.L("Прерывание", "Interrupt"),"interrupt","interrupt")
local hiddenDispel=MakePage(15,addon.L("Скрыто", "Hidden"),100)
local killPage=EffectPage(16,addon.L("Убийство и серия", "Kill and streak"),"kill","kill",function(page)
    Section(page,addon.L("Серия убийств", "Kill streak"),-700)
    VisualCheck(page,addon.L("Считать серию убийств", "Track kill streak"),"streak",18,-733)
    VisualSlider(page,addon.L("Окно продолжения серии", "Kill-streak continuation window"),"streakWindow",4,30,1,18,-770,function(v) return string.format(addon.L("%d сек", "%d sec"),v) end)
end)
local procPage=EffectPage(17,addon.L("Срабатывания талантов и эффектов (проки)", "Talent and effect triggers (procs)"),"proc","proc")
local procInfo=procPage:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");procInfo:SetPoint("TOPLEFT",procPage,"TOPLEFT",18,-720);procInfo:SetWidth(500);procInfo:SetJustifyH("LEFT");procInfo:SetText(addon.L("Прок — временно сработавший талант, бафф или аксессуар. У друида пример: Ясность мысли.", "A proc is a temporarily triggered talent, buff or trinket. Druid example: Clearcasting."))
local hiddenTarget=MakePage(18,addon.L("Скрыто", "Hidden"),100)
local controlPage=EffectPage(19,addon.L("Контроль персонажа", "Crowd control"),"control","proc",function(page)
    Section(page,addon.L("Дополнительно", "Additional"),-700)
    VisualCheck(page,addon.L("Показывать название контроля", "Show crowd-control name"),"controlText",18,-733)
end)
local damagePage=EffectPage(20,addon.L("Сильный входящий урон", "Heavy incoming damage"),"damageTaken","all",function(page)
    Section(page,addon.L("Условие срабатывания", "Trigger condition"),-700)
    VisualSlider(page,addon.L("Порог от максимального здоровья", "Threshold of maximum health"),"damageThreshold",5,50,1,18,-733,function(v) return string.format("%d%%",v) end)
end)
local lowHealthPage=EffectPage(21,addon.L("Низкое здоровье", "Low health"),"lowHealth","all",function(page)
    Section(page,addon.L("Условие срабатывания", "Trigger condition"),-700)
    VisualSlider(page,addon.L("Порог низкого здоровья", "Low-health threshold"),"lowHealthThreshold",5,60,1,18,-733,function(v) return string.format("%d%%",v) end)
end)
local lowManaPage=EffectPage(22,addon.L("Низкая мана", "Low mana"),"lowMana","all",function(page)
    Section(page,addon.L("Условие срабатывания", "Trigger condition"),-700)
    VisualSlider(page,addon.L("Порог низкой маны", "Low-mana threshold"),"lowManaThreshold",5,60,1,18,-733,function(v) return string.format("%d%%",v) end)
end)
local heartbeatPage=EffectPage(23,addon.L("Критическое здоровье", "Critical health"),"heartbeat","all",function(page)
    Section(page,addon.L("Условие срабатывания", "Trigger condition"),-700)
    VisualSlider(page,addon.L("Порог сердцебиения", "Heartbeat threshold"),"heartbeatThreshold",5,45,1,18,-733,function(v) return string.format("%d%%",v) end)
end)
local hiddenCombat=MakePage(24,addon.L("Скрыто", "Hidden"),100)
local deathPage=EffectPage(25,addon.L("Смерть и воскрешение", "Death and resurrection"),"death","death",function(page)
    Section(page,addon.L("Поведение после смерти", "Behavior after death"),-730)
    VisualCheck(page,addon.L("Держать затемнение краёв до воскрешения", "Keep edge darkness until resurrection"),"deathPersistent",18,-763)
    local info=page:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");info:SetPoint("TOPLEFT",page,"TOPLEFT",18,-810);info:SetWidth(500);info:SetJustifyH("LEFT");info:SetText(addon.L("При смерти края экрана остаются затемнёнными. После воскрешения затемнение снимается и появляется короткое зелёное свечение.", "When you die, the screen edges remain darkened. After resurrection, the darkness fades and a brief green glow appears."))
end)

local diagnostics = MakePage(6, addon.L("Диагностика", "Diagnostics"), 900)
Section(diagnostics, addon.L("Состояние аддона", "Addon status"), -10)
local statusText = diagnostics:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
statusText:SetPoint("TOPLEFT", diagnostics, "TOPLEFT", 18, -45)
statusText:SetWidth(505); statusText:SetJustifyH("LEFT"); statusText:SetJustifyV("TOP")
statusText:SetTextColor(0.85, 0.92, 0.88)
Config.statusText = statusText
Button(diagnostics, addon.L("Вывести статус в чат", "Print status to chat"), 18, -230, 190, function() addon:ShowStatus() end)
Button(diagnostics, addon.L("Очистить журнал ошибок", "Clear error log"), 225, -230, 190, function() addon.errors = {}; Config:Refresh() end)

local tips = diagnostics:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
tips:SetPoint("TOPLEFT", diagnostics, "TOPLEFT", 18, -310)
tips:SetWidth(505); tips:SetJustifyH("LEFT")
tips:SetText(addon.L("Если появится окно Lua-ошибки, пришли первый блок текста со строкой CursorCastFX. Полезные команды:\n\n/cfx config — открыть настройки\n/cfx test — переключать тесты\n/cfx preset minimal — применить минималистичный стиль\n/cfx trail — включить текстурный след\n/cfx modeltrail — включить модельный след\n/cfx status — диагностика\n/cfx reset — сбросить текущий профиль", "If a Lua error window appears, send the first text block containing CursorCastFX. Useful commands:\n\n/cfx config — open settings\n/cfx test — cycle tests\n/cfx preset minimal — apply the minimalist style\n/cfx trail — toggle the texture trail\n/cfx modeltrail — toggle the model trail\n/cfx status — diagnostics\n/cfx reset — reset the current profile"))
tips:SetTextColor(0.72, 0.82, 0.77)

local navData = {
 {addon.L("Общее", "General"),"Interface\\Icons\\INV_Misc_Gear_01",1},
 {addon.L("Элементы", "Elements"),"Interface\\Icons\\Spell_Arcane_Arcane01",2},
 {addon.L("Анимации", "Animations"),"Interface\\Icons\\Spell_Nature_StarFall",3},
 {addon.L("След курсора", "Cursor trail"),"Interface\\Icons\\Ability_Rogue_Sprint",4},
 {addon.L("Профили", "Profiles"),"Interface\\Icons\\INV_Misc_Note_05",5},
 {addon.L("Диагностика", "Diagnostics"),"Interface\\Icons\\INV_Gizmo_02",6},
 {addon.L("FX: общее", "FX: general"),"Interface\\Icons\\Spell_Holy_MagicalSentry",7},
 {addon.L("Крит. урон", "Crit. damage"),"Interface\\Icons\\Ability_CriticalStrike",12},
 {addon.L("Крит. лечение", "Crit. healing"),"Interface\\Icons\\Spell_Holy_Heal",13},
 {addon.L("Прерывание", "Interrupt"),"Interface\\Icons\\Ability_Kick",14},
 {addon.L("Убийство", "Kill"),"Interface\\Icons\\Ability_Warrior_DecisiveStrike",16},
 {addon.L("Проки", "Procs"),"Interface\\Icons\\Spell_Nature_WispSplode",17},
 {addon.L("Контроль", "Crowd control"),"Interface\\Icons\\Spell_Shadow_PsychicScream",19},
 {addon.L("Сильный урон", "Heavy damage"),"Interface\\Icons\\Ability_Warrior_BloodNova",20},
 {addon.L("Низкое здоровье", "Low health"),"Interface\\Icons\\Spell_Shadow_LifeDrain",21},
 {addon.L("Низкая мана", "Low mana"),"Interface\\Icons\\INV_Potion_76",22},
 {addon.L("Сердцебиение", "Heartbeat"),"Interface\\Icons\\Spell_Holy_SealOfSacrifice",23},
 {addon.L("Смерть", "Death"),"Interface\\Icons\\Spell_Shadow_SoulLeech_3",25},
}
local function SelectPage(index)
    selectedPage = index
    for i, page in ipairs(pages) do
        if i == index then
            page.scroll:Show()
            if page.scroll.UpdateScrollChildRect then pcall(page.scroll.UpdateScrollChildRect, page.scroll) end
        else
            page.scroll:Hide()
        end
    end
    for i, button in ipairs(navButtons) do
        if navData[i] and navData[i][3] == index then
            button:SetBackdropColor(0.10, 0.38, 0.22, 0.95)
            button.label:SetTextColor(0.45, 1.00, 0.65)
        else
            button:SetBackdropColor(0.035, 0.05, 0.06, 0.90)
            button.label:SetTextColor(0.82, 0.88, 0.84)
        end
    end
    pageTitle:SetText(pages[index].title)
end

for i, data in ipairs(navData) do
    local button = CreateFrame("Button", nil, leftPanel)
    button:SetWidth(144); button:SetHeight(20)
    button:SetPoint("TOPLEFT", leftPanel, "TOPLEFT", 10, -7 - (i - 1) * 21)
    button:SetBackdrop({ bgFile="Interface\\Buttons\\WHITE8X8", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", edgeSize=9, insets={left=2,right=2,top=2,bottom=2} })
    button:SetBackdropBorderColor(0.10, 0.28, 0.18, 0.72)
    local iconTexture = button:CreateTexture(nil, "ARTWORK")
    iconTexture:SetTexture(data[2]); iconTexture:SetWidth(15); iconTexture:SetHeight(15)
    iconTexture:SetPoint("LEFT", button, "LEFT", 8, 0); iconTexture:SetTexCoord(0.08,0.92,0.08,0.92)
    local label = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetPoint("LEFT", iconTexture, "RIGHT", 5, 0); label:SetText(data[1])
    button.label = label
    button:SetScript("OnClick", function() SelectPage(data[3]) end)
    navButtons[i] = button
end

local testButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
testButton:SetWidth(145); testButton:SetHeight(27)
testButton:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 20, 15)
testButton:SetText(addon.L("Проверить эффект", "Test effect"))
testButton:SetScript("OnClick", function() addon:RunTest(); if addon.visualFX then addon.visualFX:Test("all") end end)

local hideButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
hideButton:SetWidth(145); hideButton:SetHeight(27)
hideButton:SetPoint("LEFT", testButton, "RIGHT", 12, 0)
hideButton:SetText(addon.L("Скрыть эффект", "Hide effect"))
hideButton:SetScript("OnClick", function() addon:HideEffect() end)

local resetButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
resetButton:SetWidth(145); resetButton:SetHeight(27)
resetButton:SetPoint("LEFT", hideButton, "RIGHT", 12, 0)
resetButton:SetText(addon.L("Сбросить профиль", "Reset profile"))
resetButton:SetScript("OnClick", function() addon:ResetProfile() end)

local doneButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
doneButton:SetWidth(120); doneButton:SetHeight(27)
doneButton:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -20, 15)
doneButton:SetText(addon.L("Готово", "Done"))
doneButton:SetScript("OnClick", function() frame:Hide() end)

function Config:Refresh()
    profileLabel:SetText(addon.L("Профиль: |cffffff88", "Profile: |cffffff88") .. addon:GetProfileName() .. addon.L("|r   Версия ", "|r   Version ") .. addon.version)
    for _, control in ipairs(controls) do
        if control.Refresh then control:Refresh() end
    end
    if statusText then
        local modelState = addon:GetOption("trail.modelEnabled") and addon.L("включён", "enabled") or addon.L("выключен", "disabled")
        local textureState = addon:GetOption("trail.textureEnabled") and addon.L("включён", "enabled") or addon.L("выключен", "disabled")
        local lastError = #addon.errors > 0 and addon.errors[#addon.errors] or addon.L("нет", "none")
        statusText:SetText(
            addon.L("Версия: ", "Version: ") .. addon.version .. "\n" ..
            addon.L("Активный профиль: ", "Active profile: ") .. addon:GetProfileName() .. "\n" ..
            addon.L("Ядро: ", "Core: ") .. (addon.ready and addon.L("готово", "ready") or addon.L("не готово", "not ready")) .. "\n" ..
            addon.L("Текстурный след: ", "Texture trail: ") .. textureState .. "\n" ..
            addon.L("Модельный след: ", "Model trail: ") .. modelState .. "\n" ..
            addon.L("Количество ошибок: ", "Error count: ") .. tostring(#addon.errors) .. "\n\n" ..
            addon.L("Последняя ошибка:\n", "Last error:\n") .. tostring(lastError)
        )
    end
end

function addon:OpenConfig()
    if _G.CursorCastFXVisualFXConfig then _G.CursorCastFXVisualFXConfig:Hide() end
    if frame:IsShown() then frame:Hide() else frame:Show() end
end

frame:SetScript("OnShow", function()
    Config:Refresh()
    SelectPage(selectedPage)
end)

if UISpecialFrames then table.insert(UISpecialFrames, "CursorCastFXStudioConfig") end
SelectPage(1)
