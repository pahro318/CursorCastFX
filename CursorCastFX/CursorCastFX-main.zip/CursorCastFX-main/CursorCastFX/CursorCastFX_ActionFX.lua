local addon=_G.CursorCastFX;if not addon then return end
local Suite=addon.suite;if not Suite then return end
local A={};Suite:RegisterModule("actionFX",A);A.buttons={};A.elapsed=0
local prefixes={"ActionButton","MultiBarBottomLeftButton","MultiBarBottomRightButton","MultiBarRightButton","MultiBarLeftButton","BonusActionButton"}
local function Build()
 for _,p in ipairs(prefixes) do for i=1,12 do local b=_G[p..i];if b and not b.CursorCastFXGlow then local g=b:CreateTexture(nil,"OVERLAY");g:SetTexture("Interface\\Buttons\\UI-ActionButton-Border");g:SetBlendMode("ADD");g:SetPoint("CENTER",b,"CENTER",0,0);g:SetWidth(70);g:SetHeight(70);g:Hide();b.CursorCastFXGlow=g;table.insert(A.buttons,b) end end end
end
function A:Apply(db) Build();for _,b in ipairs(self.buttons) do if not db.enabled and b.CursorCastFXGlow then b.CursorCastFXGlow:Hide();b:SetAlpha(1) end end end
local f=CreateFrame("Frame");f:SetScript("OnUpdate",function(_,dt)A.elapsed=A.elapsed+dt;if A.elapsed<.10 then return end;A.elapsed=0;local db=Suite:GetDB().actionFX;if not db.enabled then return end;Build();local pulse=.65+.35*math.abs(math.sin(GetTime()*3.2));for _,b in ipairs(A.buttons) do local action=b.action;if not action and b.GetID then action=b:GetID() end;if action and HasAction(action) then local usable,nomana=IsUsableAction(action);local s,d,en=GetActionCooldown(action);local ready=usable and not nomana and (not en or en==0 or d==0);if ready and db.pulseReady then b.CursorCastFXGlow:Show();b.CursorCastFXGlow:SetAlpha((db.alpha or .9)*pulse) else b.CursorCastFXGlow:Hide() end;if db.dimUnusable then b:SetAlpha((usable and not nomana) and 1 or .45) end else b.CursorCastFXGlow:Hide();b:SetAlpha(1) end end end)
