local addon=_G.CursorCastFX;if not addon then return end
local Suite=addon.suite;if not Suite then return end
local M={};Suite:RegisterModule("castbars",M)
local function NewBar(name,label,y)
 local b=CreateFrame("StatusBar",name,UIParent);b:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar");b:SetStatusBarColor(.85,.55,.12);b:SetWidth(260);b:SetHeight(18);b:SetPoint("CENTER",0,y);b:SetFrameStrata("HIGH");b:Hide();b.bg=b:CreateTexture(nil,"BACKGROUND");b.bg:SetAllPoints(b);b.bg:SetTexture(0,0,0,.8);b.icon=b:CreateTexture(nil,"ARTWORK");b.icon:SetWidth(28);b.icon:SetHeight(28);b.icon:SetPoint("RIGHT",b,"LEFT",-5,0);b.text=b:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall");b.text:SetPoint("CENTER");b.tag=b:CreateFontString(nil,"OVERLAY","GameFontNormalSmall");b.tag:SetPoint("BOTTOMLEFT",b,"TOPLEFT",0,2);b.tag:SetText(label);return b
end
M.target=NewBar("CursorCastFXTargetCastbar",addon.L("ЦЕЛЬ", "TARGET"),135);M.focus=NewBar("CursorCastFXFocusCastbar",addon.L("ФОКУС", "FOCUS"),105)
local function Read(unit)
 local n,_,tex,startMS,endMS,_,_,notInterruptible=UnitCastingInfo(unit);local channel=false
 if not n then n,_,tex,startMS,endMS,_,notInterruptible=UnitChannelInfo(unit);channel=n and true or false end
 return n,tex,(startMS or 0)/1000,(endMS or 0)/1000,channel,notInterruptible
end
function M:UpdateBar(b,unit,enabled)
 if not enabled or not UnitExists(unit) then b:Hide();return end
 local n,tex,s,e,ch,ni=Read(unit);if not n then b:Hide();return end
 b.name=n;b.start=s;b.finish=e;b.channel=ch;b:SetMinMaxValues(s,e);b.icon:SetTexture(tex);b.text:SetText(n);if ni then b:SetStatusBarColor(.75,.15,.15) else b:SetStatusBarColor(.95,.62,.12) end;b:Show()
end
function M:Apply(db) self.target:SetWidth(db.width or 260);self.target:SetHeight(db.height or 18);self.focus:SetWidth(db.width or 260);self.focus:SetHeight(db.height or 18);self.target:SetScale(db.scale or 1);self.focus:SetScale(db.scale or 1);self.target:ClearAllPoints();self.target:SetPoint("CENTER",0,db.y or 135);self.focus:ClearAllPoints();self.focus:SetPoint("CENTER",0,(db.y or 135)-32);if not db.enabled then self.target:Hide();self.focus:Hide() end end
local ev=CreateFrame("Frame");for _,e in ipairs({"UNIT_SPELLCAST_START","UNIT_SPELLCAST_STOP","UNIT_SPELLCAST_FAILED","UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_DELAYED","UNIT_SPELLCAST_CHANNEL_START","UNIT_SPELLCAST_CHANNEL_UPDATE","UNIT_SPELLCAST_CHANNEL_STOP","PLAYER_TARGET_CHANGED","PLAYER_FOCUS_CHANGED"}) do ev:RegisterEvent(e) end
ev:SetScript("OnEvent",function(_,_,unit)local db=Suite:GetDB().castbars;if not unit or unit=="target" then M:UpdateBar(M.target,"target",db.enabled and db.target) end;if not unit or unit=="focus" then M:UpdateBar(M.focus,"focus",db.enabled and db.focus) end end)
local ticker=CreateFrame("Frame");ticker:SetScript("OnUpdate",function()for _,b in ipairs({M.target,M.focus}) do if b:IsShown() then local now=GetTime();if now>=b.finish then b:Hide() else b:SetValue(b.channel and (b.finish-now+b.start) or now) end end end end)
