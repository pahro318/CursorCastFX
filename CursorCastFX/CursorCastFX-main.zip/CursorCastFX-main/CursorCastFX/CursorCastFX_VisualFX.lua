local addon = _G.CursorCastFX
if not addon then return end

addon.visualFX = addon.visualFX or {}
local V = addon.visualFX
V.version = "1.0.0-beta20-author-defaults"
local sin, cos, pi, max, min = math.sin, math.cos, math.pi, math.max, math.min
local GetTime = GetTime

local function clamp01(x) return x < 0 and 0 or (x > 1 and 1 or x) end
local function smoothstep(x) x=clamp01(x); return x*x*(3-2*x) end
local function easeOutCubic(x) x=clamp01(x); local y=1-x; return 1-y*y*y end
local function easeInCubic(x) x=clamp01(x); return x*x*x end
local function pulseEnvelope(x)
 x=clamp01(x)
 if x < .18 then return smoothstep(x/.18) end
 return 1-smoothstep((x-.18)/.82)
end

local function style(enabled, particles, text, edge, size, alpha, duration, count, spread)
    return {enabled=enabled, center=true, particles=particles, text=text, edge=edge, size=size, alpha=alpha, centerIntensity=1, edgeIntensity=1, duration=duration, particleCount=count, particleSpread=spread}
end

local defaults = {
		["streak"] = true,
		["kill"] = true,
		["castSuccess"] = true,
		["streakWindow"] = 12,
		["criticalDamage"] = true,
		["screenEdges"] = true,
		["dispel"] = true,
		["sound"] = false,
		["masterAlpha"] = 0.9000000357627869,
		["enabled"] = true,
		["procAuras"] = true,
		["text"] = true,
		["ambientInterval"] = 3.2,
		["eventCooldown"] = 0.2,
		["heartbeat"] = true,
		["edgeAlpha"] = 0.45,
		["damageThreshold"] = 18,
		["cursorCast"] = true,
		["cursorClicks"] = true,
		["damageTaken"] = true,
		["controlAlert"] = true,
		["centerSize"] = 260,
		["combatState"] = true,
		["layoutRevision"] = "beta7-clean",
		["ambientCombat"] = false,
		["deathPersistent"] = true,
		["targetText"] = false,
		["intensity"] = 1,
		["targetChange"] = true,
		["heartbeatThreshold"] = 10,
		["interrupt"] = true,
		["effects"] = {
			["resurrection"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 0,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 0,
				["center"] = true,
				["alpha"] = 0.65,
				["edgeIntensity"] = 1,
				["duration"] = 0.7,
				["particles"] = false,
				["size"] = 260,
			},
			["kill"] = {
				["enabled"] = true,
				["text"] = true,
				["particleSpread"] = 250,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 24,
				["center"] = false,
				["alpha"] = 1,
				["edgeIntensity"] = 1,
				["duration"] = 0.9,
				["particles"] = false,
				["size"] = 320,
			},
			["castSuccess"] = {
				["enabled"] = false,
				["text"] = false,
				["particleSpread"] = 170,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 14,
				["center"] = true,
				["alpha"] = 1,
				["edgeIntensity"] = 1,
				["duration"] = 0.6,
				["particles"] = true,
				["size"] = 112,
			},
			["combatEnter"] = {
				["enabled"] = false,
				["text"] = false,
				["particleSpread"] = 0,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 0,
				["center"] = true,
				["alpha"] = 0.8,
				["edgeIntensity"] = 1,
				["duration"] = 0.45,
				["particles"] = false,
				["size"] = 260,
			},
			["criticalDamage"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 230,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 22,
				["center"] = false,
				["alpha"] = 1,
				["edgeIntensity"] = 1,
				["duration"] = 0.55,
				["particles"] = false,
				["size"] = 260,
			},
			["damageTaken"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 0,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 0,
				["center"] = false,
				["alpha"] = 1,
				["edgeIntensity"] = 0.55,
				["duration"] = 0.55,
				["particles"] = false,
				["size"] = 260,
			},
			["dispel"] = {
				["enabled"] = false,
				["text"] = false,
				["particleSpread"] = 170,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 14,
				["center"] = false,
				["alpha"] = 0.95,
				["edgeIntensity"] = 1,
				["duration"] = 0.3,
				["particles"] = false,
				["size"] = 105,
			},
			["combatLeave"] = {
				["enabled"] = false,
				["text"] = false,
				["particleSpread"] = 0,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 0,
				["center"] = true,
				["alpha"] = 0.75,
				["edgeIntensity"] = 1,
				["duration"] = 0.45,
				["particles"] = false,
				["size"] = 260,
			},
			["leftClick"] = {
				["enabled"] = false,
				["text"] = false,
				["particleSpread"] = 100,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 8,
				["center"] = true,
				["alpha"] = 0.9,
				["edgeIntensity"] = 1,
				["duration"] = 0.42,
				["particles"] = false,
				["size"] = 35,
			},
			["targetChange"] = {
				["enabled"] = false,
				["text"] = false,
				["particleSpread"] = 95,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 8,
				["center"] = false,
				["alpha"] = 0.85,
				["edgeIntensity"] = 1,
				["duration"] = 0.38,
				["particles"] = true,
				["size"] = 88,
			},
			["castStart"] = {
				["enabled"] = false,
				["text"] = false,
				["particleSpread"] = 100,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 8,
				["center"] = false,
				["alpha"] = 0.9,
				["edgeIntensity"] = 1,
				["duration"] = 0.42,
				["particles"] = false,
				["size"] = 92,
			},
			["lowMana"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 0,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 0,
				["center"] = false,
				["alpha"] = 0.8,
				["edgeIntensity"] = 0.8,
				["duration"] = 0.65,
				["particles"] = false,
				["size"] = 260,
			},
			["rightClick"] = {
				["enabled"] = false,
				["text"] = false,
				["particleSpread"] = 100,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 18,
				["center"] = true,
				["alpha"] = 0.9,
				["edgeIntensity"] = 1,
				["duration"] = 0.42,
				["particles"] = false,
				["size"] = 92,
			},
			["criticalHeal"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 230,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 22,
				["center"] = false,
				["alpha"] = 1,
				["edgeIntensity"] = 1,
				["duration"] = 0.65,
				["particles"] = false,
				["size"] = 260,
			},
			["lowHealth"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 0,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 0,
				["center"] = false,
				["alpha"] = 0.9,
				["edgeIntensity"] = 0.6000000000000001,
				["duration"] = 0.75,
				["particles"] = false,
				["size"] = 260,
			},
			["ambient"] = {
				["enabled"] = false,
				["text"] = false,
				["particleSpread"] = 0,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 0,
				["center"] = true,
				["alpha"] = 0.3,
				["edgeIntensity"] = 1,
				["duration"] = 0.35,
				["particles"] = false,
				["size"] = 260,
			},
			["control"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 210,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 20,
				["center"] = false,
				["alpha"] = 1,
				["edgeIntensity"] = 1,
				["duration"] = 0.85,
				["particles"] = false,
				["size"] = 300,
			},
			["interrupt"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 230,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 22,
				["center"] = false,
				["alpha"] = 1,
				["edgeIntensity"] = 1,
				["duration"] = 0.65,
				["particles"] = false,
				["size"] = 280,
			},
			["proc"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 25,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 1,
				["center"] = false,
				["alpha"] = 1,
				["edgeIntensity"] = 0.7000000000000001,
				["duration"] = 0.75,
				["particles"] = false,
				["size"] = 75,
			},
			["heartbeat"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 0,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 0,
				["center"] = false,
				["alpha"] = 1,
				["edgeIntensity"] = 1,
				["duration"] = 0.55,
				["particles"] = false,
				["size"] = 260,
			},
			["death"] = {
				["enabled"] = true,
				["text"] = false,
				["particleSpread"] = 0,
				["centerIntensity"] = 1,
				["edge"] = true,
				["particleCount"] = 0,
				["center"] = true,
				["alpha"] = 0.78,
				["edgeIntensity"] = 1,
				["duration"] = 1,
				["particles"] = false,
				["size"] = 260,
			},
		},
		["lowManaThreshold"] = 22,
		["criticalHeal"] = true,
		["lowHealth"] = true,
		["lowHealthThreshold"] = 30,
		["lowMana"] = true,
		["controlText"] = true,
		["cursorSize"] = 92,
		["scale"] = 1.049999952316284,
		["theme"] = "class",
		["particles"] = true,
	}

local palettes={
 nature={.20,1,.35,.95,.82,.20}, arcane={.62,.28,1,.18,.82,1}, frost={.18,.78,1,.82,.98,1},
 fire={1,.20,.03,1,.76,.08}, holy={1,.84,.18,1,1,.76}, shadow={.60,.14,.92,.95,.12,.55},
 blood={.92,.03,.08,.45,.01,.02}, storm={.08,.58,1,.72,.92,1}, poison={.40,1,.06,.66,.16,.96},
 steel={.72,.78,.88,1,.38,.06},
}
local classTheme={DRUID="nature",MAGE="arcane",DEATHKNIGHT="frost",PALADIN="holy",PRIEST="holy",SHAMAN="storm",WARLOCK="shadow",ROGUE="poison",WARRIOR="steel",HUNTER="nature"}
local function copy(v) if type(v)~="table" then return v end local t={} for k,x in pairs(v) do t[k]=copy(x) end return t end
local function merge(dst,src) if type(dst)~="table" then dst={} end for k,v in pairs(src) do if dst[k]==nil then dst[k]=copy(v) elseif type(dst[k])=="table" and type(v)=="table" then merge(dst[k],v) end end return dst end
function V:GetDB()
 if self.db then return self.db end
 if type(CursorCastFXDB)~="table" then CursorCastFXDB={} end
 CursorCastFXDB.visualFX=merge(CursorCastFXDB.visualFX,defaults)
 local db=CursorCastFXDB.visualFX
 if db.layoutRevision~="beta7-clean" then
  for _,name in ipairs({"castStart","castSuccess","dispel","targetChange","combatEnter","combatLeave","ambient"}) do
   if db.effects and db.effects[name] then db.effects[name].enabled=false end
  end
  db.layoutRevision="beta7-clean"
 end
 self.db=db
 return db
end
function V:GetEffect(name)
 local db=self:GetDB(); db.effects=db.effects or {}
 local effect=db.effects[name]
 if not effect then
  effect=copy(defaults.effects[name] or style(true,true,true,false,260,1,.6,12,150))
  db.effects[name]=effect
 end
 return effect
end
function V:GetPalette() local db=self:GetDB(); local n=db.theme if n=="class" then local _,c=UnitClass("player"); n=classTheme[c] or "arcane" end return palettes[n] or palettes.arcane end

local root=CreateFrame("Frame","CursorCastFXVisualFXRoot",UIParent); root:SetAllPoints(UIParent); root:SetFrameStrata("FULLSCREEN_DIALOG"); root:SetFrameLevel(200); root:EnableMouse(false); V.root=root

local edge=CreateFrame("Frame","CursorCastFXVisualEdgeFrame",UIParent)
edge:SetAllPoints(UIParent); edge:SetFrameStrata("FULLSCREEN_DIALOG"); edge:SetFrameLevel(500); edge:EnableMouse(false); edge:Hide(); V.edge=edge
local edgeSoft=edge:CreateTexture(nil,"ARTWORK")
edgeSoft:SetAllPoints(edge); edgeSoft:SetTexture("Interface\\AddOns\\CursorCastFX\\Media\\edge_glow.tga")
edgeSoft:SetBlendMode("ADD"); edgeSoft:SetAlpha(0)
local edgeCore=edge:CreateTexture(nil,"OVERLAY")
edgeCore:SetAllPoints(edge); edgeCore:SetTexture("Interface\\AddOns\\CursorCastFX\\Media\\edge_glow_inner.tga")
edgeCore:SetBlendMode("ADD"); edgeCore:SetAlpha(0)
local function ShowEdgeFrames(show)
 if show then edge:Show() else edge:Hide(); edgeSoft:SetAlpha(0); edgeCore:SetAlpha(0) end
end

local edgeProfiles = {

 lowHealth="red",             
 heartbeat="deepred",         
 damageTaken="yellow",        
 kill="crimson",              
 criticalDamage="orange",     
 lowMana="blue",              
 criticalHeal="green",        
 death="gray", resurrection="gold", interrupt="orange", proc="aqua",
 control="purple", combatLeave="cyan", combatEnter="orange", ambient="purple",
}

local effectProfiles = {
 castStart={cursor=true,center=true,label=addon.L("НАЧАЛО ПРИМЕНЕНИЯ", "CAST START"),strong=false},
 castSuccess={cursor=true,center=true,label=addon.L("ЗАКЛИНАНИЕ ПРИМЕНЕНО", "SPELL CAST"),strong=true},
 criticalDamage={center={1,.34,.03,1,.82,.10},edge=true,label=addon.L("КРИТИЧЕСКИЙ УДАР", "CRITICAL HIT"),strong=true},
 criticalHeal={center={.08,1,.34,.48,1,.68},edge=true,label=addon.L("КРИТИЧЕСКОЕ ИСЦЕЛЕНИЕ", "CRITICAL HEAL"),strong=true},
 interrupt={center={1,.62,.05,1,.95,.55},edge=true,label=addon.L("ПРЕРЫВАНИЕ", "INTERRUPT"),strong=true},
 dispel={center={.20,.72,1,.78,.95,1},label=addon.L("ОЧИЩЕНИЕ", "DISPEL"),strong=false},
 kill={center={1,.04,.30,1,.35,.62},edge=true,label=addon.L("ЦЕЛЬ УНИЧТОЖЕНА", "TARGET DESTROYED"),strong=true},
 proc={center={.05,1,.88,.65,1,1},edge=true,label=addon.L("СРАБОТАЛ ПРОК", "PROC TRIGGERED"),strong=true},
 targetChange={cursor={1,.10,.05,1,.55,.10},center={1,.10,.05,1,.55,.10},label=addon.L("ВРАЖЕСКАЯ ЦЕЛЬ", "ENEMY TARGET"),strong=false,targetText=true},
 control={center={.62,.12,1,.95,.40,1},edge=true,label=addon.L("КОНТРОЛЬ: ОГЛУШЕНИЕ", "CONTROL: STUN"),strong=true,controlText=true},
 damageTaken={center={1,.78,.04,1,.96,.38},edge=true,label=addon.L("СИЛЬНЫЙ УДАР", "HEAVY HIT")},
 lowHealth={center={1,.04,.03,.50,.01,.01},edge=true,duration=.85},
 lowMana={center={.05,.35,1,.18,.72,1},edge=true,duration=1.05},
 heartbeat={center={.66,.00,.05,1,.04,.12},edge=true,duration=.48},
 combatEnter={center={1,.34,.04,1,.72,.10},edge=true,label=addon.L("ВХОД В БОЙ", "ENTERING COMBAT")},
 combatLeave={center={.08,.42,1,.40,.75,1},edge=true,label=addon.L("ВЫХОД ИЗ БОЯ", "LEAVING COMBAT")},
 ambient={center={.38,.10,.65,.68,.28,.92},edge=true,label=addon.L("БОЕВАЯ АТМОСФЕРА", "COMBAT AMBIENCE")},
 death={death=true,edge=true,duration=1.0},
 resurrection={resurrection=true,edge=true},
}
V.effectProfiles=effectProfiles
local function ApplyEdgeProfile(effectName)
 local profile=edgeProfiles[effectName] or "gold"
 local base="Interface\\AddOns\\CursorCastFX\\Media\\"
 edgeSoft:SetTexture(base.."edge_glow_"..profile..".tga")
 edgeCore:SetTexture(base.."edge_glow_inner_"..profile..".tga")

 edgeSoft:SetVertexColor(1,1,1)
 edgeCore:SetVertexColor(1,1,1)
end

local deathEdge=CreateFrame("Frame","CursorCastFXDeathEdgeFrame",UIParent)
deathEdge:SetAllPoints(UIParent); deathEdge:SetFrameStrata("FULLSCREEN_DIALOG"); deathEdge:SetFrameLevel(490); deathEdge:EnableMouse(false); deathEdge:Hide(); V.deathEdge=deathEdge
local deathSoft=deathEdge:CreateTexture(nil,"ARTWORK")
deathSoft:SetAllPoints(deathEdge); deathSoft:SetTexture("Interface\\AddOns\\CursorCastFX\\Media\\death_vignette.tga")
deathSoft:SetVertexColor(.06,.065,.075); deathSoft:SetBlendMode("BLEND")
local deathCore=deathEdge:CreateTexture(nil,"OVERLAY")
deathCore:SetAllPoints(deathEdge); deathCore:SetTexture("Interface\\AddOns\\CursorCastFX\\Media\\death_vignette_inner.tga")
deathCore:SetVertexColor(.015,.018,.025); deathCore:SetBlendMode("BLEND")
local function ShowDeathFrames(show)
 if show then deathEdge:Show() else deathEdge:Hide() end
end
local center=CreateFrame("Frame",nil,root); center:SetSize(512,512); center:SetPoint("CENTER",UIParent,"CENTER",0,35)
local ring1=center:CreateTexture(nil,"ARTWORK"); ring1:SetAllPoints(center); ring1:SetTexture("Interface\\AddOns\\CursorCastFX\\Media\\ring_outer.tga"); ring1:SetBlendMode("ADD")
local ring2=center:CreateTexture(nil,"ARTWORK"); ring2:SetPoint("CENTER"); ring2:SetSize(360,360); ring2:SetTexture("Interface\\AddOns\\CursorCastFX\\Media\\ring_inner.tga"); ring2:SetBlendMode("ADD")
local burst=center:CreateTexture(nil,"OVERLAY"); burst:SetPoint("CENTER"); burst:SetSize(430,430); burst:SetTexture("Interface\\AddOns\\CursorCastFX\\Media\\burst.tga"); burst:SetBlendMode("ADD"); center:Hide(); V.center=center
local text=root:CreateFontString(nil,"OVERLAY","GameFontNormalHuge"); text:SetPoint("CENTER",UIParent,"CENTER",0,120); text:SetShadowOffset(2,-2); text:Hide(); V.text=text

local state={
 centerT=0,centerD=.6,edgeT=0,edgeD=.45,textT=0,textD=1.1,angle=0,
 lastTarget=nil,lowHealthPulse=0,lowManaPulse=0,heartbeatT=0,streak=0,streakAt=0,
 lastEvent={},activeAlpha=1,centerStyle=nil,edgeStyle=nil,edgeName=nil,
 deathCheck=0,testDeathUntil=0,vitalsElapsed=0,needVitalsTick=false,
 playerGUID=nil,wasDead=false,ambientT=0,controlName=nil,
 driverActive=false,perf={combat=0,rejected=0,handled=0,driverWakeups=0,driverSleeps=0}
}
local WakeDriver
local function setColor(p) ring1:SetVertexColor(p[1],p[2],p[3]); ring2:SetVertexColor(p[4] or p[1],p[5] or p[2],p[6] or p[3]); burst:SetVertexColor(p[4] or p[1],p[5] or p[2],p[6] or p[3]) end
function V:SpawnParticles(x,y,p,s) end
function V:CenterBurst(effectName,label,p,strong) local db=self:GetDB(); local s=self:GetEffect(effectName); if not db.enabled or not s.enabled or s.center==false then return end p=p or self:GetPalette(); setColor(p); state.centerT=0;state.centerD=s.duration or .65;state.angle=0;state.centerStyle=s; center:SetSize((s.size or 260)*(db.scale or 1),(s.size or 260)*(db.scale or 1));center:SetScale(1);center:SetAlpha(0);center:Show(); WakeDriver(); if db.text and s.text and label then text:SetText(label);text:SetTextColor(p[4] or p[1],p[5] or p[2],p[6] or p[3]);text:SetAlpha(0);text:Show();state.textT=0;state.textD=strong and 1.4 or 1 end; self:SpawnParticles(UIParent:GetWidth()/2,UIParent:GetHeight()/2+35,p,s) end
function V:EdgeFlash(effectName,p,durationOverride)
 local db=self:GetDB(); local st=self:GetEffect(effectName)
 if not db.enabled or not db.screenEdges or not st.enabled or not st.edge then return end
 ApplyEdgeProfile(effectName)
 edgeSoft:SetAlpha(0); edgeCore:SetAlpha(0); edge:SetAlpha(1); ShowEdgeFrames(true)
 state.edgeT=0; state.edgeD=durationOverride or st.duration or .5; state.edgeStyle=st; state.edgeName=effectName; WakeDriver()
end
function V:SetDeathEdges(show)
 local db=self:GetDB(); local st=self:GetEffect("death")
 if show and db.enabled and st.enabled and st.edge and db.deathPersistent then
  ShowEdgeFrames(false)
  local a=(st.alpha or .78)*(db.masterAlpha or 1)
  deathSoft:SetAlpha(a*.78); deathCore:SetAlpha(a*.42); ShowDeathFrames(true)
 else
  ShowDeathFrames(false)
 end
end
local function eventReady(name) local db=V:GetDB();local now=GetTime();local last=state.lastEvent[name] or 0;if now-last<(db.eventCooldown or .2) then return false end;state.lastEvent[name]=now;return true end

function V:TargetChanged() local db=self:GetDB();local s=self:GetEffect("targetChange");if not db.enabled or not s.enabled or not UnitExists("target") then return end;local guid=UnitGUID("target");if guid and guid==state.lastTarget then return end;state.lastTarget=guid;local label,p;if UnitIsDeadOrGhost("target") then label="МЁРТВАЯ ЦЕЛЬ";p={.45,.45,.50,.75,.75,.80} elseif UnitCanAttack("player","target") then label="ВРАЖЕСКАЯ ЦЕЛЬ";p={1,.10,.05,1,.55,.10} elseif UnitCanAssist("player","target") then label="СОЮЗНАЯ ЦЕЛЬ";p={.10,1,.35,.55,1,.70} else label="НОВАЯ ЦЕЛЬ";p={1,.78,.12,1,1,.60} end;self:PlayEffect("targetChange",{label=label,cursorColor=p,centerColor=p}) end
local controlSpells={[408]=true,[1833]=true,[5211]=true,[22570]=true,[853]=true,[10308]=true,[12809]=true,[30283]=true,[8122]=true,[2094]=true,[5782]=true,[6215]=true,[5484]=true,[6358]=true,[15487]=true,[1330]=true,[339]=true,[122]=true,[33395]=true,[64695]=true,[45524]=true,[1715]=true,[12323]=true}
function V:ScanControls() local db=self:GetDB();local s=self:GetEffect("control");if not s.enabled then return end;local found;for i=1,40 do local name,_,_,_,_,_,_,_,_,_,spellId=UnitDebuff("player",i);if not name then break end;if controlSpells[spellId or 0] then found=name;break end end;if found and not state.controlName and eventReady("control") then state.controlName=found;self:PlayEffect("control",{label="КОНТРОЛЬ: "..string.upper(found)}) elseif not found then state.controlName=nil end end
function V:UpdateVitals(elapsed)
 local db=self:GetDB()
 if not db.enabled or UnitIsDeadOrGhost("player") then state.needVitalsTick=false; return end
 local hpmax=UnitHealthMax("player") or 0
 local hp=UnitHealth("player") or 0
 local hpct=hpmax>0 and hp/hpmax*100 or 100
 state.needVitalsTick=false

 
 if self:GetEffect("lowHealth").enabled and hpct<=db.lowHealthThreshold then
  state.needVitalsTick=true
  state.lowHealthPulse=state.lowHealthPulse+elapsed
  local threshold=max(1,db.lowHealthThreshold or 30)
  local danger=max(0,min(1,(threshold-hpct)/threshold))
  local period=1.35-(danger*.72)
  if state.lowHealthPulse>=period and eventReady("lowhealth") then
   state.lowHealthPulse=0
   self:PlayEffect("lowHealth",{duration=min(.90,period*.82)})
  end
  state.lowManaPulse=0
 else
  state.lowHealthPulse=0
  local powerType=UnitPowerType("player")
  local pmax=UnitPowerMax("player",powerType) or 0
  local pv=UnitPower("player",powerType) or 0
  local pct=pmax>0 and pv/pmax*100 or 100
  if powerType==0 and self:GetEffect("lowMana").enabled and pct<=db.lowManaThreshold then
   state.needVitalsTick=true
   state.lowManaPulse=state.lowManaPulse+elapsed
   if state.lowManaPulse>=1.65 and eventReady("lowmana") then
    state.lowManaPulse=0
    self:PlayEffect("lowMana",{duration=1.05})
   end
  else
   state.lowManaPulse=0
  end
 end

 state.heartbeatT=0
end
local specialProcs={[16870]="ЯСНОСТЬ МЫСЛИ",[48518]="ЗАТМЕНИЕ",[48517]="ЗАТМЕНИЕ",[12536]="ЯСНОСТЬ МЫСЛИ",[48108]="ПРИЛИВ СИЛЫ",[44401]="ШКВАЛ ЧАР",[59578]="ИСКУССТВО ВОЙНЫ",[54149]="ИСКУССТВО ВОЙНЫ",[53817]="ВОДОВОРОТ",[16246]="ЯСНОСТЬ МЫСЛИ",[56453]="НА ИЗГОТОВКУ!",[59052]="МОРОЗНЫЙ ТУМАН",[46916]="ВНЕЗАПНАЯ СМЕРТЬ",[47283]="УСИЛЕННЫЙ ТРАНС",[63734]="ВЕЛИКАЯ ВОЛНА",[33151]="ПРИЛИВ СВЕТА"}
local procNames={["ЯСНОСТЬ МЫСЛИ"]=true,["CLEARCASTING"]=true,["ЗАТМЕНИЕ (ЛУНА)"]=true,["ЗАТМЕНИЕ (СОЛНЦЕ)"]=true,["ЗАТМЕНИЕ"]=true,["ECLIPSE (LUNAR)"]=true,["ECLIPSE (SOLAR)"]=true,["ECLIPSE"]=true}
local function procLabel(spellId,spellName) if specialProcs[spellId or 0] then return specialProcs[spellId or 0] end local upper=spellName and string.upper(spellName);if upper and procNames[upper] then return upper end end
local knownAuras={}
function V:ScanAuras(initializeOnly)
 if not self:GetEffect("proc").enabled then return end
 local current={}
 for i=1,40 do
  local name,rank,icon,count,debuffType,duration,expiration,caster,stealable,consolidate,spellId=UnitBuff("player",i)
  if not name then break end
  spellId=spellId or 0;local key=spellId..":"..name;current[key]=true
  local label=procLabel(spellId,name)
  if label and not initializeOnly and not knownAuras[key] and eventReady("proc") then self:PlayEffect("proc",{label=label}) end
 end
 knownAuras=current
end
local function isCritical(v) return v==true or v==1 or v=="1" end

local relevantCombatEvents={
 SPELL_DAMAGE=true,RANGE_DAMAGE=true,SPELL_PERIODIC_DAMAGE=true,SWING_DAMAGE=true,
 SPELL_HEAL=true,SPELL_PERIODIC_HEAL=true,SPELL_AURA_APPLIED=true,
 SPELL_INTERRUPT=true,PARTY_KILL=true,
}
function V:CombatLog(...)
 local db=self:GetDB(); if not db.enabled then return end
 local perf=state.perf; perf.combat=perf.combat+1
 local event=select(2,...)
 if not relevantCombatEvents[event] then perf.rejected=perf.rejected+1;return end
 local hasHideCaster=type(select(3,...))=="boolean"
 local srcGUID,dstGUID,payload
 if hasHideCaster then srcGUID=select(4,...);dstGUID=select(7,...);payload=10 else srcGUID=select(3,...);dstGUID=select(6,...);payload=9 end
 local pg=state.playerGUID or UnitGUID("player");state.playerGUID=pg
 local fromPlayer=srcGUID and srcGUID==pg
 local toPlayer=dstGUID and dstGUID==pg
 if not fromPlayer and not toPlayer then perf.rejected=perf.rejected+1;return end
 perf.handled=perf.handled+1
 if fromPlayer then
  if event=="SPELL_DAMAGE" or event=="RANGE_DAMAGE" or event=="SPELL_PERIODIC_DAMAGE" then
   if self:GetEffect("criticalDamage").enabled and isCritical(select(payload+9,...)) and eventReady("criticalDamage") then self:PlayEffect("criticalDamage") end
  elseif event=="SWING_DAMAGE" then
   if self:GetEffect("criticalDamage").enabled and isCritical(select(payload+6,...)) and eventReady("criticalDamage") then self:PlayEffect("criticalDamage") end
  elseif event=="SPELL_HEAL" or event=="SPELL_PERIODIC_HEAL" then
   if self:GetEffect("criticalHeal").enabled and isCritical(select(payload+6,...)) and eventReady("criticalHeal") then self:PlayEffect("criticalHeal") end
  elseif event=="SPELL_AURA_APPLIED" and toPlayer and self:GetEffect("proc").enabled then
   local spellId,spellName=select(payload,...),select(payload+1,...);local label=procLabel(spellId,spellName)
   if label and eventReady("proc") then self:PlayEffect("proc",{label=label}) end
  elseif event=="SPELL_INTERRUPT" and self:GetEffect("interrupt").enabled then self:PlayEffect("interrupt")
  elseif event=="PARTY_KILL" then
   local st=self:GetEffect("kill");if st.enabled then local now=GetTime();if db.streak and now-(state.streakAt or 0)<=db.streakWindow then state.streak=(state.streak or 0)+1 else state.streak=1 end;state.streakAt=now;local label="ЦЕЛЬ УНИЧТОЖЕНА";if db.streak and state.streak>=2 then label="СЕРИЯ x"..state.streak end;self:PlayEffect("kill",{label=label}) end
  end
 end
 if toPlayer and self:GetEffect("damageTaken").enabled then
  local amount;if event=="SWING_DAMAGE" then amount=select(payload,...) elseif event=="SPELL_DAMAGE" or event=="RANGE_DAMAGE" then amount=select(payload+3,...) end
  local hpmax=UnitHealthMax("player") or 0
  if amount and hpmax>0 and amount/hpmax*100>=db.damageThreshold then self:PlayEffect("damageTaken") end
 end
end

function V:PlayEffect(effectName, context)
 context=context or {}
 local profile=effectProfiles[effectName]
 if not profile then return end
 local label=context.label or profile.label
 local centerColor=context.centerColor or profile.center
 local cursorColor=context.cursorColor or profile.cursor
 local duration=context.duration or profile.duration
 local strong=context.strong
 if strong==nil then strong=profile.strong end

 if profile.death then
  if context.preview then state.testDeathUntil=GetTime()+(context.previewDuration or 2.5); WakeDriver() end
  self:SetDeathEdges(true)
 end
 if profile.resurrection then self:SetDeathEdges(false) end

 if profile.center then
  local allow=true
  if profile.targetText and not self:GetDB().targetText then allow=false end
  if profile.controlText and not self:GetDB().controlText then allow=false end
  if allow then self:CenterBurst(effectName,label,centerColor==true and nil or centerColor,strong) end
 end
 if profile.edge then self:EdgeFlash(effectName,nil,duration) end
end

function V:TestEffect(effectName)

 
 local context={preview=true}
 if effectName=="targetChange" then
  local label,p
  if UnitExists("target") then
   if UnitIsDeadOrGhost("target") then label="МЁРТВАЯ ЦЕЛЬ";p={.45,.45,.50,.75,.75,.80}
   elseif UnitCanAttack("player","target") then label="ВРАЖЕСКАЯ ЦЕЛЬ";p={1,.10,.05,1,.55,.10}
   elseif UnitCanAssist("player","target") then label="СОЮЗНАЯ ЦЕЛЬ";p={.10,1,.35,.55,1,.70}
   else label="НОВАЯ ЦЕЛЬ";p={1,.78,.12,1,1,.60} end
  else
   label="ТЕСТ СМЕНЫ ЦЕЛИ";p={1,.78,.12,1,1,.60}
  end
  context.label=label;context.cursorColor=p;context.centerColor=p
 elseif effectName=="proc" then context.label="ЯСНОСТЬ МЫСЛИ"
 elseif effectName=="dispel" then context.label="СНЯТ ЯД ИЛИ ПРОКЛЯТИЕ"
 elseif effectName=="criticalHeal" then context.label="КРИТИЧЕСКОЕ ИСЦЕЛЕНИЕ"
 end
 self:PlayEffect(effectName,context)
end

function V:Test(mode)
 local legacy={heal="criticalHeal",interrupt="interrupt",kill="kill",death="death",cast="castStart",success="castSuccess",proc="proc"}
 if mode=="all" or not mode then
  self:TestEffect("criticalDamage")
  self:TestEffect("criticalHeal")
 else
  self:TestEffect(legacy[mode] or mode)
 end
end
local function DriverNeeded()
 local db=V:GetDB()
 if center:IsShown() or edge:IsShown() or text:IsShown() then return true end
 if state.needVitalsTick then return true end
 if (state.testDeathUntil or 0)>0 then return true end
 if deathEdge:IsShown() then return true end
 if db.effects.ambient.enabled and UnitAffectingCombat("player") then return true end
 return false
end

local function DriverOnUpdate(_,elapsed)
  local db=V:GetDB()
  state.vitalsElapsed=state.vitalsElapsed+elapsed
  if state.needVitalsTick and state.vitalsElapsed>=.10 then
   V:UpdateVitals(state.vitalsElapsed)
   state.vitalsElapsed=0
  elseif not state.needVitalsTick then
   state.vitalsElapsed=0
  end

  if db.effects.ambient.enabled and UnitAffectingCombat("player") then
   state.ambientT=(state.ambientT or 0)+elapsed
   if state.ambientT>db.ambientInterval and eventReady("ambient") then state.ambientT=0;V:PlayEffect("ambient") end
  else state.ambientT=0 end

  if center:IsShown() then
   state.centerT=state.centerT+elapsed;local q=state.centerT/state.centerD
   if q>=1 then center:Hide() else
    local st=state.centerStyle or {}
    local envelope=pulseEnvelope(q)
    local a=envelope*(db.masterAlpha or 1)*(st.alpha or 1)*(st.centerIntensity or 1)
    center:SetAlpha(max(0,a))
    state.angle=state.angle+elapsed*(1.35+.65*(1-q))
    ring1:SetRotation(state.angle);ring2:SetRotation(-state.angle*1.35)
    center:SetScale(.72+easeOutCubic(q)*.58)
   end
  end

  if edge:IsShown() then
   state.edgeT=state.edgeT+elapsed;local q=state.edgeT/state.edgeD
   if q>=1 then ShowEdgeFrames(false) else
    local st=state.edgeStyle or {}
    local envelope=pulseEnvelope(q)
    local a=envelope*(db.edgeAlpha or .45)*(db.masterAlpha or 1)*(st.alpha or 1)*(st.edgeIntensity or 1)
    edgeSoft:SetAlpha(a);edgeCore:SetAlpha(a*(.38+.10*(1-q)))
   end
  end

  state.deathCheck=(state.deathCheck or 0)+elapsed
  if state.deathCheck>=.50 then
   state.deathCheck=0
   local now=GetTime()
   if (state.testDeathUntil or 0)>0 and now>=state.testDeathUntil then
    state.testDeathUntil=0
    if not UnitIsDeadOrGhost("player") then V:SetDeathEdges(false) end
   end
   local previewing=(state.testDeathUntil or 0)>now
   if not previewing then
    local dead=UnitIsDeadOrGhost("player") and true or false
    if dead~=state.wasDead then state.wasDead=dead;V:SetDeathEdges(dead)
    elseif dead and not deathEdge:IsShown() then V:SetDeathEdges(true)
    elseif not dead and deathEdge:IsShown() then V:SetDeathEdges(false) end
   end
  end

  if text:IsShown() then
   state.textT=state.textT+elapsed;local q=state.textT/state.textD
   if q>=1 then text:Hide() else
    local fadeIn=smoothstep(min(1,q/.16))
    local fadeOut=1-smoothstep(max(0,(q-.62)/.38))
    text:SetAlpha(fadeIn*fadeOut*(db.masterAlpha or 1))
    text:SetPoint("CENTER",UIParent,"CENTER",0,120+easeOutCubic(q)*20)
   end
  end

  if not DriverNeeded() then
   state.driverActive=false
   state.perf.driverSleeps=(state.perf.driverSleeps or 0)+1
   root:SetScript("OnUpdate",nil)
  end
end

WakeDriver=function()
 if state.driverActive then return end
 state.driverActive=true
 state.perf.driverWakeups=(state.perf.driverWakeups or 0)+1
 root:SetScript("OnUpdate",DriverOnUpdate)
end
V.WakeDriver=WakeDriver

local events=CreateFrame("Frame");for _,e in ipairs({"PLAYER_LOGIN","PLAYER_ENTERING_WORLD","UNIT_AURA","UNIT_HEALTH","UNIT_MANA","UNIT_MAXHEALTH","UNIT_MAXMANA","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","COMBAT_LOG_EVENT_UNFILTERED","PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST","PLAYER_FLAGS_CHANGED"}) do events:RegisterEvent(e) end
events:SetScript("OnEvent",function(_,event,...)
 local db=V:GetDB()
 if not db.enabled and event~="PLAYER_LOGIN" then return end
 if event=="PLAYER_LOGIN" then
  V:GetDB();state.playerGUID=UnitGUID("player");V:ScanAuras(true);state.wasDead=UnitIsDeadOrGhost("player") and true or false;V:SetDeathEdges(state.wasDead);V:UpdateVitals(.1);if DriverNeeded() then WakeDriver() end
 elseif event=="UNIT_AURA" then
  local unit=...;if unit=="player" then V:ScanAuras();V:ScanControls() end
 elseif event=="UNIT_HEALTH" or event=="UNIT_MANA" or event=="UNIT_MAXHEALTH" or event=="UNIT_MAXMANA" then
  local unit=...;if unit=="player" then V:UpdateVitals(.1);if DriverNeeded() then WakeDriver() end end
 elseif event=="PLAYER_REGEN_DISABLED" or event=="PLAYER_REGEN_ENABLED" then
  if DriverNeeded() then WakeDriver() end
 elseif event=="PLAYER_DEAD" then
  state.needVitalsTick=false;V:PlayEffect("death");WakeDriver()
 elseif event=="PLAYER_ALIVE" or event=="PLAYER_UNGHOST" then
  V:PlayEffect("resurrection");V:UpdateVitals(.1);if DriverNeeded() then WakeDriver() end
 elseif event=="PLAYER_ENTERING_WORLD" or event=="PLAYER_FLAGS_CHANGED" then
  state.playerGUID=UnitGUID("player");state.wasDead=UnitIsDeadOrGhost("player") and true or false;V:SetDeathEdges(state.wasDead);V:UpdateVitals(.1);if DriverNeeded() then WakeDriver() end
 elseif event=="COMBAT_LOG_EVENT_UNFILTERED" then V:CombatLog(...) end
end)

SLASH_CURSORCASTFXPERF1="/ccfxperf"
SlashCmdList["CURSORCASTFXPERF"]=function()
 local p=state.perf or {}
 local active=0
 if center:IsShown() then active=active+1 end
 if edge:IsShown() then active=active+1 end
 if deathEdge:IsShown() then active=active+1 end
 if text:IsShown() then active=active+1 end
 DEFAULT_CHAT_FRAME:AddMessage(string.format("|cff55ddffCursorCastFX Core|r: combat=%d, filtered=%d, relevant=%d, active=%d, driver=%s, wake=%d, sleep=%d",p.combat or 0,p.rejected or 0,p.handled or 0,active,state.driverActive and "ON" or "OFF",p.driverWakeups or 0,p.driverSleeps or 0))
end

SLASH_CURSORCASTFXCHECK1="/ccfxcheck"
SlashCmdList["CURSORCASTFXCHECK"]=function()
 local problems={}
 local db=V:GetDB()
 if type(db)~="table" then problems[#problems+1]="база настроек" end
 if type(db.effects)~="table" then problems[#problems+1]="таблица эффектов" end
 for name in pairs(effectProfiles) do
  if not db.effects or type(db.effects[name])~="table" then problems[#problems+1]="эффект "..name end
 end
 if not center or not edge or not deathEdge or not text then problems[#problems+1]="визуальные слои" end
 if type(DriverOnUpdate)~="function" or type(WakeDriver)~="function" then problems[#problems+1]="драйвер" end
 if #problems==0 then
  DEFAULT_CHAT_FRAME:AddMessage("|cff55ff88CursorCastFX|r: проверка ядра пройдена, ошибок не найдено.")
 else
  DEFAULT_CHAT_FRAME:AddMessage("|cffff5555CursorCastFX|r: проблема — "..table.concat(problems,", "))
 end
end

SLASH_CURSORCASTFXPERFRESET1="/ccfxperfreset"
SlashCmdList["CURSORCASTFXPERFRESET"]=function()
 state.perf={combat=0,rejected=0,handled=0,driverWakeups=0,driverSleeps=0}
 DEFAULT_CHAT_FRAME:AddMessage("|cff55ddffCursorCastFX Core|r: счётчики производительности сброшены.")
end
